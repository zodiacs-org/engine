# `@zodiacs/engine/calc`

One calculation API over positions, houses, longitude crossings and charts
in the tropical or sidereal zodiac, plus tropical stations and lunations.
It is a separate entry point, so the root entry (`@zodiacs/engine`) loads
none of it.

```ts
import { calc, houses, events, chart } from "@zodiacs/engine/calc";

const mars = calc({
  body: "Mars",
  time: { jd: 2461306.5, scale: "tt" },
  frame: "equatorial-true-of-date",
  center: "geocentric",
  flags: { correction: "apparent", cartesian: true }
});
if (mars.status === "ok") {
  console.log(mars.lon, mars.lat, mars.dist, mars.speeds, mars.bounds, mars.band, mars.receipt);
} else {
  console.log(mars.reason, mars.detail); // a typed refusal
}
```

With every default, `calc({ body, time })` is the position `positions()` and
`natalChart()` give, to the bit: the same longitude, latitude and speed, from
the same ephemeris (*Which ephemeris* below). Every result is a function of
its request and of the default source alone (`setDefaultEphemeris` in the
root entry, or `useDe440()` in `@zodiacs/engine/de440/pack`): nothing depends
on what was computed before it.

From 3.0.0 this file ships in the npm package, as
`node_modules/@zodiacs/engine/docs/calc.md`, beside
`skills/zodiacs-compute/SKILL.md`, for agents and for callers moving from
Swiss Ephemeris (*Swiss Ephemeris `calc_ut` flags* below). The documents it
links to are not packed: they are in the repository's
[`docs/`](https://github.com/zodiacs-org/engine/tree/main/docs).

## Which ephemeris

From 1.1.0-rc.10 the calc entry follows the root's default source
([de440.md](de440.md), *The default source*), so that every function gives
one position for one instant. In 1.1.0-rc.9 it stayed on astronomy-engine,
and a default `calc()` was as much as 29.19″ from `positions()` at one
instant a day (noon TT) from 1800 to 2199, and more for a planet passing
behind the Sun.

From 3.0.0 the default source is astronomy-engine, and neither the root's
graph nor this entry's holds the DE440 pack: a browser bundle of the root's
`natalChart` is 36,624 bytes gzipped, measured on 3.0.0's build
([guide.md](guide.md), *Bundle size in a web page*). One call makes the
shipped pack the default of the root and of this entry together:

```ts
import { useDe440 } from "@zodiacs/engine/de440/pack";
useDe440();
```

From 1.1.0-rc.10 to 2.1.0 the pack was the default without that call. The
table says what each request computes on after `useDe440()`. Before it, each
row that names the pack computes on astronomy-engine, names it and carries
no flag, as after `setDefaultEphemeris("astronomy-engine")`; and
`setDefaultEphemeris("de440")` with no `useDe440()` computes on
astronomy-engine and flags each such result `"de440-unavailable"`.

| request | computed on, after `useDe440()` |
| --- | --- |
| `calc()`: the Sun, the Moon, Mercury to Pluto, geocentric and apparent (the defaults), in any frame | the shipped DE440 pack |
| `calc()`: the true node and its opposite point | the shipped DE440 pack |
| `calc()`: True Black Moon Lilith (from 3.0.0) | the shipped DE440 pack's Moon state, as `chartPoints()` |
| `chart()` | as `natalChart()`: the shipped DE440 pack |
| `events()` | as `searchLongitudeCrossings()`: the shipped DE440 pack |
| `searchStations()`, `searchLunations()` | the default ephemeris over the whole window, including its probes |
| `calc()`: a heliocentric, barycentric or topocentric center; an astrometric or geometric correction; the Earth | astronomy-engine |
| `calc()`: the mean node, the mean south node, Black Moon Lilith | no ephemeris: their own series |
| `houses()` | no ephemeris |

The entry computes only inside `CALC_SPAN`, 1800 to 2200, which the pack
covers, so no request leaves the pack's years.

**A position from the pack** is the pack's apparent place as
`natalChart()` takes it: light time by iteration, the Sun's light deflection
(from 1.1.0-rc.12 none for a planet behind the Sun's disc, as JPL Horizons),
relativistic annual aberration, Mars to Pluto as planetary-system
barycentres, and the Moon from the ephemeris with light time, in the true
ecliptic of date ([de440.md](de440.md), *The reduction*). In any other frame
the same direction is turned from the true ecliptic of date with the engine's
own nutation and precession, as a node is. `dist` is the light path. Speeds
are central differences, as `positions()` takes them.

**What stays on astronomy-engine**, and why. The pack's reduction makes the
apparent geocentric place and nothing else. The other centers and
corrections are defined by astronomy-engine's own steps (its barycentre of
the Sun and the giant planets, planet centres, no light deflection, a
backdated observer), and every bound they quote was measured on
astronomy-engine. Moving them needs a second reduction and new comparisons
with an arbiter, which this candidate does not have. `natalChart()` gives
none of them, so none of them disagrees with it; but a topocentric or
geometric position of a body and its default position rest on two
ephemerides, up to the limits under *Bounds* apart, beyond the parallax or
the correction itself. The receipt of each says which it used.

**The result says which.** `receipt.engine.ephemeris` is
`{ name: "jpl-de440", version: <the pack's SHA-256> }` or
`{ name: "astronomy-engine", version: "2.1.19" }`, and the conventions hold
`ephemeris:<name>@<version>`. **No fallback is silent:** if the default is
the pack and the pack is not loaded (`setDefaultEphemeris("de440")` with no
`useDe440()`) or cannot be opened (its bytes are missing, their SHA-256 is
wrong, or they cannot be decoded), a position the pack would have given is
astronomy-engine's, its receipt names astronomy-engine, and its `flags` hold
`"de440-unavailable"`;
`chart()`'s chart and `events()`'s result carry the same flag.
After `setDefaultEphemeris("astronomy-engine")`, the caller's own choice,
the receipt names astronomy-engine and nothing is flagged. A request the
pack never gives is not a fallback and is not flagged.

In the sidereal zodiac the ayanamsa is the same on either ephemeris, but for
a star-anchored one, whose star is placed with astronomy-engine's Earth and
Sun ([vedic.md](vedic.md)), whatever the position came from.

The calc entry refuses inside `withEphemeris`, as before: a caller's source
gives no distance and has no measured bounds.

## Functions

| function | takes | gives |
| --- | --- | --- |
| `calc` | `{ body, time, frame?, center?, zodiac?, flags? }` | `{ lon, lat, dist, speeds, cartesian, ayanamsa, bounds, band, flags, receipt }` |
| `houses` | `{ time, place, houseSystem?, zodiac? }` | angles, Vertex, East Point, ARMC, obliquity and the cusps, with `ayanamsa`, `bounds`, `band` and a receipt, as `natalChart()` computes them |
| `events` | `{ kind: "longitude-crossing", body, longitude, from, to, zodiac?, stepDays?, maxSamples? }` | every instant in (from, to] the body sits on the longitude, from the engine's crossing search, each with its `band`, and `flags`, `bounds` and a receipt |
| `searchStations` | `{ from, to, body, maxSamples? }` | TT instants of reversals, outgoing direction and signed longitude curvature |
| `searchLunations` | `{ from, to, phaseDegrees, maxSamples? }` | TT instants of the requested phase and the Moon's longitude speed relative to the Sun |
| `chart` | `{ time, place?, houseSystem?, timeKnown?, timeFlags?, zodiac? }` | the chart `natalChart()` gives, with its sidereal longitudes in the sidereal zodiac, its `band` and a receipt |

Each returns `status: "ok"` or a typed refusal (below). Malformed input (an
unknown body, frame or field, an invalid date, a latitude out of range) throws
`RangeError`. `houses()` and `chart()` take a place without a height
(`CalcLocation`), and refuse one; a topocentric center takes a height
(`CalcPlace`).

## Station and lunation search

In 2.1.0-rc.1, `searchStations()` finds when Mercury through Pluto turn
direct or retrograde in apparent geocentric tropical longitude.
`searchLunations()` finds one Moon minus Sun longitude angle per call.
Use 0 for new Moon, 90 for first quarter, 180 for full Moon and 270 for
last quarter, in degrees. `events()` keeps its 2.0.0 longitude-crossing
request, result and signature.

Both round `from` and `to` to the nearest TT millisecond. A search includes
its right endpoint and excludes its left. To continue from an event, pass
`{ jd: event.jdTt, scale: "tt" }` as the next `from`. Adjacent windows
partition the events only when the whole window and both pieces use the
same ephemeris name and version. Each call chooses one source for its
entire window and the probes on either side. A source change can shift a
root across the cut. A zero-length window succeeds with zero samples.

A window must have `from` no later than `to`, and this is checked twice,
from 3.0.0. When both ends are on the same scale, a reversed window is
refused with a `RangeError` before either end is converted. Once converted
to TT (to UTC for `events()`), the ends are compared again: ends in order
on one scale can still come out reversed where the time basis steps back
between them. A 1 ms UT1 window across the end of the IERS table
(2027-10-02) converts to TT 1 ms backwards; a UTC window across 1972-01-01,
where the ΔT model gives way to the leap seconds, converts to TT up to
44.55 ms backwards; a UTC window across the ΔT model's step at 1941.0
(1940-12-31T18:00 UT1), up to 13.95 ms; and a TT window across a leap
second converts to UTC, on which `events()` runs, up to a second backwards.
Such a window is refused with a `RangeError` that names the conversion (the
input's scale and the scale the search runs on) and the step. Give both
ends on the scale the search runs on, TT for `searchStations()` and
`searchLunations()` and UTC for `events()`, or widen the window past the
step.

`maxSamples` accepts a positive safe integer or `Infinity` (the default).
The budget counts scalar evaluations during the scan, refinement and
confirmation. A `sample-budget` refusal reports the count and limit.
Retry the whole window with a larger budget. The search result and each event name the ephemeris and carry its flags.
An empty result also names its source.
An unreadable pack sets `de440-unavailable`. A padded window outside pack
coverage sets `outside-de440-span`. Both use astronomy-engine. Selecting
astronomy-engine explicitly leaves the fallback flag clear.

Each event gives `jdTt`, `jdUt1` and the calendar label `at`. Its
`band.utc` and `band.ut1` are one-sigma clock uncertainties in seconds.
`delta-t-extrapolated` flags an extrapolated time basis. The numerical TT
bracket is 0.001 s. The estimated `bounds.timing` in seconds adds that
bracket to the time implied by the local angular allowance, using longitude
curvature at a station or relative angular speed at a lunation. Shallow
stations have wider estimates. [Timing formulas and tests](proposals/2.1.0-station-lunation-search.md#root-and-uncertainty-calculation)

The independent DE440s L4 vectors cover 30 Mercury through Saturn stations
and 40 new or full Moons. The shipped pack passes all 70. Astronomy-engine
passes all 30 stations and 21 lunations. L4 has no quarter or outer-planet
station vectors. Separate DE440s checks cover both April 2024 quarters at
2 s and six Uranus, Neptune and Pluto stations in 2024. Two-second quarter
timing and station timing beyond Saturn remain unverified across the full
calc span. [L4 results](../conformance/RESULTS.md) and [additional reference cases](evidence/station-lunation-search/reference-residuals.csv)

## The input vocabulary

- **`time`**: an ISO 8601 string or a `Date`, read as UTC on the engine's
  time basis, as `positions()` and `natalChart()` read one
  ([time.md](time.md)): from 1972-01-01 to the end of the IERS UT1 table
  (2027-10-02), TT = UTC + (TAI − UTC) + 32.184 s from the IERS leap-second
  list, and UT1 = UTC + (UT1 − UTC) from IERS; before 1972 civil time is
  read as UT1 and TT comes from the ΔT model (`zodiacs-deltat/1`); after the
  table (the continuous-UTC rule), TT = UTC + 69.184 s and UT1 = TT − ΔT from
  the model. Or
  `{ jd, scale: "utc" | "ut1" | "tt" }`, a Julian date on a named time scale
  (the root entry's `TimeScaleName`; before 1.0.0 the names were in capitals),
  read on the same basis, or `{ iso }`. Any of the object forms takes
  `deltaT`, a fixed ΔT = TT − UT1 in seconds, in place of the basis's: UT1
  still comes from the instant, and TT = UT1 + ΔT. The receipt records the
  UTC, UT1 and TT the engine used. A Julian date near 2.46 million holds time
  to about 4 × 10⁻¹⁰ of a day (40 µs); `chart()` reads it to the nearest
  millisecond, because `natalChart()` takes a `Date`. An instant is computed
  only when both its UT1 and its TT lie in the span (see Refusals). One
  exception, in `chart()` alone: a calendar date with no time, such as
  `"1990-05-03"` or `{ iso: "1990-05-03" }`, is refused with a `RangeError`,
  as `natalChart()` refuses one as a birth's `utc`, unless `timeKnown` is
  false. Read as 00:00 UTC it would give angles and houses for a birth time
  nobody gave. With `timeKnown: false` the date is read as 00:00 UTC and the
  chart has the `no-time` flag and no angles or houses. The refusal comes
  after every other input check and after the span, so a date outside the
  span is refused as `out-of-range` first. `calc()`, `houses()` and
  `events()` read a calendar date as 00:00 UTC, as `positions()` does.
- **`place`** and the topocentric observer: `{ latitude, longitude }`,
  geodetic, east longitude positive, degrees; the observer also takes
  `height` in metres above astronomy-engine's ellipsoid (IERS 2003,
  a = 6378.1366 km, 1/f = 298.25642), 0 by default.
- **`frame`**: one of eight, below. Default `"ecliptic-true-of-date"`.
- **`center`**: `"geocentric"` (default), `"heliocentric"`, `"barycentric"`,
  or `{ topocentric: { latitude, longitude, height? } }`.
- **`zodiac`**: `"tropical"` (default) or `{ sidereal: ayanamsa }`, where
  `ayanamsa` is one of `lahiri`, `fagan-bradley`, `krishnamurti`, `raman`,
  `yukteswar`, `true-chitra`, `true-revati`, `true-pushya` or
  `galactic-center`, the ayanamsas of `@zodiacs/engine/vedic`
  ([vedic.md](vedic.md)), or a caller's own (see *The sidereal zodiac*).
- **`flags`**: `correction` (`"apparent"`, `"astrometric"` or `"geometric"`,
  default apparent), `speeds` (default true), `cartesian` (default false),
  `units` (`"degrees"` or `"radians"`, default degrees) and `deflection`
  (default false; true is refused). `deflection` is not a switch: the
  pack's apparent place has the Sun's light deflection (outside the Sun's
  disc) whatever it says, and astronomy-engine's places have none. A
  receipt echoes the request as given, `false` included; its conventions
  say what was applied, `deflection:sun-outside-disc` or `deflection:none`.

**Bodies**: the Sun, the Moon, Mercury to Pluto, the Earth (heliocentric and
barycentric only), the true lunar nodes (`"North Node"`, `"South Node"`), the
mean ones (`"Mean Node"`, `"Mean South Node"`), `"Black Moon Lilith"`, the
mean lunar apogee, and from 3.0.0 `"True Black Moon Lilith"`, the osculating
lunar apogee (`lilith:true-osculating` below). The planets are astronomy-engine's: truncated VSOP87 for
Mercury to Neptune, and its own integration for Pluto. Mars to Pluto were
compared with Horizons's system barycentres (NAIF 4 to 9), as the conformance
suite compares them. Its L1 build finds Horizons's body centres of Mars,
Jupiter, Saturn and Pluto at most 0.084″ from those barycentres, as their
satellites explain, and those of Uranus and Neptune, from their satellite
solutions, up to 0.67″ and 0.11″ away (`conformance/arbiters/l1/README.md`);
all of it is inside the ephemeris's own error.

## Frames

A position is found as a vector on astronomy-engine's EQJ axes (the mean
equator and equinox of J2000.0 that its precession starts from), and turned
into the frame asked for:

| `frame` | plane and equinox | how |
| --- | --- | --- |
| `ecliptic-true-of-date` | ecliptic of date, true equinox | IAU 2006 precession, the IAU 2006 mean obliquity and the IAU 2000B nutation in longitude, as `positions()` turns a vector: the longitude on the mean ecliptic of date plus Δψ (see below) |
| `ecliptic-mean-of-date` | ecliptic of date, mean equinox | the same without the nutation |
| `ecliptic-j2000` | mean ecliptic and equinox of J2000.0 | EQJ turned by the IAU 2006 obliquity of J2000.0, 84381.406″ |
| `ecliptic-icrs` | ecliptic on ICRS axes | the ICRS turned by 84381.406″ about its x axis |
| `equatorial-true-of-date` | true equator and equinox of date (apparent right ascension and declination) | the same precession and nutation, on the true obliquity (the mean obliquity plus Δε) |
| `equatorial-mean-of-date` | mean equator and equinox of date | the precession alone |
| `equatorial-j2000` | mean equator and equinox of J2000.0 | EQJ itself |
| `equatorial-icrs` | ICRS | EQJ less the IAU 2000 frame bias (dψ = −0.041775″, dε = −0.0068192″, dα₀ = −0.0146″, composed as ERFA's `eraBp00`) |

In an equatorial frame `lon` is right ascension, in degrees (or radians), not
hours, and `lat` is declination. The ICRS and J2000.0 frames differ by the
frame bias, at most 0.023″. Where astronomy-engine's EQJ sits between the two
is not settled below that level; its planetary series is referred to the FK5
by a fixed rotation. Horizons's `ECLIPTIC` reference plane uses the IAU 1976
obliquity, 84381.448″, so it is tilted 0.042″ from `ecliptic-icrs`.

The precession is astronomy-engine's (IAU 2006, the angles of Capitaine et al.
2003), which the engine reproduces term for term (`src/frame.ts`), and the
nutation the engine's own IAU 2000B (McCarthy and Luzum 2003): all 77 of its
luni-solar terms and its two fixed planetary offsets (`src/nutation.ts`;
[guide.md](guide.md), *Nutation*). They are the precession and nutation of `positions()`
and `natalChart()` on astronomy-engine, so there the default frame is
`positions()` to the bit. (A place from the DE440 pack reaches the true
ecliptic of date by the pack's own chain, with the P03 adjustment of the
nutation; *Which ephemeris*.) Its Δψ
and Δε equal ERFA's `nut00b` within 10⁻¹⁰″ from 1800 to 2200
(`docs/evidence/nutation-2026-09-29`), and IAU 2000B's Δψ is at most 0.00394″
from IAU 2006/2000A's (ERFA's `nut06a`) there, sampled every 0.1 day of TT
(the largest in 2192), which a longitude of date inherits
(`docs/evidence/rc16-20260930/results/nutation-grid.json`). The receipts name
it `nutation:iau2000b`. Up to 0.1.1-rc.15 the engine took astronomy-engine's
nutation, which keeps five of the 77 terms: sampled every 0.1 day from 1800 to
2200 it was up to 0.27″ from the full series in longitude and 0.087″ in
obliquity, and its rate up to 0.079″ a day in longitude
(`docs/evidence/calc-api`, diagnostic D4).

## The sidereal zodiac

`zodiac: { sidereal }` counts longitudes from the sidereal zero point of an
ayanamsa, every function alike. A sidereal longitude is the longitude in the
ecliptic of date less the ayanamsa: in `ecliptic-true-of-date` the true
ayanamsa, the mean one plus the nutation in longitude Δψ, and in
`ecliptic-mean-of-date` the mean one. Δψ cancels, so the two frames give the
same sidereal longitude, within 10⁻⁶″. The other six frames are refused
(`unsupported-combination`), because the ayanamsa is counted along the
ecliptic of date from its equinox; Swiss Ephemeris's projections onto the
ecliptic of an epoch or the solar system's plane (`SE_SIDBIT_ECL_T0`,
`SE_SIDBIT_SSY_PLANE`) are not offered.

- **`calc()`** subtracts the ayanamsa as `@zodiacs/engine/vedic`'s
  `siderealLongitude()` does, at the instant on its own clock, so with every
  other default it gives `siderealChart()`'s longitudes to the bit. Every
  center is offered, and the nodes and Lilith. The latitude and the distance
  are the tropical ones; a cartesian position and its velocity are turned
  about the pole of the ecliptic with the longitude. The speed is the
  sidereal longitude's, differenced as the tropical one is: the tropical
  speed less the rate of the ayanamsa subtracted. A precessing definition's
  mean ayanamsa grows by about 0.138″ a day; the true one adds the rate of
  Δψ, so Lahiri's true ayanamsa moved by −0.016″ to 0.378″ a day in 2026.
- **`houses()`** subtracts the true ayanamsa from the angles, the cusps, the
  Vertex and the East Point. Whole-sign cusps, asked for or as the polar
  fallback, start at the sidereal ascendant's sign, as `siderealChart()`'s
  do. The ARMC and the obliquity are not zodiacal and do not change.
- **`events()`** reads `longitude` as a sidereal longitude and searches the
  body's longitude less the true ayanamsa at each instant it samples.
- **`chart()`** keeps `chart`, `natalChart()`'s tropical chart, and adds
  `sidereal`: the ayanamsa at the chart's instant, the bodies' sidereal
  longitudes, the ascendant, the midheaven, the house system and the cusps,
  each as `siderealChart()` gives it.

All three give the ayanamsa in one shape, `ayanamsa`, in the result's
angular unit: `{ name, mean, nutation, true, subtracted, bound }`. `mean` is
counted along the mean ecliptic of date, `nutation` is the engine's Δψ (IAU
2000B), and `true` is their sum, wrapped into (−180°, 180°]. `subtracted`
says which was subtracted: `"true"` in `ecliptic-true-of-date`, which
`houses()` and `chart()` always use, `"mean"` in `ecliptic-mean-of-date`.
`bound` is the mean ayanamsa's (*Bounds*). Δψ cancels from a sidereal
longitude, so that is the bound a sidereal result adds; `true` read on its
own also differs from IAU 2000A's by the nutation model's difference, up to
0.00394″ (*Frames*).

A caller's ayanamsa is `@zodiacs/engine/vedic`'s `userAyanamsa` in JSON,
`{ name?, epoch, value, rate?, model? }`, and the receipt records it with
every default filled in:

- `name`: a lowercase identifier of at most 64 characters that is not a
  built-in name; `"user"` by default.
- `epoch`: read as `time` is. `{ jd, scale: "tt" }` is Swiss Ephemeris's
  `SE_SIDM_USER` epoch `t0`, and `{ jd, scale: "ut1" }` its epoch with
  `SE_SIDBIT_USER_UT`; an ISO string is UTC on the time basis.
- `value`: the mean ayanamsa at the epoch, degrees, from −360 to 360.
- `rate`: arcseconds a Julian year, from −3600 to 3600. With it the
  ayanamsa grows by that rate, as Raman's and Sri Yukteswar's do.
- `model`: without a rate, the precession model `value` was computed with:
  `"engine"` (IAU 2006, the default), which carries `value` from the epoch,
  as `SE_SIDM_USER` does, or `"newcomb"` or `"iau1976"`, whose zodiac is held
  where that model puts it at J2000.0, as the built-in definitions are.

A caller's ayanamsa carried by precession is computed from an epoch whose TT
is anywhere in `EPHEMERIS_SPAN`, 0001-04-30T12:00 to 3998-09-03T12:00 TT,
the years astronomy-engine tabulates, and refused `epoch-out-of-range` from
one outside it. Outside `CALC_SPAN` the engine's precession and ERFA's part
further, the further the epoch is from J2000.0, and the ayanamsa's bound is
wider (see Bounds). Beyond `EPHEMERIS_SPAN`, where nothing else the engine
computes reaches, they go on parting: 0.0051″ from an epoch a century before
it, 0.35″ from JD 1,000,000, 10.6″ from JD 0.5 and 139° from the first day a
`Date` holds (`docs/evidence/calc-epochs-2026-10-06/`). Before 1.0.0-rc.1
calc refused an epoch outside `CALC_SPAN` itself. A linear ayanamsa is
computed from any epoch whose TT a `Date` can hold: one given on UTC or UT1
within about 2,800 days of a `Date`'s last day throws a `RangeError`, its TT
being later still. Swiss Ephemeris's named modes are not always this engine's
definitions: its Krishnamurti, Raman, Sri Yukteswar, True Pushya and Galactic
Center differ ([vedic.md](vedic.md), *Agreement with Swiss Ephemeris*).

## Centers and corrections

| `correction` | what it is |
| --- | --- |
| `apparent` | on astronomy-engine: light time and aberration: the observer is backdated with the target, as astronomy-engine's `GeoVector` does, which adds the observer's aberration to first order, annual and for a topocentric observer diurnal too, and no gravitational deflection. A geocentric apparent place from the DE440 pack (after `useDe440()`; the default from 1.1.0-rc.10 to 2.1.0) is the pack's instead: light time, the Sun's light deflection (none behind the Sun's disc) and relativistic annual aberration (*Which ephemeris*). |
| `astrometric` | light time only: the target when its light left, from where the observer is when it arrives, on barycentric positions. |
| `geometric` | where the target is at the instant, from where the observer is at the instant. |

- **Geocentric**: the Moon's apparent position keeps the engine's convention,
  its series at the instant without light time or aberration, so that `calc`
  agrees with `positions()` and `natalChart()`. A fully apparent Moon differs
  from it by the light time of the Moon's own motion, about 0.7″. Its
  astrometric position does carry light time.
- **Heliocentric** and **barycentric**: every body but the Sun heliocentric;
  the barycentre is astronomy-engine's, from the Sun and the four giant
  planets, each weighted m / (m + M☉). Scanned daily from 1800 to 2200 it is
  up to 1.26 × 10⁻⁵ au (1,880 km) from the full Newtonian barycentre of the
  same positions, and at most as far from Horizons's where the scan found it
  worst; calc takes 1.4 × 10⁻⁵ au and 1.2 × 10⁻⁷ au a day as its error
  (`RESULTS.md`, Deviation 8). That is small against every body's
  distance but the Sun's. The Sun comes within 1.0 × 10⁻⁴ au of the
  barycentre (2130-03-11), where the error turns its barycentric direction by
  degrees: at 2130-03-05T00:00Z it is 2.66° from Horizons's, and its distance
  1.8% off. The barycentric Sun's bounds are therefore derived from the
  barycentre's error, not measured (see Bounds). The barycentre does not move,
  so a barycentric apparent position is its astrometric one.
- **Topocentric**: the observer's position and velocity on astronomy-engine's
  ellipsoid, turned by the engine's Greenwich apparent sidereal time and taken
  back to the J2000.0 axes by the engine's precession and nutation (the
  arithmetic of astronomy-engine's `ObserverState`, on the engine's own
  models; no polar motion). Light time is solved from the observer.
- **Distances**: `dist` is in au: the light path for apparent and astrometric
  positions (the length of the light-time-corrected vector), the geometric
  distance for geometric ones. The geocentric apparent Moon, being the series
  at the instant, has its geometric distance; the light path is up to 10⁻⁴ of
  it (38 km) longer or shorter, as the Moon moves with the Earth around the
  Sun during the 1.3 s of light time. The nodes and the two Liliths have
  none: `dist` is null and a cartesian position is refused.
- **Nodes and the two Liliths** are geocentric points of the Moon's orbit; the three
  corrections give the same position (`correction:not-applicable` in the
  receipt), and other centers are refused.

## Speeds

`speeds` holds the rate of `lon`, `lat` and `dist` per day, and with
`cartesian` the rates of x, y and z. Every rate is per day of 86,400 s; they
are differenced on the scale the instant was given on, UTC unless a Julian
date names another, which runs slower than TT by under one part in 10⁷;
where a leap second or another step of the time basis lies between the two
samples, the difference is divided by the TT between them, as `positions()`
divides it.

- **Analytic** for geometric positions on fixed axes (the J2000.0 and ICRS
  frames) of every body but the Moon: astronomy-engine's velocities from its
  differentiated VSOP87 series (Pluto: from its integrator), turned into the
  frame. Pluto's integrator velocity differs from the derivative of its
  position by up to 0.00097″ a day.
- **Central difference** everywhere else: the value at t + h minus the value
  at t − h, over 2h, with the engine's steps, h = 0.001 day, and h = 0.25 day
  for the true node, whose short-period motion would otherwise dominate. The
  two instants are built as `positions()` builds them, so for an ISO or
  `Date` instant the longitude speed is its speed to the bit.

The differencing error is h²/6 times the third derivative. Estimated on the
engine alone by Richardson's rule, |D(2h) − D(h)| / 3, it is at most
1.2 × 10⁻⁴″ a day for apparent geocentric positions (the Moon),
3.2 × 10⁻³″ a day for astrometric ones (the Moon again: the light-time
solution stops at a tolerance, which leaves a small jitter in each position)
and 0.094″ a day for the topocentric Moon, whose parallax turns with the Earth
once a day. `bounds.speed` names the method and the step, and gives the
largest rate difference measured against Horizons, which includes the
differencing error. The true node's speed was not compared, so its `value` is
null.

## Bounds

Every position carries `bounds.position` (the angle between the reported
direction and the arbiter's, arcseconds), `bounds.distance` (relative) and
`bounds.speed` (arcseconds a day), each labelled `measured` or `estimated`;
none is proven. Each one's `basis` says which comparison it rests on.

**A position from the shipped DE440 pack** (*Which ephemeris*) quotes none
of the bounds below, which were measured on astronomy-engine. Its
`bounds.position` is the largest angle from JPL Horizons's apparent
geocentric place (DE441) at the conformance suite's 240 L1 vectors, 24 TT
instants a body from 1851 to 2148, in the true ecliptic of date, and from
1.1.0-rc.12 the largest angle from NAIF's `de440.bsp` at noon TT of each of
the 146,097 days from 1800-01-01 to 2199-12-31 in all eight frames (the
dense sweep run on the pack, *Measured against DE440 every day*), the
larger of the two, rounded up to two significant figures: the Moon 0.013″
(Horizons; DE440 and DE441 differ in the Moon), Saturn 0.0039″, every other
body 0.0040″ (`src/calc-bounds-de440.ts`; `src/calc-bounds-de440.test.ts`
recomputes the L1 rows from the vectors and reads the sweep's committed
summary). In 1.1.0-rc.10 and rc.11 the table held the 24 instants alone,
0.0034″ to 0.0038″ for the Sun and the planets; the sweep found up to
0.00395″, the engine's IAU 2000B nutation against ERFA's 2000A in the frames
of date. It is labelled `measured` in the true ecliptic of date and
`estimated` in the seven other frames, where Horizons was not compared.
Within 3″ of the Sun's limb a planet's bound is 1.8″, `estimated`
(`DE440_AT_LIMB`): the pack bends no light behind the Sun's disc, as JPL
Horizons does not, so the place steps at the limb by the deflection there,
at most 1.7512″, and the two edges differ by 0.06″ to 0.17″
([de440.md](de440.md), *Behind the Sun's disc*). Its `bounds.distance` and
`bounds.speed`, and every bound of the true node and its opposite point,
have `value: null` and the basis "not compared with an independent
ephemeris". True Black Moon Lilith's bounds are null on both sources too,
with a basis that says it was compared with JPL Horizons at 12 instants
only: from 1850 to 2150 its longitude is under 1.6″ from the osculating
apogee of Horizons's geocentric Moon state on the pack, and under 400″
(6.7′) on astronomy-engine, whose lunar series' small velocity errors the
eccentricity vector magnifies (`src/true-lilith.test.ts`). The ΔT widening below applies to a position from the pack as to
any other.

**On astronomy-engine** (the other centers and corrections, and every
position where astronomy-engine stands in for the pack): from 1.1.0-rc.7
the geocentric Sun, Moon, Mercury to Pluto (with each of the
three corrections) and the true node and its opposite point take the largest
differences from JPL's DE440 (NAIF's `de440.bsp`) found at noon TT on each of
the 146,097 days from 1800-01-01 to 2199-12-31, in every frame, rounded up to
two significant figures by the same rule: 32 rows,
`docs/evidence/de440-sweep-20261111/` (the section below). Before, those rows
held the 32 instants' values, and the engine was found beyond ten of the
eleven apparent position limits on other days.

Every other row (heliocentric and barycentric positions, and the mean points)
keeps the measured values that follow, 63 rows. They are the
largest differences from NASA JPL
Horizons (DE441) over a preregistered corpus of 32 instants from 1802 to 2188,
by center, correction and body, in every frame, rounded up to two
significant figures: `docs/evidence/calc-api/`. For the mean node, the mean
south node and Black Moon Lilith they are the largest differences, on the
same instants, from the same definitions evaluated with ERFA's fundamental
arguments, which checks the implementation, not an ephemeris; their `basis`
says so. They are the largest seen on
those 32 instants, not limits: another instant can exceed them, as a
broader sample found for the geocentric rows while they held the 32
instants' values (below). They come from
the comparison rerun on this version's build, after the engine took the full
IAU 2000B nutation (`docs/evidence/calc-api/rc16/`); none is larger than the
first run's, and the rate bounds of the outer planets and the position and
rate bounds of the mean node and Lilith, which carried the five-term
nutation's error, are smaller. Topocentric
positions were compared for the Sun, the Moon and Mars, in all three
corrections, on the same 32 instants. The sweep did not take topocentric
places, and a topocentric place is the geocentric one moved by the parallax,
so the geocentric differences carry over. Every topocentric body therefore
takes its geocentric bound for the same correction, labelled `estimated`:
the Sun, the Moon and Mars too, since the geocentric row is at or above each
value of their own 32 instants' rows (9 rows), so their position bounds are
3.4″, 12″ and 23″ in place of the 32 instants' 3.0″, 7.8″ and 6.6″, and
`src/calc-bounds.ts` leaves those rows out. Its generator,
`docs/evidence/de440-sweep-20261111/tools/write_bounds.py`, keeps a
topocentric row only where it is at or above the geocentric one in every
value, and refuses one above in some values and below in others
(`calc-bounds.test.ts` checks each value against both summaries).

The engine's TT and UT1 rest on a ΔT its model extrapolates, with no
observation behind it, after the last day of the IERS UT1 table the release
carries (time.md, *From an instant to UT1 and TT*; for this release, after
2027-10-02T00:00Z, and on UTC input from 00:00:00.147Z, when UT1 passes it),
when ΔT is not pinned. Its 1-σ band `deltaT.sigma` grows
with the years ([time.md](time.md)), and no arbiter gives positions for such
an instant. A result that moves with that ΔT is flagged
`"delta-t-extrapolated"` and its bounds widen by how far each quantity moves,
to first order, while TT and UT1 move by their bands, s and u seconds
(`band.time`); its receipt names `bounds:plus-delta-t-band`, and a widened
bound is labelled `estimated`, its `basis` adding the amount. On UT1 input
TT carries the ΔT, so every result moves with it. On TT input (s = 0,
u = σ) UT1 carries it, so only what turns with UT1 moves: a topocentric
position, the houses and the angles; a geocentric, heliocentric or
barycentric position on TT input keeps its bounds, with no flag. On UTC
input, from 2.0.0-rc.3, TT is UTC + 69.184 s (the
continuous-UTC rule, time.md) and UT1 carries the ΔT, as on TT input
(s = 0, u = σ): every result is still flagged, as before, but only what
turns with UT1 widens. Up to 2.0.0-rc.2, UTC input after the table was
read as UT1 and TT carried the ΔT, so every result widened.

- **`calc()`**: `flags` holds the flag (empty otherwise), and each bound
  grows by: the position's, (Ω + w) s + w u, with Ω the direction's angular
  rate √((λ′ cos β)² + β′²) in arcseconds a second; the speed's,
  (Ω′ + w ω⊕) s + w ω⊕ u, with Ω′ the change of that rate and ω⊕ the
  Earth's rotation; the distance's, (|r′| / r + v / r) s + (v / r) u. Ω, Ω′
  and r′ come from samples 0.001 day (0.25 day for the true node) either
  side, as the speeds do, whether or not speeds were asked for; w and v
  bound a topocentric observer's turn, as in *Bands*, and are 0 for other
  centers. On UTC input s is 0 and u is σ, as on TT input (up to
  2.0.0-rc.2 s was √(0.9² + σ²) and u 0.9 s). For the Moon at
  2199-06-15T12:00Z given on UTC, σ is over 100 s: its geocentric position
  bound does not grow (it grew by between 50″ and 65″ up to 2.0.0-rc.2), and
  the topocentric Moon's grows by w σ alone, as on TT input
  (`src/calc-delta-t.test.ts`). On UT1 input s is σ and u 0, and the
  geocentric Moon's bound grows by between 50″ and 65″. In the sidereal
  zodiac the widening comes on top of the ayanamsa's addition, from the
  sidereal rates.
- **`houses()`**: `flags` holds the flag, on UTC, UT1 or TT input alike, and
  `bounds.angles` grows by the largest of the ascendant's, midheaven's,
  Vertex's and East Point's bands, `bounds.cusps` by the largest cusp band
  (*Bands*). On TT input the ascendant's band is its rate on UT1 times σ:
  over 15 arcminutes at 41.5° N in 2199 (`src/calc-delta-t.test.ts`).
- **`events()`**: `flags` holds the flag where an event's UTC rests on that
  ΔT, and `bounds.timing` grows by the widest such event's `band.utc`: the
  ephemeris fixes an event in TT, so its UTC moves with the band of TT − UTC.
  After the table that band is 0 on the continuous-UTC rule, UTC being
  TT − 69.184 s, so the flag stays and the timing bound does not grow (up to
  2.0.0-rc.2 it grew by about the ΔT band).
- **`chart()`** and `natalChart()`: the chart's `flags` hold it on UTC or UT1
  input, and on TT input where the chart has houses. A chart has no bounds;
  `positions()` returns a bare list of bodies and carries none.

The widening is first order and uses a 1-σ band, so it is not a limit
either: the true ΔT can be further off. It errs wide in two places, kept as
they are. A topocentric place's observer turn is counted on both TT and UT1
(w s + w u) although on UTC input it moves with UT1 alone, and w bounds the
turn in any direction, so a topocentric widening can be several times the
place's actual movement. And on UT1 and TT input the time basis steps where the table ends
(time.md): just before it nothing widens, and just after it the bands are the
model's σ at once. On UTC input the continuous-UTC rule keeps TT on the leap
seconds across the end, so only UT1's band steps, from the table's 26.2 ms to
the model's σ, and the positions' bounds do not jump. Up to 2.0.0-rc.2 the
bands on UTC input were about 0.9 s at once after the end, and within a
sample step of it the speed's Ω′, a second difference across that step, could
come out large, so the bounds there jumped wider than the movement. Before the IERS
table (before 1972) the model's ΔT is reconstructed from observations of the
past, not extrapolated, so nothing is flagged or widened there; its band,
which the model gives, is in `band`.

A broader sample on 2026-11-13 compared the geocentric apparent positions in
the true ecliptic of date with JPL DE421 at 1,711 instants per body from 1900
to 2050 (`docs/evidence/broad-sample-2026-11-13/`). It was read against the
bounds published before 1.1.0-rc.7, the 32 instants' values. Where its largest
difference is above that published bound, the two are:

| Body | Published `bounds.position`, largest seen on 32 instants | Largest on 1,711 instants, 1900 to 2050 | Published `bounds.speed` (angular rate), largest seen on 32 instants | Largest longitude rate difference on 1,711 instants, 1900 to 2050 |
| --- | ---: | ---: | ---: | ---: |
| Moon | 8.3″ | | 1.1″ a day | 1.62″ a day |
| Mercury | 9.3″ | 11.91″ | 2.2″ a day | |
| Venus | 11″ | 20.54″ | 0.64″ a day | 0.667″ a day |
| Mars | 6.6″ | 14.05″ | 0.45″ a day | 0.59″ a day |
| Jupiter | 13″ | 13.86″ | 0.061″ a day | 0.062″ a day |
| Saturn | 18″ | 21.96″ | 0.03″ a day | 0.043″ a day |
| Neptune | 21″ | | 0.013″ a day | 0.015″ a day |
| True node | 16″ | 19.2″ | not compared (`null`) | not compared |

An empty position cell means the broader sample stayed within that published
bound. An empty speed cell means the broader sample's longitude rate stayed
within the published figure; because that is a different metric (see below), it
does not show the angular rate bound holds. The true node has no measured speed
bound (its `value` is null) and its speed was compared in neither sample.

The two speed columns are not the same metric. The published `bounds.speed`
is the largest angular rate difference, hypot(Δ(longitude rate) × cos
latitude, Δ(latitude rate)), on the 32 instants
(`docs/evidence/calc-api/tools/compare.py`). The broader sample measured the
difference in the rate of longitude alone, in arcseconds a day, with no
cos latitude factor and no latitude rate, against a reference without solar
deflection, so its figures are the ephemeris's difference in longitude rate
alone; within about 10° of the Sun the engine's lack of deflection adds more.
Its speed figures show that the published bounds are exceeded in longitude
rate; they are not angular rate maxima. The true node's figure depends on how the reference's
osculating node is defined, which moves it by several arcseconds. The sample
changed no value `calc()` returns. From 1.1.0-rc.7 the geocentric rows in this
table no longer hold the 32-instant maxima: they take the DE440 sweep's values
(above), and each position bound the sweep gives (the last column of the table
in *Measured against DE440 every day*) is at or above the largest position
difference in this table. Their `basis` says which comparison they rest on.

The barycentric Sun is the exception: its error comes from the barycentre,
and its distance from the barycentre, 1.0 × 10⁻⁴ to 0.01 au, decides what
that error does to it, so no sample of instants bounds it. Its bounds are
labelled `estimated` and derived from the barycentre's error, e = 1.4 × 10⁻⁵ au
and ė = 1.2 × 10⁻⁷ au a day, at the reported distance r and speed v: the
direction within asin(e / r), the distance within e / (r − e) of the true
one, and the rate of the direction within ė / r + (v + ė) e (1 / r² +
1 / (r (r − e))), each rounded up to two significant figures. At
2130-03-05T00:00Z that is 27,000″, 0.15 and 3,400″ a day, against 9,593″,
0.018 and 378″ a day from Horizons; far from the barycentre, at 0.0097 au,
it is 300″, 0.0015 and 3.1″ a day.

`houses()` carries the conformance suite's measured L2 bounds, 0.02″ for the
angles and 0.08″ for the cusps (`conformance/RESULTS.md`); `events()` gives the bisection bracket, the
step divided by 2²⁴, as an estimate, to which the ephemeris's own error
divided by the body's speed adds.

In the sidereal zodiac each bound adds the ayanamsa's own: the largest
difference of the engine's mean ayanamsa, and of its rate, from ERFA's
construction of the same definition, rounded up to two significant figures,
over 2,333,979 comparisons from 1800 to 2200
(`docs/evidence/calc-sidereal-2026-10-05/`). They take every star definition
in every year of the span, densely around its pass by the Sun and down to
0.00001 day where either computation's cap on the deflection starts and stops
applying, and callers' ayanamsas at the ends of what calc accepts; and for
a caller's epoch outside 1800 to 2200, 64,974 more, with epochs every 20 years
across `EPHEMERIS_SPAN` (`docs/evidence/calc-epochs-2026-10-06/`). `ayanamsa.bound` gives it, and
`bounds.position` and `bounds.speed` add it, in whole nanoarcseconds rounded
up; a speed bound that is null stays null. A star definition's band is set by
its star's angle from the Sun.

| definitions | comparisons | ayanamsa | its rate |
| --- | ---: | --- | --- |
| linear, from any epoch; and by precession, built-in and callers', from an epoch from 1800 to 2200 | 134,833 | 4.6 × 10⁻⁷″ | 1.6 × 10⁻⁷″ a day |
| a caller's epoch outside 1800 to 2200, on the engine's precession | 21,658 | 0.0037″ | 1.3 × 10⁻⁷″ a day |
| a caller's epoch outside 1800 to 2200, on Newcomb's or IAU 1976's | 43,316 | 1.8 × 10⁻⁵″ | 1.2 × 10⁻⁷″ a day |
| star, 2° or more from the Sun | 306,850 | 0.0013″ | 0.00039″ a day |
| star, 0.3° to 2° from the Sun | 238,364 | 0.0048″ | 0.026″ a day |
| star, within 0.3° of the Sun | 1,653,932 | 0.058″ | 27″ a day |

An epoch's 1800 to 2200 is read on TT, from 1800-01-01T00:00 TT up to
2200-01-01T00:00 TT, the second excluded, as `CALC_SPAN`'s is. An epoch
outside 1800 to 2200 is not an instant: calc still computes only
instants inside `CALC_SPAN`, and the comparison takes them across it. On the
engine's precession the difference grows with the epoch's distance from
J2000.0, to 0.0037″ from the first epoch of `EPHEMERIS_SPAN` at an instant in
1800; on Newcomb's or IAU 1976's precession, whose zodiac is held at J2000.0,
most of the engine's difference from ERFA cancels, and what is left is up to
1.8 × 10⁻⁵″.

For an epoch or linear definition the rate's difference is rounding: for an
epoch definition, the two programs' in their precession and the engine's in
adding the value; for a linear one, the engine's alone, at most one and a
half units in the last place of a value below 512° over the 0.002 day of the
difference, 1.535 × 10⁻⁷″ a day. A search found a definition and instant
within one per cent of that, and the comparison includes it. These are
differences of the ayanamsa at the same two instants. A speed in calc adds
rounding of its own: in each instant's Terrestrial Time, in the nutation the
true ayanamsa adds, and in subtracting the ayanamsa from the longitude. For a
linear ayanamsa at 3,600″ a year, within calc's span, that is at most about
4.5 × 10⁻⁷″ a day, so the ayanamsa's rate in calc's speeds, the tropical
speed less the sidereal, can be up to about 6 × 10⁻⁷″ a day from the
definition's; the largest found is 3.5 × 10⁻⁷″ a day. No bound includes it;
the smallest speed bound calc gives is 8.1 × 10⁻⁴″ a day.

The engine and ERFA deflect a star's light by the Sun with the same formula,
and both cap its denominator at the same small number, which only True
Pushya's star reaches, within about 0.08° of the Sun's centre. Their Earth
positions differ slightly, by an amount that changes from year to year, so
they put the star at slightly different angles from the Sun. The deflection,
and still more its rate, grows so fast as that angle falls that the
difference grows with it, and where the cap starts and stops applying the two
computations do so at instants a little apart: there their rates part by up
to 27″ a day. How far apart they come changes from one pass to the next,
which is why every year is compared. Within 0.3° the star is on or beside the
Sun's disc, whose radius is about 0.27°. The bound says how far
apart the two computations of the same definition are, not that such a star
is seen. It is against this engine's definition, not another program's:
definitions differ between programs by far more.

## Bands

Every result also carries `band`, from 1.1.0-rc.2: how far it moves, to first
order, when the TT and the UT1 of its instant move by their 1-σ bands. Those
two come from the bands the instant records, `deltaT.sigma` and
`timeScale.ut1MinusUtc.sigma`, by the rule of [time.md](time.md), *The time
bands* (`timeBands` in `@zodiacs/engine/time`), and every band gives them as
`time: { tt, ut1 }`, in seconds. A band is not a bound on the error, and not
an error. It
leaves out the ephemeris's error, which `bounds` gives, the input time's own
uncertainty, how far a civil time before 1972 was from UT1, and terms of the
second order, and it is as good as the σ it comes from (time.md says what each
is). It is kept apart from `bounds`, whose values are the largest differences
from an arbiter, labelled measured or estimated; `events()`'s `bounds.timing`
is the bisection bracket. For a result flagged `"delta-t-extrapolated"`
(*Bounds*), though, `bounds` already include the time term, widened by these
bands, so do not add `band` to `bounds`: that counts it twice.

- **`calc()`**: `band` is `{ time, lon, lat, dist }`, and null without
  speeds. A geocentric, heliocentric or barycentric position, a node and
  Lilith move with TT alone, so `lon` and `lat` are their speeds times the
  TT band, in arcseconds (degrees a day × `tt` / 24), and `dist` the
  distance's rate times it, in au (au a day × `tt` / 86,400), null where
  `dist` is. `lon` is the band of the frame's longitude, or of the right
  ascension in an equatorial frame. Under `units: "radians"` the band stays
  in arcseconds. A speed is per day of the input's scale, which the band takes
  as a rate on TT; in the sidereal zodiac it is the sidereal longitude's, so
  the ayanamsa's own rate is in the band. A topocentric position also turns
  with the observer, and the observer turns with UT1, while its speed is the
  rate with both scales moving together. Its band adds rates that are at
  least those at which the observer's turn moves it: w = ω (a + h⁺) /
  (dist (1 − 10⁻³)) radians a second in direction and v = ω (a + h⁺) km a
  second in distance, with ω = 7.292115 × 10⁻⁵ rad/s and a = 6,378.1366 km,
  the constants of the engine's observer (`src/calc-reduce.ts`), h⁺ the
  height when it is above the ellipsoid and 0 below it, and dist the reported
  distance in km. a + h⁺ is at least the site's distance from the Earth's
  axis at any latitude, and
  the 10⁻³ covers the difference between the reported light path and the
  length of the apparent vector. So, with each speed in arcseconds or au a
  second and w in arcseconds a second, `lon` = (|speed| + w / cos lat) `tt` +
  (w / cos lat) `ut1`, `lat` = (|speed| + w) `tt` + w `ut1`, and `dist` =
  (|speed| + v) `tt` + v `ut1`, with v in au a second. The two terms are
  summed, which is at least their root sum of squares, whatever the
  correlation of the two bands. Two kinds of position are exceptions to
  "first order". A topocentric position's band is a conservative bound on
  how far it moves to first order, at or above that movement rather than
  equal to it (`src/calc.test.ts` holds it at or above the partials on TT and
  UT1 taken from pinned evaluations). And the true nodes' speed is a
  difference over ±0.25 day (*Speeds*), which smooths their short-period
  motion, so their band is that smoothed speed times the TT band, not how far
  they move when TT moves by its band.
- **`houses()`**: `band` is `{ time, asc, mc, vertex, eastPoint, cusps }`,
  in arcseconds. The angles and cusps turn with UT1, through the Earth
  rotation angle, and move with TT, through the precession and the nutation in
  the sidereal time, the obliquity and, in the sidereal zodiac, the ayanamsa.
  Each one's band is its rate on UT1 times the UT1 band plus its rate on TT
  times the TT band. The rate on UT1 is its difference with the sidereal time
  moved by ±1 s of UT1 (±1.00273781191135448 / 3,600 hour), the latitude and
  the obliquity held fixed, divided by 2 s; the rate on TT is its difference
  with TT moved by ±600 s and UT1 held, divided by 1,200 s; each difference is
  wrapped into (−180°, 180°]. Where the TT band is 0 the rate on TT is not
  taken. The 600 s is long against the rounding of an angle and Placidus's
  settling to 1e-9°, and short against the nutation's periods and the
  ayanamsa's motion, a star's near the Sun included:
  `docs/evidence/1.1.0-rc.2-20261102/time-bands/tt-step.json` compares it with
  steps from 1 s to a day, on synthetic instants and places, by pinning ΔT.
  The rate on TT is small against the turn of the Earth for most angles, but
  not where an angle's rate on UT1 is small, as for the Vertex near the
  equator. Whole-sign cusps, and the cusps where Placidus or Koch falls back
  to whole signs, are sign starts, with band 0: a difference across a change
  of the ascendant's sign would give 30°. Placidus and Koch fall back where
  the latitude is 90° − ε or more from the equator, and the obliquity ε moves
  with TT: where TT moved by 600 s one way would make them fall back and the
  instant does not, a cusp's rate on TT is the one-sided difference between
  the instant and TT moved the other way, over 600 s; where both ways would,
  the cusps take no rate on TT. The angles do not fall back and keep the
  central difference. Inside the polar circle a cusp that turns with the
  ascendant can jump, and a difference across a jump gives a large band,
  which says that the cusp is not determined better than that there. In the
  sidereal zodiac the rate on UT1 is the tropical one, because the ayanamsa
  moves with TT alone, and the rate on TT is the sidereal longitude's, the
  ayanamsa's own rate in it; so the two zodiacs' bands are the same where the
  TT band is 0, and differ where it is not.
- **`events()`**: each event's `band` is `{ utc, ut1 }`, in seconds. The
  ephemeris fixes an event in TT, so its `jdTt` has no band, and only its
  clock labels move: `utc` is the band of TT − UTC at the event (0 on the
  IERS basis and, after the table, on the continuous-UTC basis; the ΔT band
  before 1972; √(u² + d²) on the `delta-t` basis after the table, up to
  2.0.0-rc.2) and `ut1`
  that of TT − UT1, the ΔT band there. An event's band is computed from its
  own `at`, not from the window's instants that the receipt records. The
  receipt names `time-band:first-order` whether or not the search finds an
  event; only the events carry bands.
- **`chart()`**: `band` is `{ time, bodies, asc, mc }`: each of the chart's
  bodies' longitude band, its speed times the TT band, in arcseconds, and the
  ascendant's and the midheaven's, as `houses()` gives them for the chart's
  place in the tropical zodiac, null without angles. It describes `chart`, the
  tropical chart: in the sidereal zodiac `sidereal`'s longitudes also move by
  the ayanamsa's rate times the TT band, which it leaves out. It gives no cusp
  bands; `houses()` does.

The bands step where the time basis steps (time.md). The consequence to keep
in mind: **on UTC input from 1972-01-01 to 2027-10-02 without a pinned ΔT,
TT comes from the leap seconds, so every geocentric, heliocentric and
barycentric position's band is 0, and so are a chart's bodies'**. TT comes
from them exactly up to 2027-06-28, when the shipped leap-second list
expires; after it the list's last value is carried, and no band is added for
a leap second not yet announced (time.md). The time basis's band then
appears only in the angles and cusps, through their rate on UT1, in
topocentric positions and in each event's UT1. With a pin on UTC input, TT
is UT1 plus the pin and takes UT1's band (time.md), so the positions have
one too. A band that the rule makes zero is exactly 0.

Bands are confined to this entry point. The root's `positions()` and
`natalChart()`, natal envelopes, and the events of `@zodiacs/engine/sky`,
`@zodiacs/engine/timing` and the root's crossing search carry none; theirs
follow from the fields they record: `timeBands(chart)` for the instant, and a
body's speed times the TT band. A reader can recompute every band here: the
instant's from the receipt's instant, a position's from the result's own
speeds, distance and latitude, an angle's by repeating the request (with ΔT
pinned at the recorded value ± 600 s on the instant's UT1 for its rate on TT,
and at the recorded value too where one side falls back), and an event's from
its `at`. Receipts with clock bands name `time-band:first-order` last.
All three searches include it even when they find no events.

## Refusals

A refusal is `{ status: "refused", reason, detail }`, the `status` and
`reason` words of the engine's crossing search:

| `reason` | when | extra fields |
| --- | --- | --- |
| `not-in-this-version` | gravitational deflection | |
| `unsupported-combination` | the Sun heliocentric; the Earth geocentric or topocentric; a node or Lilith with a center other than geocentric, or with `cartesian`; the sidereal zodiac in a frame other than the two ecliptics of date; crossings of a body `positions()` does not give; a pinned ΔT for any event search | |
| `epoch-out-of-range` | a caller's ayanamsa carried by precession from an epoch whose TT is outside `EPHEMERIS_SPAN`, 0001-04-30T12:00 to 3998-09-03T12:00 TT (the span includes its ends) | `epochSpan`, the root's `EPHEMERIS_SPAN` |
| `out-of-range` | an instant whose UT1 or TT is outside `CALC_SPAN`, 1800-01-01T00:00Z up to 2200-01-01T00:00Z, where the positions have been compared with an independent ephemeris | `span` |
| `sample-budget` | an event search that needs more evaluations than `maxSamples` | `samples`, `maxSamples` |

The checks run in that order: a request with both an epoch outside
`EPHEMERIS_SPAN` and an instant outside `CALC_SPAN` is refused for its epoch.
The span is checked on both time scales, so a
ΔT pin cannot move the ephemeris outside it, and with the engine's ΔT the
last instant computed on UTC input is 2199-12-31T23:58:50.815Z, whose TT is
69.184 s later (up to 2.0.0-rc.2, 2199-12-31T23:57:53.752Z, read as UT1;
`docs/evidence/continuous-utc-20261117/results/span-ends-*.json`). `natalChart()`
still computes outside the span, with the `outside-reference-span` flag, as
it always has, and so does `positions()`, whose rows carry the flag from
2.0.0 (1.1.0's rows carried none). calc refuses instead
because every result it returns carries a bound, and outside the span there
is no comparison to take one from.

## Receipts

`receipt` is `{ schema, request, instants, conventions, engine }`:

- `request`: the request as read, every default filled in, as JSON. Passing it
  back to the same function repeats the calculation.
- `instants`: each instant used, `{ utc, jdUt1, jdTt, deltaT, timeScale }`:
  its UTC to the millisecond (before 1972, and up to 2.0.0-rc.2 after the IERS
  table, the civil time read as UT1; after the table now TT − 69.184 s), its UT1 and TT as Julian dates, the ΔT value with its
  band and its source, and the time basis's record, as a chart's `timeScale`
  gives it.
- `conventions`: ids from the vocabulary below; every receipt but that of
  `calc()` without speeds names `time-band:first-order` last, `events()`'s
  even when it finds no event. A `calc()`, `houses()` or `events()` receipt
  whose bounds were widened for an extrapolated ΔT names
  `bounds:plus-delta-t-band` (*Bounds*). No codec parses a calc receipt; a
  reader repeats its request, which gives the flag again.
- `engine`: the package version and the ephemeris.

### Convention ids

| id | meaning |
| --- | --- |
| `zodiac:tropical` | longitudes from the equinox of the frame |
| `zodiac:sidereal` | longitudes from the ayanamsa's sidereal zero point: the longitude in the ecliptic of date less the true ayanamsa (true equinox) or the mean one (mean equinox) |
| `ayanamsa:<name>` | a built-in ayanamsa, `ayanamsa:lahiri` to `ayanamsa:galactic-center`, as [vedic.md](vedic.md) defines it |
| `ayanamsa:user-epoch`, `ayanamsa:user-linear` | a caller's ayanamsa, carried by precession or by a rate; the receipt's request holds it |
| `frame:<frame>` | one of the eight frames above |
| `center:geocentric`, `center:heliocentric`, `center:barycentric`, `center:topocentric` | the origin |
| `correction:apparent`, `correction:astrometric`, `correction:geometric` | as above; `correction:not-applicable` for the nodes and Lilith |
| `light-time:newtonian` | astronomy-engine's light-time solution, iterated until successive light times agree to 10⁻⁹ day |
| `light-time:iterated` | on the DE440 pack: light time by iteration on the pack's states, at most 12 steps, to 10⁻¹¹ s |
| `deflection:sun-outside-disc` | on the DE440 pack, from 1.1.0-rc.12: the Sun's gravitational light deflection (the form of ERFA's `eraLd`), none for a planet behind the Sun's disc, as JPL Horizons; 1.1.0-rc.10 and rc.11 wrote `deflection:sun`, the deflection behind the disc too |
| `aberration:relativistic-annual` | on the DE440 pack: relativistic annual aberration from the Earth's barycentric velocity |
| `target:system-barycentre` | on the DE440 pack: Mars to Pluto are planetary-system barycentres, not planet centres |
| `place:icrf-to-true-ecliptic-of-date`, `frame-bias:iau2006-fukushima-williams`, `nutation:iau2000b-p03`, `time:tdb-three-term` | on the DE440 pack: the place is carried from the ICRF to the true ecliptic of date by the IAU 2006 Fukushima-Williams angles, frame bias included, and IAU 2000B nutation with the P03 adjustment, at a TDB formed from TT by three terms ([de440.md](de440.md), *The reduction*) |
| `frame-turn:from-true-ecliptic-of-date` | on the DE440 pack, in a frame other than the true ecliptic of date: the pack's place of date, turned into the frame with the engine's own nutation and precession |
| `ephemeris:jpl-de440@<SHA-256>` | the shipped DE440 pack, named by its digest |
| `aberration:backdated-observer` | first-order aberration from backdating the observer with the target |
| `deflection:none` | no gravitational light deflection |
| `moon:series-at-instant` | the engine's Moon: astronomy-engine's lunar series at the instant, without light time or aberration |
| `precession:iau2006` | Capitaine et al. (2003) angles ψA, ωA, χA as astronomy-engine applies them to EQJ, without a frame bias; named in every frame for the nodes and Lilith, which are found in the ecliptic of date |
| `nutation:iau2000b` | the engine's IAU 2000B nutation (McCarthy and Luzum 2003): all 77 luni-solar terms and the two fixed planetary offsets (see Frames) |
| `obliquity:iau2006` | the IAU 2006 mean obliquity (84381.406″ at J2000.0), with the nutation in obliquity for a true-of-date frame; named in every frame for the nodes and Lilith |
| `frame-bias:iau2000` | the IAU 2000 frame bias of the ICRS (IERS Conventions 2010, eq. 5.21) |
| `barycentre:sun-and-giant-planets` | astronomy-engine's solar-system barycentre |
| `observer:iers2003-ellipsoid;no-polar-motion` | the topocentric observer as above |
| `node:true-osculating`, `node:mean`, `lilith:mean` | the Moon's osculating node from its state vector; its mean node (IERS 2003 Ω plus the nutation in longitude); its mean apogee |
| `lilith:true-osculating` | from 3.0.0, True Black Moon Lilith: the apogee of the two-body orbit of the geometric geocentric Moon's state vector, along −e with e = (v × h) / μ − r / \|r\| and μ = 398,600.4418 + 4,902.8001 km³/s², carried from EQJ to the true ecliptic of date as a body is, without the frame bias; on the DE440 pack, from the pack's Moon state at TDB (`time:tdb-three-term`) |
| `speed:analytic`, `speed:central-difference-0.001d`, `speed:central-difference-0.25d` | how the speeds were found |
| `ephemeris:astronomy-engine@2.1.19` | the ephemeris: truncated VSOP87 for the planets, a lunar series after Brown's theory (Montenbruck and Pfleger), an integrated Pluto |
| `deltat:time-basis`, `deltat:pinned` | ΔT from the time basis (`iers-utc/1` from 1972-01-01 to the end of the IERS table, `zodiacs-deltat/1` outside it; each instant's `deltaT.model` says which), or the caller's value |
| `time:tt-from-leap-seconds-and-ut1-from-iers-1972-to-table-end;delta-t-model-otherwise` | the time basis above, as the natal receipt's time-basis set names it ([time.md](time.md)), for a receipt whose instants all lie on or before the end of the IERS table (2027-10-02) or carry a pinned ΔT |
| `time:tt-from-leap-seconds-and-ut1-from-iers-1972-to-table-end;tt-utc-plus-69.184s-and-ut1-from-delta-t-model-after;delta-t-model-before-1972` | the continuous-UTC rule ([time.md](time.md)), as the natal receipt's continuous-UTC sets name it: from 3.0.0, for a receipt with any instant on the `continuous-utc` basis, after the IERS table |
| `house:<system>`, `polar-fallback:whole` | the house system asked for, and whole sign where Placidus or Koch is undefined |
| `angles:gast-and-true-obliquity`, `sidereal-time:gast-iau2006-era` | the angles from the engine's apparent sidereal time (the Earth rotation angle, astronomy-engine's IAU 2006 polynomial, and the equation of the equinoxes: Δψ cos εA and the two largest IAU 2000 complementary terms) and the true obliquity |
| `aspects:major`, `search:scan-and-bisect` | the chart's major aspects; the crossing search |
| `bounds:plus-delta-t-band` | `calc()`'s, `houses()`'s or `events()`'s bounds widened for a ΔT extrapolated past the IERS table, by how far each quantity moves while TT and UT1 move by their bands (*Bounds*) |
| `time-band:first-order` | the result carries bands from the time basis (*Bands*): each instant's TT and UT1 bands by the rule of [time.md](time.md)'s *The time bands*, read from the instant's recorded basis: after the IERS table on UTC input, on the `continuous-utc` basis 0 for TT and the ΔT band for UT1, and on the `delta-t` basis that releases up to 2.0.0-rc.2 recorded there the root of the sum of the squares of the two recorded bands for TT; propagated to first order, a position's rates times the TT band, with the observer's turn bounded for a topocentric one, an angle's or cusp's rates on UT1 and on TT times those bands, with whole-sign and fallback cusps 0, and an event's clock labels |

## Swiss Ephemeris `calc_ut` flags

Swiss Ephemeris is the reference implementation most astrology software uses.
This table maps each `swe_calc_ut` flag to its counterpart here. The engine
uses no Swiss Ephemeris code, data or output.

| flag | meaning in Swiss Ephemeris | here | status |
| --- | --- | --- | --- |
| `SEFLG_SPEED` | compute speeds | `flags.speeds` | supported, on by default |
| `SEFLG_HELCTR` | heliocentric; Swiss Ephemeris then applies no aberration and no deflection | `center: "heliocentric"` with `flags.correction: "astrometric"` (`"geometric"` with `SEFLG_TRUEPOS`) | supported; the default correction here, apparent, adds the aberration of the Sun's motion, which Swiss Ephemeris leaves out |
| `SEFLG_BARYCTR` | barycentric, with no aberration and no deflection as for `SEFLG_HELCTR` | `center: "barycentric"`, where apparent and astrometric coincide | supported, on astronomy-engine's barycentre |
| `SEFLG_TOPOCTR` (with `swe_set_topo`) | topocentric | `center: { topocentric: { latitude, longitude, height } }` | supported |
| `SEFLG_TRUEPOS` | geometric position | `flags.correction: "geometric"` | supported |
| `SEFLG_NOABERR` | no aberration | `flags.correction: "astrometric"` | supported; there is never deflection here |
| `SEFLG_NOGDEFL` | no gravitational deflection | on astronomy-engine, the default from 3.0.0, always so (or with another correction); on the DE440 pack, after `useDe440()`, the apparent place has the Sun's deflection and no flag removes it | partly: astronomy-engine's places have none; `flags.deflection` asks for deflection and `true` is refused (`not-in-this-version`) |
| `SEFLG_ASTROMETRIC` | `NOABERR` and `NOGDEFL` | `flags.correction: "astrometric"` | supported |
| `SEFLG_NONUT` | mean equinox of date | `frame: "ecliptic-mean-of-date"` or `"equatorial-mean-of-date"` | supported |
| `SEFLG_J2000` | J2000.0 | `frame: "ecliptic-j2000"` or `"equatorial-j2000"` | supported |
| `SEFLG_ICRS` | skip the frame bias; precession and nutation still follow unless `SEFLG_J2000` or `SEFLG_NONUT` | with `SEFLG_J2000`: `frame: "ecliptic-icrs"` or `"equatorial-icrs"` | supported with `SEFLG_J2000`; alone, not offered: the of-date frames here are precessed from J2000.0, as Swiss Ephemeris's are without the flag |
| `SEFLG_EQUATORIAL` | right ascension and declination | `frame: "equatorial-…"` | supported |
| `SEFLG_XYZ` | cartesian coordinates | `flags.cartesian: true` (given beside `lon`, `lat`, `dist`) | supported |
| `SEFLG_RADIANS` | radians | `flags.units: "radians"` | supported |
| `SEFLG_SIDEREAL` (with `swe_set_sid_mode`) | sidereal zodiac | `zodiac: { sidereal: ayanamsa }`, an ayanamsa by name, or `{ epoch, value, rate?, model? }` for `SE_SIDM_USER` | supported in the two ecliptics of date (see *The sidereal zodiac*); with `SEFLG_NONUT`, `frame: "ecliptic-mean-of-date"`; the projections `SE_SIDBIT_ECL_T0` and `SE_SIDBIT_SSY_PLANE` are not offered |
| `SEFLG_TROPICAL` | tropical zodiac | `zodiac: "tropical"` | supported, the default |
| `SEFLG_SWIEPH`, `SEFLG_JPLEPH`, `SEFLG_MOSEPH` | which ephemeris | none per call: the module's default source, astronomy-engine or, after `useDe440()`, the shipped DE440 pack (*Which ephemeris*), named in every receipt | not offered as a flag; none of Swiss Ephemeris's files is read |
| `SEFLG_SPEED3` | speeds from three positions | none | not offered; speeds are analytic or central differences |
| `SEFLG_DPSIDEPS_1980`, `SEFLG_JPLHOR`, `SEFLG_JPLHOR_APPROX` | IAU 1980 nutation corrections, Horizons's frame | none | not offered; the nutation is IAU 2000B |
| `SEFLG_CENTER_BODY` | a planet's centre, not its system barycentre | none | not offered; Mars to Pluto were compared with system barycentres (see Bodies) |

`swe_calc_ut` takes a UT1 Julian date and `swe_calc` a TT one; here they are
`{ jd, scale: "ut1" }` and `{ jd, scale: "tt" }`. `swe_set_delta_t_userdef(dt)` is the `deltaT` pin, but `dt`
is in days and `deltaT` in seconds: `deltaT` = 86,400 × `dt`. Its bodies
map to `CalcBody` as `SE_SUN` to `SE_PLUTO` by name, `SE_EARTH` to `"Earth"`,
`SE_TRUE_NODE` to `"North Node"`, `SE_MEAN_NODE` to `"Mean Node"` and
`SE_MEAN_APOG` to `"Black Moon Lilith"`; from 3.0.0 the osculating apogee,
`SE_OSCU_APOG`, corresponds to `"True Black Moon Lilith"`, which was compared
with JPL Horizons and not with Swiss Ephemeris (on astronomy-engine's lunar
series it is under 6.7′ from the apogee of Horizons's Moon at 12 instants,
on the DE440 pack under 1.6″). From 3.0.0 Chiron, Ceres, Pallas, Juno and
Vesta (`SE_CHIRON`, `SE_CERES`, `SE_PALLAS`, `SE_JUNO`, `SE_VESTA`) are in
`@zodiacs/engine/minor-bodies`, from tables fitted to JPL Horizons, not in
`calc()`: `minorBodyPosition(chiron, time)` gives one body's apparent
geocentric place in the true ecliptic of date, from 1800 to 2200 TT, on the
same default source, and at 500 places from Horizons that the fit never saw
it is within 0.54″ after `useDe440()` and 1.7″ on astronomy-engine
(`src/minor-bodies.test.ts`; [guide.md](guide.md), *Minor bodies*). The flags Swiss Ephemeris returns,
which say what it actually computed, correspond to the receipt's conventions,
and its error returns to the typed refusals.

## Measured against DE440 every day

`docs/evidence/de440-sweep-20261111/` compares `calc()` with NAIF's
`de440.bsp` (SHA-256 `a4ce9bf9…c4b5`) at noon TT on each of the 146,097 days
from 1800-01-01 to 2199-12-31, geocentric, in all eight frames, for the Sun,
the Moon, Mercury to Pluto (Mars to Pluto as system barycentres, on both
sides) with each correction, and the true node and its opposite point. The
reference is formed from the kernel with ERFA, as the Horizons comparison
turns Horizons's vectors; astronomy-engine's apparent places are compared
with a place without the Sun's light deflection, as astronomy-engine
computes them (a run on the pack, from 1.1.0-rc.11, with the deflection,
and from 1.1.0-rc.12 none behind the Sun's disc, as Horizons; below). It
ran in GitHub Actions (`PLAN.md`,
`README.md`, `results/`). The largest differences, apparent places, in
arcseconds, and the position bound each gives, beside the 32 instants':

| body | ecliptic longitude of date | angle, any frame | bound from 32 instants | bound from the sweep |
| --- | ---: | ---: | ---: | ---: |
| Sun | 2.39 | 3.34 | 3.0 | 3.4 |
| Moon | 11.92 | 11.88 | 8.3 | 12 |
| Mercury | 14.12 | 16.92 | 9.3 | 17 |
| Venus | 22.92 | 23.32 | 11 | 24 |
| Mars | 14.32 | 22.92 | 6.6 | 23 |
| Jupiter | 10.64 | 16.81 | 13 | 17 |
| Saturn | 13.10 | 23.22 | 18 | 24 |
| Uranus | 12.09 | 19.65 | 20 | 20 |
| Neptune | 19.71 | 21.28 | 21 | 22 |
| Pluto | 29.19 | 29.86 | 25 | 30 |
| True node | 32.64 | 32.64 | 16 | 33 |

The first two columns are rounded up to 0.01″ from the sweep's
`results/tables.md`. The true node's bound, 33″, is over 30″, so a statement
that positions agree with DE440 to within 30″ covers the Sun, the Moon and
the planets only. Pluto's largest difference is on the last day of the span
and still growing, 0.81″ under 30″ in longitude and 0.14″ in angle, and the
statement holds for no day outside the span. These are the largest found at
one instant a day: another instant can exceed them.

The sweep measured 1.1.0-rc.3's build. 1.1.0-rc.7 computes the same
positions: its sources differ from 1.1.0-rc.3's only in local-time
resolution, receipts, the version and the bounds, none of which a geocentric
position reads, and the sweep's workflow, run again on 1.1.0-rc.7's build,
checks every largest difference against the bounds the build quotes
(`docs/evidence/1.1.0-rc.7-20261111/`).

These rows are the bounds of astronomy-engine's results: on the shipped
DE440 pack (the default from 1.1.0-rc.10 to 2.1.0, and from 3.0.0 after
`useDe440()`), `calc()` quotes
`src/calc-bounds-de440.ts` instead (*Which ephemeris*). The sweep's engine
side ran `calc()` at its default, so on 1.1.0-rc.10 it measured the pack's
apparent places against these limits and against an arbiter without the
light deflection the pack applies, and the workflow failed (run
43618467433). From 1.1.0-rc.11 it names the source (`engine_sweep.mjs
--ephemeris`) and the workflow sweeps astronomy-engine; run so on
1.1.0-rc.10's head, the engine's values are the same bytes as 1.1.0-rc.3's
in all eight eras and every row is within its limit
(`docs/evidence/1.1.0-rc.11-20261115/sweep/`).

From 1.1.0-rc.12 the workflow sweeps the pack too, `calc()`'s default until
2.1.0 (`engine_sweep.mjs --ephemeris de440`), against the kernel's apparent place
with the Sun's light deflection (`erfa.ld` with `erfa.ldsun`'s limiter, and
none for a planet behind the Sun's disc, as Horizons), and its job *Sweep
results on the DE440 pack* holds every body's largest angle over all
instants and frames to `src/calc-bounds-de440.ts` (`tools/check_pack.py`);
it runs when the reduction or either table changes. On this build, at the
146,097 instants: the Moon 0.0045″ and every other body 0.0040″, rounded
up (0.004422″, and 0.003898″ to 0.003948″), near the Sun too, where 1.1.0-rc.11 was up to
17.308″ (`docs/evidence/1.1.0-rc.12-20261115/sweep-pack/`). The pack's
bounds take these, rounded up, where they are above the 24 Horizons
instants' (*Bounds*).

## Measured against JPL Horizons and ERFA

`docs/evidence/calc-api/` holds the preregistration, the Horizons requests and
responses with their SHA-256, the scripts, and the results of the first run,
on astronomy-engine's five-term nutation (`RESULTS.md`, `results/`);
`rc16/` holds the same comparison rerun unchanged on this version's build,
with the engine's IAU 2000B nutation. The angle between the engine's
direction and Horizons's, over 32 instants from 1802 to 2188, in arcseconds,
median / 95th percentile / maximum, the bodies pooled, from the rerun:

| center, correction | ICRS equator | true ecliptic of date | largest relative distance difference |
| --- | --- | --- | ---: |
| geocentric, apparent (10 bodies) | 3.00 / 15.5 / 24.6 | 3.00 / 15.5 / 24.6 | 1.3 × 10⁻⁴ |
| geocentric, astrometric or geometric | 2.88 / 15.5 / 24.6 | 2.88 / 15.5 / 24.6 | 6.7 × 10⁻⁵ |
| heliocentric (10 bodies) | 2.95 / 16.4 / 24.3 | 2.95 / 16.4 / 24.3 | 8.6 × 10⁻⁵ |
| barycentric, the Sun (its bounds are derived, see Bounds) | 87 / 340 / 519 | 87 / 340 / 519 | 4.1 × 10⁻³ |
| barycentric, the other 10 bodies | largest 24.3 | largest 24.3 | 7.7 × 10⁻⁵ |
| topocentric, each correction (Sun, Moon, Mars; two sites) | 1.29 / 5.60 / 7.70 | 1.29 / 5.60 / 7.70 | 5.7 × 10⁻⁵ |

To the last digit shown, every frame gives the same figures: the frames of
date now differ from Horizons's turned by ERFA's IAU 2006/2000A chain only by
IAU 2000B's own difference from IAU 2000A, under 0.0023″ here. The first run's
true-of-date figures differed from the others in the last digit, by the
five-term nutation. The differences are the ephemeris's own: largest for the
outer planets (Pluto 24.6″, Neptune 20.1″, Uranus 19.5″, Saturn 17.6″
geocentric at worst on these 32 instants), 2.9″ for the Sun and 8.3″ for the
Moon. Geocentric angular rates differ from Horizons's by 0.03″ a day median
and 2.1″ a day at worst (Mercury) on these 32 instants. For Jupiter to Pluto
the largest rate difference on them is 0.013″ (Neptune) to 0.060″ a day
(Jupiter) in every frame; on the five-term nutation it was up to 0.082″ a day
in the true-of-date frames (Neptune's 0.051″ against 0.013″ in the other
frames). The broader DE421 sample of 1,711 instants per body from 1900 to 2050
finds more for some bodies: Saturn 21.96″, Venus 20.54″, Mars 14.05″,
Jupiter 13.86″ and Mercury 11.91″, and longitude rate differences up to
0.043″ a day for Saturn, 0.062″ for Jupiter and 0.015″ for Neptune, a
different metric from the angular rates above (see Bounds).

The frame transforms were checked against ERFA 2.0.1 on the engine's own
output, and all twelve checks pass on this version's build. Those without
the nutation agree to better than a microarcsecond: spherical against
cartesian, the frame bias, the IAU 2006 precession, and the equator against
the ecliptic in the mean-of-date, J2000.0 and ICRS frames. The four checks
through the nutation, which the first run failed by up to 0.20″ on
astronomy-engine's five-term nutation, pass their preregistered 5 mas
tolerance: at most 0.0023″, IAU 2000B's difference from ERFA's IAU 2006/2000A.
The mean node and Lilith agree with their definitions evaluated on ERFA's
fundamental arguments to under 10⁻⁶″ in the frames without the nutation, and
to 0.0023″ in the true-of-date frames, where ERFA's definition takes IAU
2000A's nutation (0.2″ on the five-term nutation); the true node is 6.6″ median and 16″ at worst from the node of the
osculating orbit of Horizons's Moon on the 32 instants, and up to 19.2″ on the
broader sample's 1,711, a figure that depends on how the reference node is
defined.
