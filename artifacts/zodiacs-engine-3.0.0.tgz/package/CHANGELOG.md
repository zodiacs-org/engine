# Engine changelog

## 3.0.0 (cut 2026-11-27)

A major release, cut on 2026-11-27 on 2.1.0 (main at `7aeb1086`). It is
published only by the owner; `artifacts/README.md` records what happens to
it. Callers moving from 2.x should read
[What 3.0.0 changes](docs/guide.md#what-300-changes). Sizes below are
measured on this build (`docs/evidence/3.0.0-20261127/`); bundles are
esbuild 0.27.7 browser bundles of an application, minified, then gzipped at
level 9 by the zlib of the official Node 22.22.2 build.

### Breaking changes

- **The root computes on astronomy-engine by default.** From 1.1.0-rc.9 to
  2.1.0 the root loaded the sealed DE440 pack on import and computed on it.
  From 3.0.0 the root's import graph holds neither the DE440 reader nor the
  pack, and a plain call gives astronomy-engine 2.1.19's positions, named in
  `ephemeris` and not flagged as a fallback. One call makes the pack
  (2,489,664 bytes, refitted from JPL's DE440 for 1790 to 2210) the default
  for the root and every entry point that shares its ephemeris:
  `import { useDe440 } from "@zodiacs/engine/de440/pack"; useDe440();`
  ([de440.md](docs/de440.md#the-default-source)). An application of the
  root's `natalChart` is 79,787 bytes minified and 36,624 gzipped (36,213
  with the system zlib of Homebrew's Node 26.4.0); with `useDe440()` it is
  3,419,715 and 2,402,512.
- **`require()` loads the package, and `engines` is
  `^20.19.0 || >=22.12.0`** (2.1.0: `^20.19.0 || >=22.7.0`), the versions
  whose `require()` loads ES modules. The CommonJS stub that threw
  `ERR_ZODIACS_ESM_ONLY` and the `"require"` condition are gone; each entry
  point exports `types` and `default`
  ([guide](docs/guide.md#runtimes-and-module-formats)).
- **`@zodiacs/engine/core` shares the root's module state.** It re-exports
  the root: the same functions, default source, `withEphemeris` and
  `useDe440()`. Until 2.1.0 it was the root's code bundled on its own,
  without the pack and with settings of its own.

### Deprecated

- **`@zodiacs/engine/core`**, the root under its 2.x name: import
  `@zodiacs/engine`. It keeps working, and may be removed only in a major
  release at least twelve months after this one
  ([versioning.md](docs/versioning.md#deprecation)).

### Added

- **`@zodiacs/engine/minor-bodies`**: the apparent geocentric places of
  Chiron, Ceres, Pallas, Juno and Vesta from 1800-01-01 to 2200-01-01 TT,
  from Chebyshev tables fitted to NASA JPL Horizons's vectors, refused with
  a `RangeError` outside that span. At 500 Horizons places the fit never
  saw, every longitude and latitude is within 0.54″ after `useDe440()` and
  within 1.7″ on astronomy-engine (largest 0.53211″ and 1.68213″;
  `src/minor-bodies.test.ts`). A place's speed takes the central instant's
  side of the Sun's disc on both of its samples, as a planet's does, so it
  does not step where one sample crosses the limb.
  `minorBodyPosition(spec, date)` bundles only the tables of the specs an
  application imports: Chiron alone adds 24,261 bytes minified (14,132
  gzipped) to an application of the root's `natalChart`, and all five
  180,599 (115,938) ([guide](docs/guide.md#minor-bodies); LICENSING.md,
  *Minor-body tables*).
- **True Black Moon Lilith**, the osculating lunar apogee: the last row of
  `chartPoints()` and the body `"True Black Moon Lilith"` of `calc()`
  (`lilith:true-osculating`). Against the osculating apogee of NASA JPL
  Horizons's Moon at 12 instants from 1850 to 2150 it is within 1.59″ on
  the sky in longitude (median 0.049″) after `useDe440()`, and within 397″
  (median 179″) on astronomy-engine (`src/true-lilith.test.ts`;
  [guide](docs/guide.md#points)). `PointPosition` has optional `ephemeris`
  and `fallback`, which that row carries, `PositionSource` an optional
  `moonState`, and a DE440 source gives `moonState` and `earthAndSunState`.
- **Two packed documents**: `docs/calc.md`, the calc entry's reference with
  the Swiss Ephemeris flag mapping, and `skills/zodiacs-compute/SKILL.md`,
  for agents.
- **CI guardrails.** `budgets.json` and `scripts/ratchet.mjs` hold bundle
  sizes, the absence of bare chunk imports, two accuracy maxima, the
  conformance passes and the passing tests to limits that only a commit
  with a person's approval may loosen. The check fails on a measurement
  that is not a finite number, and on a skipped test that is not skipped by
  design: the tier-B kernel tests without `PRECISION_KERNEL`, the tzdata
  2025c test on a host without that release, and the tests that need
  `dist/` before the build. `scripts/verify-no-dashes.mjs` keeps en and em
  dashes out of the documents it names, a candidate's own changelog entry
  included until the base branch carries its archive.
- **`@zodiacs/wheel` 1.0.0** in `tools/wheel/`, a chart wheel for engine
  3.0.0's charts, minor bodies and points, prepared for npm and not
  published. It is not part of this package.

### Fixed

- **Timing results and the chart's fallback flags.** Profections, solar arc
  directions, zodiacal releasing from a lot, firdaria and planetary returns
  carry `"outside-de440-span"` or `"de440-unavailable"` where a natal
  position they use was computed on astronomy-engine in place of the pack:
  the chart's bodies, its lots and its sect, which are read on the chart's
  clock with its pinned ΔT, as the chart's flags say, and True Black Moon
  Lilith, as its `fallback` says. Up to 2.1.0 their flags came only from the
  instants they read the ephemeris at, as UTC instants, so a chart whose
  pinned ΔT put it outside the pack gave results without the flag
  (`src/timing/shared.test.ts`, `src/true-lilith.test.ts`).
- **`calc()` receipts after the IERS table (E1).** A receipt names the
  continuous-UTC rule's time-basis id when any of its instants lies after
  2027-10-02 on the `"continuous-utc"` basis; every other receipt keeps the
  id it carried (`src/calc-time-basis-2.1.1.test.ts`).
- **Search windows across a step of the time basis (E2).** A window is
  checked in order on the scale it was given on and again once converted to
  TT (to UTC for `events()`). A window that converts backwards is refused
  with a `RangeError` that names the conversion and the step: the end of
  the IERS table (2027-10-02) for a UT1 window across it, 1972-01-01 for a
  UTC window converted to TT, a leap second for a TT window converted to
  UTC, and the ΔT model's step at 1941.0
  ([calc.md](docs/calc.md#station-and-lunation-search)).
- **Bare chunk imports.** The build takes out the bare imports esbuild
  writes for chunks a file already loads, so bundling an entry point under
  `"sideEffects": false` gives no `ignored-bare-import` warning
  (`scripts/verify-dist-purity.mjs`).
- **Documentation.** README.md is a short overview, and every section it
  carried up to 2.1.0 is in `docs/guide.md`. `docs/comparison.md` gives
  PyEphem's L1 as `conformance/results/pyephem.json` has it, 240
  unsupported, where it gave 36 of 240.

### Parked

- `tools/cli/` and `python/` are parked at 3.0.0, pinned to the 1.0.0-rc.2
  and 0.1.1-rc.14 archives (`PARKED.md` in each).

### Sizes and budgets

Import graphs beside the DE440 pack and the minor-body tables, as
`npm run package:contents` measures them on this build
(`scripts/verify-package-contents.mjs` gives each step). Five budgets are
over 2.1.0's, each set to the measurement rounded up to the next hundred
bytes, for the owner to decide with the candidate:

- `./core`: 111,000 to 122,100 (graph 122,049). It is the root's graph, in
  chunks that import and export each other's names, where 2.1.0's `core.js`
  was one file of 110,870 bytes; it grows with True Black Moon Lilith and
  with the chunks the root's graph shares with `./minor-bodies`.
- `./de440`: 54,600 to 55,800 (55,714): the Moon's state for True Black
  Moon Lilith, and the Earth's and the Sun's for the minor bodies.
- `./de440/pack`: 55,800 to 57,900 (57,812): `useDe440()` and the default
  setting it shares with the root, and the same states.
- `./receipt`: 81,200 to 81,300 (81,203): the chunks the root's graph
  shares with `./minor-bodies`.
- `./minor-bodies`: new, 60,300 (60,274), beside its five tables, which are
  data held to their exact sizes and digests.

Eight graphs lose the DE440 reader and their budgets are lowered to the
measurement rounded up: `.` 154,500 to 122,100 (122,049), `./calc` 205,600
to 171,300 (171,260), `./internal` 112,600 to 79,600 (79,598), `./sky`
140,100 to 107,000 (106,998), `./techniques` 207,900 to 174,900 (174,899),
`./timing` 173,800 to 142,100 (142,014), `./vedic` 189,500 to 156,700
(156,614) and `./window` 153,000 to 120,200 (120,174). Of these, `./calc`
holds 1,162 bytes for the search windows' errors above and `./timing` 1,232
for the timing results' flags; `./minor-bodies` holds 84 for its speeds at
the Sun's limb. The cap on the package beside the pack and the tables,
1,463,000 bytes, is not raised.

### Conformance

On Node 22.22.2 against suite 0.3.0 (640 vectors; `conformance/RESULTS.md`):
after `useDe440()`, 639 pass, 0 fail and 1 unsupported (L1 240 of 240, L2
150 of 150, L3 109 of 110 with 1 unsupported, L4 140 of 140); on
astronomy-engine, the default, 392 pass, 247 fail and 1 unsupported (L1 48
of 240, L4 85 of 140). Every verdict equals 2.1.0's. The results were
written on Apple silicon: 11 of their 1,718 residual values differ from
2.1.0's, written on Linux x64, in the 6th to 9th significant digit, by
1.0 × 10⁻⁹″ at most, as 2.1.0's own build gives on that machine
(`docs/evidence/3.0.0-readme-20261126/`).

## 2.1.0 (cut 2026-11-23)

2.1.0 is 2.1.0-rc.1 with only the version changed. Station and lunation
search are available from `@zodiacs/engine/calc`.

## 2.1.0-rc.1

`@zodiacs/engine/calc` adds `searchStations()` and `searchLunations()`.
`events()` keeps its 2.0.0 contract. Chain rounded (from, to] TT windows
on the same ephemeris name and version. Exhausting `maxSamples` refuses
the whole search. Events report source and fallback flags, UTC and UT1
clock bands, and a local TT timing estimate. In L4, DE440 passes all 30
stations and 40 new or full Moons. Astronomy-engine passes 30 and 21.
Two-second quarter timing and stations beyond Saturn lack span-wide
verification. [Guide and evidence](docs/calc.md#station-and-lunation-search)

## 2.0.0 (cut 2026-11-21)

A major release: 2.0.0-rc.6 with the version changed, cut on 2026-11-21.
Checks: `docs/evidence/2.0.0-20261121/`. Callers moving from 1.1.0 should
read `docs/migrating-to-2.md` (held by `src/migration-2.0.test.ts`).

- **No code or value changes from 2.0.0-rc.6.** The only change under `src/`
  is the version string (`ENGINE_VERSION`, the two tests and the fixture that
  hold it), and `dist/` is 2.0.0-rc.6's but for that string
  (`docs/evidence/2.0.0-20261121/results/dist-vs-rc6.txt`, 95 files).
- **What 2.0.0 is over 1.1.0.** The entries below, 2.0.0-rc.1 to 2.0.0-rc.6,
  are its history:
  - **Input refusals (breaking):** a birth given as a calendar date with no
    time is refused unless `timeKnown` is `false` (2.0.0-rc.1); common
    near-miss birth keys such as `lat`, `lng`, `houses` and `scale` are
    refused instead of ignored (2.0.0-rc.3).
  - **UTC after 2027-10-02:** unpinned UTC input after the shipped IERS UT1
    table uses the continuous-UTC rule, `TT = UTC + 69.184 s`, with
    `TimeScale.basis: "continuous-utc"` and `ut1MinusUtc.source: "model"`
    (2.0.0-rc.3).
  - **Zone histories before 1970:** updated from tzdata 2025c to tzdata 2026f
    with `America/Yellowknife` held at 2025c by the owner's decision
    (2.0.0-rc.3).
  - **Flags:** three new `ChartFlag` values (`polar-angles` and
    `calendar-unknown` in 2.0.0-rc.1; `host-zone-data-differs` in 2.0.0-rc.3,
    with tzdata 2025c added beside 2021a as a host-probe baseline in
    2.0.0-rc.6 across 705 spans in 77 names), plus `flags` on `positions()`
    rows (2.0.0-rc.1).
  - **New entry and geo helpers:** `@zodiacs/engine/core` (the root API
    without the DE440 pack, 2.0.0-rc.3), and `julianDayNumber`,
    `dateOfJulianDayNumber` and `localMeanTimeOffset` in `@zodiacs/engine/geo`
    (2.0.0-rc.3).
  - **Errors:** `require()` of any entry point throws `ERR_ZODIACS_ESM_ONLY`
    (2.0.0-rc.4), and an unknown body name throws `RangeError` on every
    source including root crossing searches (2.0.0-rc.4, 2.0.0-rc.5).
- **Nothing deprecated is removed.** All seven `@deprecated` names remain:
  `docs/versioning.md` requires twelve months after the deprecating release,
  and 1.0.0 is from 2026-10-11.
- **Records.** 2.0.0 reads every natal record written by 0.1.1-rc.7 through
  2.0.0-rc.6 (`docs/evidence/records-2.0.0-20261120/`). 1.1.0 refuses
  2.0.0's continuous-UTC records as `unsupported_feature`; 2.0.0-rc.3 and
  2.0.0-rc.6 read 2.0.0's envelopes
  (`docs/evidence/2.0.0-20261121/results/earlier-readers.json`).
- **Conformance.** Measured on this build with Node 22.22.2 against suite
  0.3.0 (640 vectors; `conformance/RESULTS.md`,
  `conformance/results/zodiacs-engine.json`,
  `conformance/results/zodiacs-engine-astronomy-engine.json`): default DE440
  source **569 pass, 0 fail, 71 unsupported, 0 error** (L1 240/240, L2
  150/150, L3 109/110 with 1 unsupported, L4 70/140 with 70 unsupported);
  `astronomy-engine` 2.1.19 fallback **341 pass, 228 fail, 71 unsupported, 0
  error** (L1 48 pass / 192 fail, L2 150/150, L3 109/110 with 1 unsupported,
  L4 34 pass / 36 fail / 70 unsupported). Every verdict equals 2.0.0-rc.6's.
  The 71 unsupported vectors are 1 leap-second instant in L3, 30 stations in
  L4 and 40 lunations in L4 (the engine has no public station or lunation
  search API).
- **Runtimes.** Measured on this build across six runtimes on Linux x64
  (`docs/evidence/runtime-conformance-2.0.0-20261121/`, suite 0.3.0): all 569
  supported verdicts on both root and `@zodiacs/engine/core` agree with Node
  22.22.2 in Bun 1.4.4, Deno 2.9.6, Chromium 156.0.8078.4, Firefox 157.0 and
  WebKit 27.2 (verdict counts equal 2.0.0-rc.6's). Outputs are not
  bit-identical in every runtime (root: 458 of 569 identical to Node in Bun,
  Deno, Chromium and WebKit, 569 of 569 in Firefox; core: 468 in Bun and
  WebKit, 485 in Deno and Chromium, 540 in Firefox), and synthetic receipt
  digests differ from Node's where outputs differ.
- **Licence.** Ships with the four open licence questions noted (IERS EOP 20
  C04, CDS commercial use, Reid and Brunthaler, and ESA's non-commercial
  Hipparcos terms as a fourth), per the owner's decision of 2026-11-20 11:16
  Asia/Bangkok (`LICENSING.md`, `NOTICE`). No VSOP2013 series is shipped
  (`docs/evidence/2.0.0-20261121/results/vsop2013-check.log`).
- **Sizes and cap.** Measured on this build
  (`docs/evidence/2.0.0-20261121/results/package-contents.log`): all 20
  entry-point import graphs remain inside their 2.0.0-rc.6 budgets (no entry
  budget is raised). The package beside the DE440 pack is 1,462,688 bytes
  unpacked in 101 files; `TOTAL_CAP` is raised from 1,459,000 to 1,463,000
  (rounded up to the next 1,000 bytes), approved under the owner's delegation
  of 2026-11-21 15:06 Asia/Bangkok (`scripts/verify-package-contents.mjs`).

## 2.0.0-rc.6 (candidate, cut 2026-11-21)

The sixth candidate for **2.0.0**, a major release, on 2.0.0-rc.5 (main at
`ed8be41`, after pull request 140), merging pull request 128 (`f8a7e7e`) with
a merge commit. A candidate is published only by the owner;
`artifacts/README.md` in the repository records what happened to it. Callers
moving from 1.1.0 should read `docs/migrating-to-2.md`. Everything earlier
2.0.0 candidate entries say holds for rc.6 except where this entry says
otherwise.

### Fixed

- **Host time zone probe table (pull request 128, ZOD-340).** Adds IANA
  tzdata 2025c (SHA-256
  `4aa79e4effee53fc4029ffe5f6ebe97937282ebcdf386d5d2da91ce84142f957`) as a
  second baseline beside tzdata 2021a when comparing against tzdata 2026f.
  The compiled probe table in `src/geo/host-probes-data.ts` now holds 705
  spans across 77 zone names (up from 703 spans in 77 names, +9 bytes in
  `dist/geo.js`), adding the 1979-05-25T20:30Z to 1979-05-26T20:30Z span for
  `Asia/Tehran` and its link `Iran`, where tzdata 2025c gives UTC+03:30 and
  both 2021a and 2026f give UTC+04:30. A host on tzdata 2025c (including Node
  22.22.2, ICU 78.2) is now flagged `host-zone-data-differs` at 1979-05-26
  12:00 in both names instead of passing unchecked. Held by
  `src/geo/host-zone-check.test.ts` and
  `docs/evidence/host-zone-probes-20261118/`.

### Documentation

- `LICENSING.md` and `NOTICE` (ZOD-341, pull requests 138 and 139): name
  tzdata 2021a, 2025c and 2026f with their SHA-256 digests as the probe
  table's sources; credit ESA (`Credit: ESA`) for the Hipparcos observations
  behind VizieR I/311; and record the owner's 2026-11-20 11:16 Asia/Bangkok
  decision to ship 2.0.0 with the four open licence questions noted (IERS EOP
  20 C04, CDS commercial use, Reid and Brunthaler, and ESA's non-commercial
  Hipparcos terms as a fourth).
- `README.md`: updates the public entry-point count to eighteen (with
  `@zodiacs/engine/core`), updates the Node 20 line from "a 1.x minor release"
  to "a 2.x minor release", updates the host-probe descriptions to name both
  tzdata 2021a and 2025c, points callers moving from 1.1.0 to
  `docs/migrating-to-2.md`, and adds a summary of six-runtime conformance.
  The span ends were measured again on this build (`span-ends.mjs`:
  `natalChart` last UTC 3998-09-03T05:58:50.816Z, `calc` last UTC
  2199-12-31T23:58:50.815Z). Bundle sizes remain 2.0.0-rc.3's and say so.
- Unpacked repository documentation updated before this cut (not packed):
  `docs/migrating-to-2.md` with per-break tests in `src/migration-2.0.test.ts`
  (ZOD-338, pull request 133), `docs/versioning.md`, `SECURITY.md`,
  `artifacts/README.md` and `tools/cli/README.md` for 2.x (ZOD-342, pull
  request 137), records-across-the-major evidence in
  `docs/evidence/records-2.0.0-20261120/` (ZOD-337, pull request 132), and
  draft v1.1.0 release notes and tag commands in `docs/releases/` (ZOD-343
  Part A, pull request 135).

### Conformance

- Regenerated on this build with Node 22.22.2 against conformance suite 0.3.0
  (640 vectors; `conformance/RESULTS.md`,
  `conformance/results/zodiacs-engine.json`,
  `conformance/results/zodiacs-engine-astronomy-engine.json`):
  - Default source (shipped DE440 pack): **569 pass, 0 fail, 71 unsupported,
    0 error** (L1 240/240, L2 150/150, L3 109/110 with 1 unsupported, L4
    70/140 with 70 unsupported). Every verdict matches `main`.
  - Fallback source (`astronomy-engine` 2.1.19): **341 pass, 228 fail, 71
    unsupported, 0 error** (L1 48 pass / 192 fail, L2 150/150, L3 109/110
    with 1 unsupported, L4 34 pass / 36 fail / 70 unsupported). Every verdict
    matches `main`.
  - The 71 unsupported vectors are 1 leap-second instant in L3 (not
    expressible as a JavaScript Date), 30 station vectors in L4 and 40
    lunation vectors in L4: the engine has no public station or lunation
    search API.

### Runtimes

- Measured on this candidate's build across six runtimes on Linux x64
  (`docs/evidence/runtime-conformance-20261121/`, suite 0.3.0): all 569
  supported verdicts on both root and `@zodiacs/engine/core` agreed with Node
  22.22.2 in Bun 1.4.4, Deno 2.9.6, Chromium 156.0.8078.4, Firefox 157.0 and
  WebKit 27.2 (71 unsupported: 1 leap second, 30 stations, 40 lunations).
  Outputs are not bit-identical in every runtime (root: 458 of 569 identical
  to Node in Bun, Deno, Chromium and WebKit, 569 of 569 in Firefox; core: 468
  in Bun and WebKit, 485 in Deno and Chromium, 540 in Firefox), and synthetic
  receipt digests differ from Node's where outputs differ.

### Corrections

Carried from `docs/changelog-corrections.md` (item 18; items 15 to 17 were
carried into 2.0.0-rc.4's `### Corrections`). The 2.0.0-rc.3 entry is left as
written.

- 2.0.0-rc.3, `CHANGELOG.md` lines 44 to 45 ("each nearby span in which
  tzdata 2021a and 2026f differ (703 spans in 77 names)") and lines 118 to
  119 ("the host-probe table compares tzdata 2021a with 2026f"): pull request
  128 adds tzdata 2025c beside 2021a (705 spans in 77 names), flagging a
  2025c host at `Asia/Tehran` and `Iran` on 1979-05-26
  (`docs/evidence/host-zone-probes-20261118/README.md`). `README.md`,
  `NOTICE` and `LICENSING.md` are updated in this candidate.

### Sizes and budgets

- Measured on this candidate's build
  (`docs/evidence/2.0.0-rc.6-20261121/results/package-contents.log`): all 20
  entry-point import graphs remain inside their 2.0.0-rc.5 budgets (`./geo`
  grew by 9 bytes, from 47,715 to 47,724 of 47,800, for pull request 128's
  Tehran probe). The package beside the DE440 pack is 1,458,962 bytes
  unpacked in 101 files, over the 2.0.0-rc.5 cap of 1,450,000 because of this
  entry, the README updates, `LICENSING.md`, `NOTICE` and the 9-byte probe
  addition. Cap raised to 1,459,000 (the measurement rounded up to the next
  1,000 bytes), for the owner to decide with this candidate
  (`scripts/verify-package-contents.mjs`).

## 2.0.0-rc.5 (unreleased candidate)

The fifth candidate for **2.0.0**, a major release, on 2.0.0-rc.4 (pull
request 140, after the rc.4 source commit `4c2bd2c` and the unknown-body
crossing fix `11960941d`). It is not to be published on npm until the
owner approves it.

rc.4's archive is carried; the crossing fix reaches `dist/`, so by the
rule in `artifacts/README.md` the package takes a new number and rc.4's
archive stays, unchanged. The owner approved this candidate on 21 November
2026. Everything rc.4's entry says holds for rc.5 except where this entry
says otherwise.

### Changed

- `searchLongitudeCrossings` and `findLongitudeCrossings` refuse a name
  that is not a body with `RangeError("Unknown body: <name>")` before
  they search, by calling `assertKnownBody` (exported from
  `src/ephemeris.ts`, the check `longitudeOn` and `speedAt` already run).
  Up to rc.4, the wrappers refused the name only when the solver asked a
  longitude, so a zero-length window returned an empty result and a
  search over its sample budget returned the refusal. A known body on
  those same windows is unchanged: a zero-length window is complete and
  empty, and a search over its sample budget is refused for
  `sample-budget`. The DE440 entry's own unknown-body stays a
  `De440Error`. Held by `src/ephemeris-unknown-body.test.ts`. The source
  commit of the fix is `11960941d`.

### Documentation

- README.md: this candidate's paragraph, archive and install path. The
  span's ends and the README's bundle sizes were not measured again;
  they remain rc.4's and rc.3's respectively, and say so.

### Sizes and budgets

- Measured on this candidate's build, seven import graphs were over their
  budgets, each by the crossing-search body check (`assertKnownBody` in
  the root wrappers, and its export). Each budget is raised to the
  measurement, rounded up to the next 100 bytes, and no further (old
  budget, rc.4's measurement, this candidate's, new budget):

  | Entry | Old budget | rc.4 | rc.5 | New budget | Why |
  | --- | ---: | ---: | ---: | ---: | --- |
  | `.` | 154,400 | 154,316 | 154,422 | 154,500 | the crossing-search body check (106) |
  | `./calc` | 205,500 | 205,477 | 205,514 | 205,600 | the crossing-search body check (37) |
  | `./sky` | 140,000 | 139,978 | 140,015 | 140,100 | the crossing-search body check (37) |
  | `./techniques` | 207,800 | 207,704 | 207,810 | 207,900 | the crossing-search body check (106) |
  | `./timing` | 173,700 | 173,619 | 173,725 | 173,800 | the crossing-search body check (106) |
  | `./vedic` | 189,400 | 189,351 | 189,457 | 189,500 | the crossing-search body check (106) |
  | `./window` | 152,900 | 152,874 | 152,911 | 153,000 | the crossing-search body check (37) |

  Every other graph is inside its budget, unchanged (`./internal`
  112,561 of 112,600; `./core` 110,976 of 111,000). The package beside
  the pack is 1,449,915 bytes unpacked in 101 files, over the cap of
  1,446,200: the body check, this entry and the README's lines. Raised
  to 1,450,000, the measurement rounded up to the next 100 bytes. The
  budgets and the cap are for the owner to decide with the candidate
  (`scripts/verify-package-contents.mjs`).

## 2.0.0-rc.4 (unreleased candidate)

The fourth candidate for **2.0.0**, a major release, on 2.0.0-rc.3 (main at
`900455f`, after pull request 139), with three fixes. It is not to be
published on npm until the owner approves it. Checks:
`docs/evidence/2.0.0-rc.4-20261120/`.

rc.3's archive is carried, and npm has carried rc.3 under `next` since
2026-11-17 (not tagged); these fixes reach `dist/` and the packed README, so
by the rule in `artifacts/README.md` the package takes a new number and
rc.3's archive stays, unchanged. The owner approved the fixes and this
candidate on 20 November 2026. Everything rc.1's, rc.2's and rc.3's entries
say holds for rc.4 except where this entry says otherwise.

### Changed

- `require()` of `@zodiacs/engine` or of any of its entry points throws an
  `Error` with code `ERR_ZODIACS_ESM_ONLY`, whose message says to use
  `import`, or `await import("@zodiacs/engine")` from CommonJS. Up to rc.3
  Node threw its own `ERR_PACKAGE_PATH_NOT_EXPORTED` ("No "exports" main
  defined"). Each of the 20 entries in `exports` gains a `"require"`
  condition, after `"import"`, that points at `dist/esm-only.cjs`, a file
  that throws that error and does nothing else; `files` packs it. There is
  still no CommonJS build and no `"default"` condition. A tool that resolves
  with the `require` condition (Jest in CommonJS mode, a bundler compiling
  `require()` calls) now gets this error in place of Node's: both fail, and
  this one says what to do. Held by `scripts/esm-only.test.mjs`, the export
  smoke test and the packed-consumer check, which requires every entry point
  from CommonJS and loads the package with `import()` from CommonJS.
- A name that is not a body is a `RangeError` on the default source. The
  root refuses it with `RangeError("Unknown body: <name>")` before any
  source is asked, in `searchLongitudeCrossings` and
  `findLongitudeCrossings`, and in `./internal`'s `bodyLongitude`,
  `longitudeSpeed` and their `...Detailed` forms, whether the source is the
  shipped DE440 pack, astronomy-engine or a caller's pack given with
  `withEphemeris`. Up to rc.3, on the default source, the DE440 reader's
  `De440Error` (code `unknown-body`) reached the caller, which a caller that
  catches only `RangeError` did not catch; nothing was computed either way.
  `@zodiacs/engine/de440`'s own source keeps `De440Error` for a body it does
  not place. Held by `src/ephemeris-unknown-body.test.ts`; the adversarial
  case BAD-56 now expects `RangeError`.

### Documentation

- README.md: the *Configurable aspects* and *Declinations and parallels*
  examples import `natalChart` and build their own chart, so they run as
  pasted; `src/readme-snippets.test.ts` runs both. The install notes say
  what `require()` does. This candidate's paragraph, archive and evidence
  folder. The span's ends were measured again on this build with
  `docs/evidence/continuous-utc-20261117/span-ends.mjs` and are the same to
  the millisecond as on rc.3 (natalChart's last UTC
  3998-09-03T05:58:50.816Z, calc's 2199-12-31T23:58:50.815Z;
  `docs/evidence/2.0.0-rc.4-20261120/results/span-ends.json`).
- The README's bundle sizes are rc.3's, measured on rc.3's archive, and say
  so; they were not measured again for this candidate.

### Corrections

Carried from `docs/changelog-corrections.md` (items 15 to 17). The entries
they correct are left as written.

- 2.0.0-rc.3, the heading "unreleased candidate" and "It is a draft for the
  owner's review": rc.3 was published to npm on 2026-11-17 under `next`,
  with 1.1.0 still under `latest`; it has no git tag and no GitHub release
  (`docs/evidence/changelog-corrections-20261118/records.md`). True when
  written. The rest of that sentence, "and is not to be published on npm
  until the owner approves it", stands. The README's rc.3 paragraph said
  the same ("is a draft for the owner's review and is not published to
  npm"); this candidate's paragraph replaces it.
- 2.0.0-rc.3, pull request 121 (`@zodiacs/engine/core`): "the root is
  unchanged". The root's results, names and types are unchanged; its import
  graph grew by 109 bytes because the shared ephemeris chunk grew by that
  amount, as the same entry's size table says for `.`, `./calc`,
  `./internal`, `./sky`, `./timing`, `./vedic` and `./window`.

### Sizes and budgets

- Measured on this candidate's build
  (`docs/evidence/2.0.0-rc.4-20261120/results/package-contents.log`), nine
  import graphs were over their budgets, each by the 143 bytes the body
  check adds to every graph that holds `src/ephemeris.ts`; the root had 27
  bytes to spare. Each budget is raised to the measurement, rounded up to
  the next 100 bytes, and no further (old budget, rc.3's measurement, this
  candidate's, new budget):

  | Entry | Old budget | rc.3 | rc.4 | New budget | Why |
  | --- | ---: | ---: | ---: | ---: | --- |
  | `.` | 154,200 | 154,173 | 154,316 | 154,400 | the body check (143) |
  | `./calc` | 205,400 | 205,334 | 205,477 | 205,500 | the body check (143) |
  | `./core` | 110,800 | 110,765 | 110,908 | 111,000 | the body check (143) |
  | `./internal` | 112,400 | 112,381 | 112,524 | 112,600 | the body check (143) |
  | `./sky` | 139,900 | 139,835 | 139,978 | 140,000 | the body check (143) |
  | `./techniques` | 207,600 | 207,561 | 207,704 | 207,800 | the body check (143) |
  | `./timing` | 173,500 | 173,476 | 173,619 | 173,700 | the body check (143) |
  | `./vedic` | 189,300 | 189,208 | 189,351 | 189,400 | the body check (143) |
  | `./window` | 152,800 | 152,731 | 152,874 | 152,900 | the body check (143) |

  Every other graph is inside its budget, unchanged. The package beside the
  pack is 1,446,177 bytes unpacked in 101 files, over the cap of 1,438,000:
  the body check, `dist/esm-only.cjs`, the 20 `"require"` conditions in
  `package.json`, this entry and the README's lines. Raised to 1,446,200,
  the measurement rounded up to the next 100 bytes. The budgets and the cap
  are for the owner to decide with the candidate
  (`scripts/verify-package-contents.mjs`).

## 2.0.0-rc.3 (unreleased candidate)

The third candidate for **2.0.0**, a major release, on 2.0.0-rc.2 (main at
`373ceda`, where pull request 112 merged rc.2). It is a draft for the
owner's review and is not to be published on npm until the owner approves
it. Checks: `docs/evidence/2.0.0-rc.3-20261117/`.

rc.2's archive is carried and its version was never tagged or published;
these changes reach `dist/`, so by the rule in `artifacts/README.md` the
package takes a new number and rc.2's archive stays, unchanged. rc.3 is
rc.2 with six pull requests merged into it, each with a merge commit, in
this order: 114, 115, 117, 118, 119 and 121. The owner chose this set on
17 November 2026 ("Yes, minus Yellowknife"): pull request 118 ships with
America/Yellowknife held at tzdata 2025c, and pull requests 120 and 122 are
not in it. Everything rc.1's and rc.2's entries say holds for rc.3 except
where this entry says otherwise.

### Breaking

- **Birth input refuses common near-miss names for a field** (pull
  request 115). Birth input now refuses, with a `RangeError` that names the
  field to use, these common names for a field, in any letter case: `lat`
  (use `latitude`); `lng`, `lon`, `long` (`longitude`); `house`, `houses`,
  `hsys`, `housesystem` (`houseSystem`); `scale`, `time_scale`
  (`timeScale`); `delta_t` (`deltaT`); `time_known`, `unknownTime`
  (`timeKnown`). They were ignored, so `{ utc, lat, lng }` gave a chart with
  no angles and no error. Other unknown keys are still ignored. A call that
  returned a chart before now throws.

### Added

- **Julian Day Numbers and local mean time** (pull request 114). Added:
  `julianDayNumber`, `dateOfJulianDayNumber` and `localMeanTimeOffset` in
  `@zodiacs/engine/geo`, the Julian Day Number of a Julian or proleptic
  Gregorian date and its inverse for years -100000 to 100000, and a
  longitude's local mean time in seconds east of Greenwich; the conformance
  suite's 35 calendar vectors and 5 local mean time vectors now pass. The
  `./geo` budget rises to fit them.
- **`host-zone-data-differs`** (pull request 117, ZOD-283). From 1970 on a
  wall time is read on the device's own time zone data; `resolveLocalToUtc`
  and the birth resolvers now ask that data for its offset at one instant
  inside each nearby span in which tzdata 2021a and 2026f differ (703 spans
  in 77 names, from 1970 to 2029-10-27, and not past it), and where it
  disagrees with 2026f the result, the birth, the chart and a receipt carry
  the new `ChartFlag` value `"host-zone-data-differs"` and `zone.hostCheck`
  gives both offsets; the instant is still the device's, so code that
  switches exhaustively over `ChartFlag` needs a case for it
  (`docs/time.md`, *Host time zone data*;
  `docs/evidence/host-zone-probes-20261117/`). A span is checked from 36
  hours before it begins, inclusive, to 36 hours after it ends, exclusive,
  so an instant exactly 36 hours past the end, or 36 hours or more after
  2029-10-27T00:00Z, is not checked; `docs/time.md` said "more than" 36
  hours, and now follows the code (the review's note on pull request 117).
- **`@zodiacs/engine/core`** (pull request 121, ZOD-292). Adds
  `@zodiacs/engine/core`, the root's functions computed on astronomy-engine
  without the DE440 pack: a page that uses `natalChart` from it bundles
  77,042 to 80,192 bytes instead of 3,416,191 to 3,418,817
  (`docs/evidence/2.0.0-rc.3-20261117/results/bundle-weight/`, measured on
  this candidate's archive; pull request 121 measured 75,937 to 79,084 and
  3,415,068 to 3,417,703, `docs/evidence/bundle-weight-20261117/`), and its
  positions pass 48 of the 240 L1 position tests where the root's pass 240;
  the root is unchanged. Raises the package's total cap for the entry's
  second copy of the root's code, with the owner's approval of 17 Nov 2026
  (*Sizes and budgets*, below).

### Changed

- **UTC after the IERS UT1 table** (pull request 119, ZOD-281). After the
  IERS UT1 table (2027-10-02), UTC is read on the continuous-UTC rule:
  TT = UTC + 69.184 s, UT1 from the ΔT model; time basis `continuous-utc`,
  UT1 − UTC source `model`, new natal conventions sets requiring
  `time-basis-continuous-utc`. Results move for every unpinned UTC instant
  after 2027-10-02 (positions, angles, houses, returns, windows). Records
  with the new sets are refused by 1.1.0 and 2.0.0-rc.2 as
  `unsupported_feature`; `CONTINUOUS_UTC_RELEASE` in `src/receipt.ts`, the
  first engine version a continuous-UTC set is accepted from, is
  `2.0.0-rc.3`, this candidate. On UTC input after the table calc's
  geocentric bounds and `events()`' timing bound no longer widen (on the DE440
  pack the Moon at 2199 is 0.51″ from JPL Horizons, was 28.26″). The last UTC instant
  `natalChart` accepts moves from 3998-09-03T02:01:41.309Z to
  3998-09-03T05:58:50.816Z, and calc's from 2199-12-31T23:57:53.752Z to
  2199-12-31T23:58:50.815Z, measured again on this candidate's archive
  (`docs/evidence/2.0.0-rc.3-20261117/results/span-ends.json`). Speeds
  within 6 hours of 2027-10-02 move by up to 3.6e-7 °/day (the
  astronomy-engine node 3.8e-6) against rc.2, and the 146 ms after the table
  on UTC input read the predicted ΔT segment, unflagged
  (`docs/evidence/continuous-utc-20261117/`).
- **Zone histories from tzdata 2026f** (pull request 118). The zone history
  shipped for wall times before 1970 is now tzdata 2026f, not 2025c, except
  America/Yellowknife, held at tzdata 2025c by the owner's decision because
  no tzdb NEWS entry or other official announcement explains 2026f's change
  to it. Offsets change in 23 zone names: Europe/Dublin and Eire read +0:00,
  not +1:00, from 1925-09-20T02:00Z to 1925-10-04T02:00Z (336 hours); 21
  Brazilian names keep daylight saving one hour longer on 1965-03-31 (24
  hours) and 1966-03-01 (1 hour). EST5EDT, CST6CDT, MST7MDT and PST8PDT name
  1942 to 1945 summer time EDT, CDT, MDT and PDT and no longer record a
  transition on 1945-08-14; Europe/Uzhgorod and Europe/Zaporozhye follow
  Kyiv's local mean time era and report dataForm main+backzone; Morocco's
  and Western Sahara's 2026-09-20 move to +00 reads as a legal change on
  hosts that know it (`docs/evidence/tzdb-2026f-20261117/`).
  America/Yellowknife's results before 1970 equal rc.2's, but its
  `tzdbVersion` field reads `2026f`, as every zone's does, though its data
  is tzdata 2025c's (`scripts/tzdb-held/`).

### Documentation

- README.md: this candidate's paragraph, archive and evidence folder; the
  three new `geo` functions; *Birth settings* on the refused near-miss
  names; *Input flag compatibility*, all twelve `ChartFlag` values, with
  `host-zone-data-differs` among the five caller assertions; the time basis
  after 2027-10-02, the window seam there (TT runs on, UT1 steps about
  2 ms), the bands and the span's ends; the zone histories on tzdata 2026f
  with America/Yellowknife held, and the host check; *Bundle size in a web
  page*, measured again on this candidate's archive.
- NOTICE and LICENSING.md: the zone histories are tzdata 2026f's, with
  America/Yellowknife from tzdata 2025c, and the host-probe table compares
  tzdata 2021a with 2026f; each with its archive's SHA-256.
- `docs/time.md`: the host check's 36-hour window, inclusive at its start and
  exclusive at its end, as above. `docs/calc.md`, `docs/time.md` and
  `src/types.ts` name 2.0.0-rc.3 or 2.0.0 where they said "the release
  after 2.0.0-rc.2" or "the release after 1.1.0".
- Conformance: this engine's results (`conformance/results/`, `RESULTS.md`)
  were regenerated with the harness on Node 22.22.2 and name 2.0.0-rc.3 and
  tzdb 2026f. Default source: 499 pass, 0 fail, 1 unsupported (the leap
  second instant, which a JavaScript date cannot express); on
  astronomy-engine 307 pass, 192 fail, 1 unsupported, 48 of the 240
  positions passing. No verdict differs from the pull requests' own runs.
- The offline CLI consumer check (`tools/cli/`) held the carried 1.0.0-rc.2
  archive's verdicts to this engine's astronomy-engine results, which now
  pass the 40 vectors that archive cannot answer. It now reads its own
  pinned baseline, `tools/cli/baselines/engine-1.0.0-rc.2-node-22.22.2.json`,
  the 500 verdicts of that file at `373ceda` (267 pass, 192 fail, 41
  unsupported), as pull request 114 asked the candidate to settle.

### Sizes and budgets

- Measured on this candidate's build
  (`docs/evidence/2.0.0-rc.3-20261117/results/package-contents.log`), twelve
  import graphs were over their budgets. Each budget is raised to the
  measurement, rounded up to the next 100 bytes, and no further (old budget,
  rc.2's measurement, this candidate's, new budget):

  | Entry | Old budget | rc.2 | rc.3 | New budget | Why |
  | --- | ---: | ---: | ---: | ---: | --- |
  | `.` | 151,700 | 151,563 | 154,173 | 154,200 | 115 (565), 117 (26), 119 (1,910), 121 (109) |
  | `./calc` | 204,100 | 203,138 | 205,334 | 205,400 | 119 (2,061), 117 (26), 121 (109) |
  | `./core` | 109,600 | (none) | 110,765 | 110,800 | 121's entry, now with 115, 117 and 119 |
  | `./geo` | 36,500 | 36,178 | 47,715 | 47,800 | 117's probe table and check, 114's functions |
  | `./internal` | 110,900 | 110,362 | 112,381 | 112,400 | 119 (1,910), 121 (109) |
  | `./receipt` | 77,400 | 76,845 | 81,110 | 81,200 | 119's conventions sets (3,926), 117's flag (339) |
  | `./sky` | 138,600 | 137,816 | 139,835 | 139,900 | 119 (1,910), 121 (109) |
  | `./techniques` | 207,300 | 205,247 | 207,561 | 207,600 | 119, 114, 115 and 121; 117 moved the probe table out (−1,393) |
  | `./time` | 42,600 | 42,530 | 44,485 | 44,500 | 119 (1,955) |
  | `./timing` | 171,200 | 170,866 | 173,476 | 173,500 | 119 (1,910), 115 (565), 121 (109), 117 (26) |
  | `./vedic` | 187,100 | 186,598 | 189,208 | 189,300 | 119 (1,910), 115 (565), 121 (109), 117 (26) |
  | `./window` | 151,500 | 150,577 | 152,731 | 152,800 | 119 (2,019), 121 (109), 117 (26) |

  Every other graph is inside its budget, unchanged; the zone histories are
  188,964 bytes of their 200,000. The package beside the pack is
  1,437,512 bytes unpacked in 100 files, over the cap of 1,289,000:
  the second copy of the root's code in `dist/core.js` and its declarations
  (pull request 121), the other five pull requests' code and declarations,
  this entry and the README's, NOTICE's and LICENSING.md's lines. Raised to
  1,438,000, the measurement rounded up to the next 1,000 bytes; the owner
  approved raising the cap for the core entry on 17 November 2026. The
  entry budgets are for the owner to decide with the candidate
  (`scripts/verify-package-contents.mjs`).

## 2.0.0-rc.2 (unreleased candidate)

The second candidate for **2.0.0**, a major release, on 1.1.0 (main at
`12943c1`). It is a draft for the owner's review and is not to be published
on npm until the owner approves it. Checks:
`docs/evidence/2.0.0-rc.2-20261116/`.

2.0.0-rc.1 was a draft on this same pull request (112), reviewed in draft
and not tagged or published: this candidate replaces it. Its review found a
blocker in pull request 105's check of a supplied `polar-angles` claim. The
fix changes `dist/`, and rc.1's archive is carried, so by the rule in
`artifacts/README.md` the fixed package takes a new number; rc.1's archive
stays, unchanged. rc.2 is rc.1 with pull request 105's fix merged into it
and the changes below; everything rc.1's entry says holds for rc.2 except
where this entry says otherwise.

### Fixed

- **A chart the engine flags `polar-angles` is no longer refused when passed
  back in** (pull request 105, `522a0d6`). The engine sets the flag where
  |latitude| ≥ 90° − (ε₀ + Δε), ε₀ the IAU 2006 mean obliquity
  (`meanObliquity` in `src/houses.ts`, all six terms of its polynomial, up
  to t⁵) and Δε the nutation in obliquity, both at the chart's TT. rc.1
  allowed the flag on a supplied chart (`transits`, `synastry`,
  `saturnReturn` and every timing, techniques and Vedic function that takes
  a chart) and on a natal receipt where
  |latitude| ≥ 66.55772° + 4.1227 × 10⁻¹⁵° for each millisecond from
  J2000, ε₀'s constant and linear terms alone. The terms left out reach 16″
  by 3999, so from 2936 on, at some phases of the nutation, a chart the
  engine flagged at the edge of the circle was refused: `transits` threw
  "chart flags must agree with its input and supplied house result", and its
  natal receipt was refused as `inconsistent_result`, `createNatalEnvelope`
  included. Both checks now allow the claim where
  |latitude| ≥ 90° − ε₀ − 0.003°, ε₀ from the whole polynomial: a supplied
  chart's at the TT of its input's instant, time scale and ΔT, a receipt's
  at its instant on TT input or its instant plus its recorded ΔT on UTC or
  UT1 input (UT1 − UTC, under a second, left out). The receipt entry keeps
  its own copy of the polynomial, so as not to load the houses code, and a
  test holds it to the same six coefficients. The 0.003° (10.8″) margin
  covers Δε, which is under 10″ on every day of the ephemeris span, 0001 to
  3998 (9.97″ at most); `docs/houses.md` gave it as under 9.3″, which was
  wrong. Tests at 2937-03-18, 2955-09-23, 3197-09-19, 3991-10-06 and
  3995-10-07, on both hemispheres, find by bisection the latitude at which
  the engine starts to flag and show that chart round-tripping through
  `transits` and a natal receipt, and a claim 0.0005° outside the allowed
  band still refused; a ΔT pinned 95 years from its instant shows the TT is
  the one read. They fail on rc.1 (`src/polar-angles.test.ts`,
  `docs/houses.md`). A chart the engine flags is now accepted at every
  instant of the ephemeris span. A claim on a chart it does not flag is held
  to the polynomial too, which in the early centuries puts the bound up to
  16″ further from the equator than rc.1's line, so a false claim rc.1 let
  through in that sliver is now refused.

### Client contract

- The compute clients' contract (`clients/typescript/contracts/openapi.json`)
  gains `"de440-unavailable"` and `"outside-de440-span"` in `ChartFlag` and
  in the values of `BodyPosition.flags`. Both are real chart flags: the
  ephemeris fallback flags (`EphemerisFallback`), part of the engine's
  `ChartFlag` since 1.1.0-rc.10, which a chart computed on astronomy-engine
  where the shipped DE440 pack was the default carries, and which a
  `positions()` row carries as a chart at the same instant does (rc.1,
  pull request 111). rc.1's contract named only the other two instant
  flags. `provenance.json`'s subset hash and note and the generated
  TypeScript and Python contracts follow. The engine's own types
  (`InstantFlag`, `api/`) already had them.

### Documentation

- README.md: this candidate's paragraph, archive and evidence folder; under
  *Input flag compatibility*, all eleven `ChartFlag` values, with
  `calendar-unknown` among the four caller assertions (`dst-gap`,
  `dst-fold`, `lmt`, `calendar-unknown`) and the seven flags a caller may
  echo where the calculation derives them (`no-time`, `polar-fallback`,
  `polar-angles`, `outside-reference-span`, `delta-t-extrapolated`,
  `de440-unavailable`, `outside-de440-span`; rc.1's list named three);
  `saturnReturn` runs one natal calculation for an asserted `polar-angles`
  as for `polar-fallback`, and accepts the three flags it cannot check
  without a chart unchecked.
- LICENSING.md: the owner's acceptance of shipping the DE440 pack, recorded
  for 1.1.0, covers 2.0.0, which ships the same sealed pack
  (`src/de440/` is unchanged since 1.1.0).
- rc.1's entry below: its `polar-angles` bullet gave the bound on a supplied
  chart or receipt without saying which mean obliquity; it now points here.
- Conformance: this engine's results (`conformance/results/`, `RESULTS.md`)
  were regenerated with the harness on Node 22.22.2 and name 2.0.0-rc.2. No
  verdict changes (459 pass, 0 fail, 41 unsupported; on astronomy-engine
  48 of the 240 positions pass); the 10 polar vectors whose charts fall back
  from Placidus or Koch (`L2-POL-0001` to `0003` and `0005` to `0011`) now
  record `polar-angles` beside `polar-fallback`, in both runs.

### Sizes and budgets

- Measured on this candidate's build
  (`docs/evidence/2.0.0-rc.2-20261116/results/package-contents.log`), every
  import graph is inside its budget and no budget or cap is raised. The fix
  adds 32 bytes to the root's graph and to every graph that shares its chunk
  (the time basis read once for both of `resolvedChart`'s checks, and
  `meanObliquity`), and 222 to `./receipt` (its copy of the polynomial):
  the root is 151,563 bytes of 151,700 (137 left), `./timing` 170,866 of
  171,200, `./receipt` 76,845 of 77,400 and `./techniques` 205,247 of
  207,300. The package beside the pack is 1,284,237 bytes unpacked
  in 98 files, of 1,289,000 (this entry and the README's lines).

## 2.0.0-rc.1 (unreleased candidate)

The first candidate for **2.0.0**, a major release, on 1.1.0 (main at
`12943c1`). It is a draft for the owner's review and is not to be published
on npm until the owner approves it. Checks:
`docs/evidence/2.0.0-rc.1-20261116/`.

It carries four pull requests, merged into it with merge commits: 109 (a
bare birth date refused), 111 (`positions()` rows flagged), 110 (a skipped
calendar-switch date flagged) and 105 (angles inside the polar circle
flagged). The number is a major one because of 109: which input a function
refuses is public (`docs/versioning.md`, *Documented behaviour*), the README
documented a bare date as midnight UTC, and the owner decided on 2026-11-11
to hold the refusal for 2.0.0 (1.1.0-rc.6, below). The other three add a
flag value, a result field and the cases that carry them, which a minor
release may do.

### Breaking

- **A birth given as a calendar date with no time is refused** unless the
  birth time is declared unknown (pull request 109). In 1.x,
  `natalChart({ utc: "1990-05-03" })` read the date as 00:00 UTC and returned
  a chart marked `timeKnown: true`, with a rising sign and houses for a time
  nobody gave. Now it throws a `RangeError`. With `timeKnown: false` the
  same date is accepted, with the `no-time` flag and no angles or houses. A
  full instant (`"1990-05-03T00:00:00Z"`, or with an offset), a `Date` and an
  epoch number are read exactly as before. The refusal covers every root
  function that takes a birth (`natalChart`, `transits`, `synastry`,
  `chartPoints`, `chartDeclinations`, and through the resolved chart the
  timing, techniques and Vedic functions that take one), `saturnReturn` in
  both forms (`saturnReturn("1990-05-03")` and
  `saturnReturn({ utc: "1990-05-03" })`), and calc's `chart()` given such a
  `time` (as a string or `{ iso }`). What to do: write the instant out
  (`"YYYY-MM-DDT00:00:00Z"`) or pass `timeKnown: false`. Not changed: a chart
  already built, a receipt replay, `progressedInstant` and
  `progressedBodies`, timing's `solarArc`, calc's `houses()` and
  `resolveLocalBirth`, which still read a bare date as the README says.

### Flags

- **`polar-angles`** (pull request 105). Every chart whose angles are inside
  the polar circle, |latitude| ≥ 90° − ε on the true obliquity of date,
  carries the new `ChartFlag` value `"polar-angles"`, in every house system,
  from `natalChart`, calc's `chart()` and `houses()`; there the ascendant
  turns half a circle twice a sidereal day. 1.1.0 warned only for Placidus
  and Koch (`polar-fallback`). A supplied chart or natal receipt may carry
  the flag where |latitude| ≥ 90° − ε₀ − 0.003°, ε₀ the mean obliquity of
  its instant, may lack it there, and is refused anywhere else
  (`docs/houses.md`; `docs/evidence/polar-angles-20261116/`). In rc.1, ε₀
  there was its constant and linear terms alone, which refused some charts
  the engine flagged from 2936 on; 2.0.0-rc.2 corrects it (above).
- **`calendar-unknown`** (pull request 110). `ChartFlag` and
  `LocalTimeResolution["flags"]` gain `"calendar-unknown"`, a time flag a
  caller may also assert. `resolveLocalToUtc` and the birth resolvers set it
  when no country the Gregorian adoption table dates is given and the
  written date, in either calendar, falls in the days one of the table's
  changeovers skipped, for a changeover the zone does not rule out. The
  capital zone of a tabled country follows that country's changeover alone,
  for 12 of the 18 rows; the capital zones of the Netherlands, Switzerland,
  Poland, Belgium, Sweden and Finland are not narrowed, since their rows'
  notes date changeovers inside other rows' skipped days. Russia's change of
  1918 applies only under `Europe/`, `Asia/` or a zone that names no place.
  A country the table does not date no longer silences the flag. The flag
  rides on the birth into the chart's flags and a receipt's `inputFlags`,
  and a receipt refuses it on an instant outside 1582-10-04T00:00Z up to
  1918-02-28T00:00Z, with or without a local record. The instant is never
  changed. Greece is not in the table, since none of its three sources
  dates its change of 1923, so a Greek date of 1923 is neither flagged nor
  noted (`docs/time.md`; `docs/evidence/calendar-unknown-20261116/`).
- **`positions()` rows carry flags** (pull request 111). Each row of
  `positions()`, `transits().positions` and `progressedBodies()` carries
  `flags`, the flags `natalChart()` with no place gives at the same instant,
  in the same order (`"outside-reference-span"`, `"delta-t-extrapolated"`,
  then the ephemeris fallback), from one shared function. A row has no
  `flags` property where the chart has none, so rows inside the span on a
  tabulated ΔT are as before. Besides the span's ends, rows after 2027-10-02,
  where the time basis moves from the IERS table to the ΔT model, now carry
  `["delta-t-extrapolated"]`, as `natalChart()` there already does; code
  that deep-compares rows or expects a fixed key set sees the new key there.
  The root exports `InstantFlag`, the subset of `ChartFlag` an instant alone
  determines (`docs/de440.md`; `docs/evidence/positions-span-20261116/`).
- **Code that switches exhaustively over `ChartFlag`** needs cases for
  `"calendar-unknown"` and `"polar-angles"`.

### Client contract

- The compute clients' contract (`clients/typescript/contracts/openapi.json`,
  ahead of the hosted API) gains `"calendar-unknown"` in `ChartFlag`,
  `LocalResolution.flags` and `TimeResult.flags`, `"polar-angles"` in
  `ChartFlag`, and an optional `flags` on `BodyPosition` with the values
  `"outside-reference-span"` and `"delta-t-extrapolated"`, the instant flags
  the contract's `ChartFlag` already names. `provenance.json` and the
  generated TypeScript and Python contracts follow.

### Sizes and budgets

- Measured on this candidate's build with all four pull requests
  (`docs/evidence/2.0.0-rc.1-20261116/results/package-contents.log`):
  `./techniques` is 205,215 bytes, over its budget of 203,800 (the
  zone evidence in the local-time chunk it shares with `./geo`, 109's check
  and 111's flags): raised to 207,300. `./geo` is 36,178, over 35,700
  (110's zone evidence and 105's flag): raised to 36,500. `./receipt` is
  76,623, over 76,500 (the two flags' receipt checks): raised to
  77,400. Each is the measurement and about one per cent. The package
  beside the pack is 1,276,174 bytes unpacked in 98 files, over
  the cap of 1,265,000 (the four changes' code and declarations, this entry
  and the README's lines): raised to 1,289,000. None of these has the
  owner's approval; they are for the owner to decide with the candidate
  (`scripts/verify-package-contents.mjs`).

### Documentation

- README.md: this candidate's paragraph; the install section, which now
  names npm's `latest`, 1.1.0, and this candidate's archive; *Resolved
  instant inputs*, `saturnReturn`, *Uniform calculation API* and *Birth
  settings* on the bare-date refusal; the polar paragraph on `polar-angles`;
  the evidence folders.
- `docs/calc.md`, `docs/de440.md`, `docs/houses.md` and `docs/time.md` name
  2.0.0 where they said "the release after 1.1.0".

## 1.1.0 (2026-11-16)

A minor release: 1.1.0-rc.13 with the version changed. Checks:
`docs/evidence/1.1.0-20261116/`.

- **What 1.1.0 is over 1.0.0.** The entries below, 1.1.0-rc.1 to
  1.1.0-rc.13, are its history, and a caller moving from 1.0.0 reads them.
  The largest change: a plain call computes on a DE440 pack the package
  ships, for 1790 to 2210, in place of astronomy-engine, so positions inside
  those years move by the difference between the two ephemerides. Measured
  on JPL's kernel at noon TT on each day from 1800 to 2199, the largest is
  29.19 arcseconds of ecliptic longitude for the Sun, the Moon and the
  planets (Pluto, still growing at the end of the span) and 32.64 for the
  true node; 1790 to 1799 and 2200 to 2209 were not swept, so these are the
  largest measured, not a bound for the pack's whole span (1.1.0-rc.10,
  below). `setDefaultEphemeris("astronomy-engine")`
  gives 1.0.0's positions. On the pack a plain `natalChart` is within 1
  arcsecond of JPL Horizons (DE441) at all 240 position vectors of the
  conformance suite, 24 instants from 1851 to 2148
  (`src/de440-default.test.ts`).
- **No code or value changes from 1.1.0-rc.13.** The only change under
  `src/` is the version string (`ENGINE_VERSION`, the two tests and the
  fixture that hold it), and `dist/` is rc.13's but for that string
  (`docs/evidence/1.1.0-20261116/`).
- **The DE440 pack, accepted by the owner.** `LICENSING.md` held shipping the
  pack, which rests on the owner's reading that DE440 is JPL's public data,
  as an open question to be accepted by the owner in writing before
  publication. On 2026-11-16 the owner answered, in writing, the question "Do
  you accept shipping the NASA DE440 data in 1.1.0?" with "Yes. I delegate
  these decisions to you." `LICENSING.md` now records that answer. Its three
  other open questions (IERS EOP 20 C04, the CDS star values, Reid and
  Brunthaler's two values) are as they were at 1.0.0. It also now names the
  versions in its note on the licence field: 0.1.1-rc.8 to 0.1.1-rc.13
  declared `MIT` alone, and 0.1.1-rc.14 corrected it.
- **The size budgets raised in 1.1.0-rc.12, approved.** rc.12 raised nine
  import-graph budgets by about one per cent and the package cap from
  1,245,000 to 1,265,000 bytes beside the pack, for the owner to decide with
  the candidate. The maintainer approved them on 2026-11-16, after the
  owner's written answer above delegated the release's decisions, and they
  stand as rc.12 set them.
- **README.md.** The version line; the install section, which named
  1.1.0-rc.10's archive, now gives `npm install @zodiacs/engine` and this
  release's archive; the list of drafts; the unpacked size; the evidence
  folders.
- **Conformance results.** Run again on Node 22.22.2: the verdicts are
  rc.13's, and the results now name 1.1.0.

## 1.1.0-rc.13 (unreleased candidate)

The candidate for **1.1.0**, a minor release: 1.1.0-rc.12 with its
documentation corrected and nothing else. It is a draft for the owner, and is
not to be published on npm until the owner approves it. Checks:
`docs/evidence/1.1.0-rc.13-20261115/`.

1.1.0-rc.12 was a draft on this same pull request (101), reviewed with no
blocker and not tagged or published: this candidate replaces it. The
corrections below change `README.md`, `CHANGELOG.md`, `LICENSING.md` and
`NOTICE`, which the package holds, and rc.12's archive is carried, so by the
rule in `artifacts/README.md` the corrected package takes a new number. The
code is rc.12's: the only change under `src/` is the version string
(`ENGINE_VERSION`, and the tests and fixture that hold it), and `dist/` is
rc.12's but for that string (`docs/evidence/1.1.0-rc.13-20261115/`). No
position, bound, flag or size budget changes.

- **Credit to NASA JPL for the rule behind the Sun's disc.** The pack bends
  no light from a planet behind the Sun's disc because that is what NASA
  JPL's Horizons system does, and its radius of the Sun, 695,700 km, is
  Horizons's (1.1.0-rc.12, below). `NOTICE`, `LICENSING.md` and the README
  now say so and credit NASA JPL for the convention. Horizons's responses
  were the arbiter it was measured against; no Horizons response is in the
  package.
- **At the Sun's limb, said exactly.** rc.12's entry below and
  `docs/de440.md` gave the pack as within 0.0005 arcseconds of Horizons
  within 3 arcseconds of the limb. That holds only where both put the planet
  on the same side of the limb. Within a second or two of a limb crossing
  they can put it on different sides and then differ by the step at the
  limb: the rc.12 review found 4 such instants of 50, 1.4732 to 1.6956
  arcseconds apart, inside the 1.8 that `calc()` quotes there
  (`docs/evidence/1.1.0-rc.12-20261115/breaker/BREAKER.md`, should-fix 3).
  ERFA's `eraLdsun` figure is 5.76 arcseconds (5.761255 in the evidence),
  not 5.77.
- **A longitude search at the limb step, documented.** For a planet whose
  longitude steps back at the limb, a target longitude within the step is
  crossed three times, and `searchLongitudeCrossings` and calc's `events()`
  return one of them, the last, with a complete status
  (`docs/evidence/1.1.0-rc.12-20261115/breaker/BREAKER.md`, should-fix 2).
  `docs/de440.md` now says so. The search is unchanged.
- **rc.11's Neptune figure, marked as rc.11's.** The 1.1.0-rc.11 entry gave
  33.37 arcseconds for Neptune near the Sun as the size of the change; that
  came from rc.11's bending behind the disc, which rc.12 removed. The entry
  now says so and no longer reads as a property of this package.
- **The near-Sun evidence names its build.** The rows in
  `docs/evidence/1.1.0-rc.12-20261115/near-sun/` record the engine version
  `1.1.0-rc.11`: they were run on rc.12's source before its version string
  was raised. The rc.12 review recomputed all 6,720 rows on the installed
  rc.12 archive and found them identical to the bit (should-fix 1); that
  evidence's README now says so. rc.13's code is rc.12's, so they hold for
  this candidate too.
- **Not changed.** The size of the change from earlier releases stays as
  measured: up to 29.19 arcseconds of ecliptic longitude for the Sun, the
  Moon and the planets and 32.64 for the true node at noon TT on each day
  from 1800 to 2199 (1.1.0-rc.10, below). No larger round figure is given.
  The size budgets rc.12 raised are as rc.12 left them, for the owner to
  decide with the candidate.

## 1.1.0-rc.12 (unreleased candidate)

The candidate for **1.1.0**, a minor release: 1.1.0-rc.11 with the place of
a planet behind the Sun's disc made JPL Horizons's, the dense sweep's check
on the default source restored, and two more root results labelled. It is a
draft for the owner, and is not to be published on npm until the owner
approves it. Checks: `docs/evidence/1.1.0-rc.12-20261115/`.

1.1.0-rc.11 was a draft on this same pull request (101), reviewed and not
tagged or published: this candidate replaces it. Its archive stays in
`artifacts/`, as every carried archive does (`artifacts/README.md`), which is
why this cut has a new number. Everything below is against 1.1.0-rc.11.

- **No light deflection behind the Sun's disc, as JPL Horizons.** The
  pack's reduction bent a planet's light by the Sun with the form of ERFA's
  `eraLd` and a limiter of 1e-14, so behind the Sun's disc the deflection
  grew towards the centre without limit, and the default place was far from
  Horizons's: the rc.11 review measured 307.9 arcseconds for Mercury on
  1954-05-08, 195.5 for Uranus on 2029-06-04, 56.3 for Jupiter on
  2032-01-01, where `calc()` quoted 0.0037. Horizons applies the deflection
  outside the disc and none inside it: its places at three passages, every
  15 minutes for a day, are the kernel's with the deflection outside the
  disc and without it inside, to the change at the limb. Now the reduction
  bends no light from a planet farther than the Sun whose direction is within
  the Sun's apparent radius of the Sun's (R = 695,700 km, Horizons's).
  Measured against Horizons at every passage of Mercury to Pluto behind the
  Sun from 1800 to 2199 (393 passages, 3,490 instants inside the disc, 66
  within 3 arcseconds of the limb, 3,164 outside it), as the planet's
  offset from the Sun, which takes out the two frames' difference: within
  0.0023 arcseconds inside the disc and 0.0047 outside, where the 0.0047 is
  the comparison's own remainder (a reduction of `de440.bsp` with the same
  rule gives it too, and the pack is within 0.0038 of that reduction at all
  6,720 instants). Within 3 arcseconds of the limb the two agree to 0.0005
  only where both put the planet on the same side of it, as at all 66 of
  those instants here; within a second or two of a limb crossing they can
  put it on different sides, and then differ by the step at the limb: the
  rc.12 review found 4 such instants of its 50 in that band, 1.4732 to
  1.6956 arcseconds apart (`docs/evidence/1.1.0-rc.12-20261115/breaker/BREAKER.md`,
  should-fix 3), inside the 1.8 that `calc()` quotes there. The formula of
  rc.11, reduced from `de440.bsp`, is up to 333.48 arcseconds from Horizons
  inside the disc (Mercury), and ERFA's `eraLdsun` limiter, which tapers the
  deflection inside about 0.08 degrees, up to 5.76 (Uranus): which is why
  the candidate follows Horizons and not `eraLdsun`
  (`docs/evidence/1.1.0-rc.12-20261115/near-sun/`; [docs/de440.md](docs/de440.md),
  *Behind the Sun's disc*). What changes: the apparent place of Mercury to
  Pluto while behind the disc, in `natalChart()`, `positions()`, `calc()`
  and everything built on them. Elsewhere nothing changes, bit for bit:
  `positions()` of this build and of the carried rc.11 archive, at 20,000
  pseudo-random instants from 1800 to 2199 and the 6,720 near-Sun ones,
  differ in 3,583 of 320,640 rows, each a planet behind the disc
  (`docs/evidence/1.1.0-rc.12-20261115/results/unchanged.json`); the 2026 Sagittarius ingress
  is 2026-11-22T07:23:21 UTC to the second on every default-path search
  (`src/de440-ingress.test.ts`). At the limb the place steps by the
  deflection there, at most 4GM/c²R = 1.7512 arcseconds; Horizons's edge was
  found 0.06 to 0.17 arcseconds inside the engine's at five limb crossings,
  so within 3 arcseconds of the limb `calc()` quotes 1.8 arcseconds,
  estimated (`DE440_AT_LIMB`). A speed's two samples (±0.001 day) take the
  decision of the instant the speed is for, so a speed is the rate of the
  place on that side and never the step over 0.002 day (1.7512 arcseconds
  over 0.002 day is 876 arcseconds a day; `src/de440-behind-sun.test.ts`):
  `place(body, ttDays, behind?)` of a source returns `behindDisc` and takes
  `behind`, both optional, both new. The calc convention id is now
  `deflection:sun-outside-disc` (rc.10 and rc.11 wrote `deflection:sun`).
  The reduction is no longer the research runtime's operation for operation:
  zodiacs.org's check C9 will find the two apart for a planet behind the
  disc, and in a speed within 0.001 day of a limb crossing.
- **The birth-time window search near the Sun.** rc.10 raised a planet's
  rate bound near the Sun by the inverse square of its elongation and
  compared single milliseconds within 0.01° of the Sun's centre, because the
  deflection grew there. Behind the disc there is none now, so that raise is
  gone: within a degree of the Sun in longitude the search takes the
  deflection as a displacement of at most 1.8 arcseconds, as it takes the
  true node's jitter (`Sky.bend` in `src/window.ts`). The rate scan on the
  pack (`docs/evidence/1.1.0-rc.12-20261115/window/`) finds every bound
  held with its margin, bound over largest rate plus what the grid can miss
  1.634 to 2.057 (rc.10: 0.395 for Neptune, 1.455 for Uranus, 1.480 for
  Saturn).
- **The dense sweep checks the default source again.** From rc.11 the
  workflow swept astronomy-engine only. It now also sweeps the pack
  (`engine_sweep.mjs --ephemeris de440`) against the kernel's place with the
  Sun's deflection, none behind the disc, and a new job, *Sweep results on
  the DE440 pack*, holds every body's largest angle to
  `src/calc-bounds-de440.ts` (`check_pack.py`). The astronomy-engine run and
  its check against `src/calc-bounds.ts` are as they were. Run on this
  build over the 146,097 days: every body but the Moon within 0.0040
  arcseconds of the kernel (largest 0.003948), the Moon within 0.0045
  (0.004422), near the Sun too, where rc.11 was up to 17.308.
- **The pack's position bounds cover the dense sweep.** They were the
  largest angle from Horizons at the 240 L1 vectors alone, 0.0034 to 0.0038
  arcseconds for the Sun and the planets; the sweep finds up to 0.00395
  (the engine's IAU 2000B nutation against ERFA's 2000A in the frames of
  date). Each is now the larger of the two, rounded up: the Moon 0.013,
  Saturn 0.0039, every other body 0.0040 (`src/calc-bounds-de440.test.ts`
  holds both).
- **No silent fallback in `chartPoints` and `chartDeclinations`.** Given a
  birth they computed the chart themselves and their results named no
  ephemeris and carried no flag, so with the pack damaged, or at 1750 or
  2230, they returned astronomy-engine's values and said nothing. Both
  results now carry `ephemeris` (the chart's: `{ name: "jpl-de440", version }`
  or astronomy-engine's; null for a supplied chart that names none) and
  `flags` (the chart's `"de440-unavailable"` or `"outside-de440-span"`),
  given a birth or a chart (`src/ephemeris-fallback-root.test.ts`, and the
  packed-consumer check with the pack removed, damaged and undecodable). No
  other export that reads positions was found without a label (the sweep of
  every entry point's exports is in the evidence).
- **`saturnReturn` names astronomy-engine wherever its flags hold a
  fallback.** A search that began on the pack and ran past its end named
  `jpl-de440` beside `"outside-de440-span"`.
- **What names its ephemeris, said exactly.** `docs/de440.md` said every
  result names its ephemeris; the timing and vedic results,
  `moonSignCandidates` and `searchLongitudeCrossings` carry the fallback
  flags and name none. It now lists which do which.
- **Sizes.** The root entry's import graph is 150,170 bytes beside the pack,
  2,034 more than rc.11's (the disc rule, the labels, a speed's side of the
  disc), over its budget of 149,400: raised to 151,700. Eight graphs that
  share the root's chunks go over theirs with it and are raised the same
  way, to the measurement and about one per cent: `./calc` 202,042 to
  204,100, `./window` 149,947 to 151,500, `./timing` 169,473 to 171,200,
  `./vedic` 185,205 to 187,100, `./sky` 137,224 to 138,600, `./internal`
  109,770 to 110,900, `./de440` 53,988 to 54,600 and `./de440/pack` 55,208
  to 55,800. The package beside the pack is 1,253,195 bytes unpacked, over
  the cap of 1,245,000 (this entry, the README's lines and the code): raised
  to 1,265,000. None of these has the owner's approval; they are for the
  owner to decide with the candidate (`scripts/verify-package-contents.mjs`).
- **`docs/calc.md` on the deflection.** It said an apparent place has no
  deflection and that `SEFLG_NOGDEFL` is always so, which is astronomy-engine's
  case only; the pack's apparent place has it. `flags.deflection` is a request
  (`true` is refused) and a receipt echoes it as given; the conventions say
  what was applied.

## 1.1.0-rc.11 (unreleased candidate)

The candidate for **1.1.0**, a minor release: 1.1.0-rc.10 with every
techniques result labelled, the dense DE440 sweep's check fixed, and the
size of the change to positions said exactly. It is a draft for the owner,
and is not to be published on npm until the owner approves it. Checks:
`docs/evidence/1.1.0-rc.11-20261115/`.

1.1.0-rc.10 was a draft on this same pull request (101), reviewed and not
tagged or published: this candidate replaces it. Its archive stays in
`artifacts/`, as every carried archive does (`artifacts/README.md`), which is
why this cut has a new number. Everything below is against 1.1.0-rc.10.

- **No silent fallback in `@zodiacs/engine/techniques` either.** In
  1.1.0-rc.10 ten of its functions returned astronomy-engine's answer
  with no flag and no ephemeris name where the shipped DE440 pack could not
  be opened or the instant was outside it. Now each result says so, with the
  names and flags the rest of the package uses (`ephemeris`
  `{ name: "jpl-de440", version }` or astronomy-engine's; `flags`
  `"de440-unavailable"` or `"outside-de440-span"`, after
  `"outside-reference-span"`; the caller's own choice of astronomy-engine
  named and not flagged):
  - new fields `ephemeris` and `flags` on `voidOfCourseAt`'s result, on
    `compositeChart`'s (`ephemeris` null where the two charts do not name
    one and the same) and on `chartAspectPatterns`'s, now typed
    `ChartAspectPatterns` (`AspectPatterns` with the two fields;
    `aspectPatterns` is unchanged);
  - the same two fields on each element of `moonIngresses`,
    `moonAspects` and `voidOfCourseWindows` (and a window's `lastAspect`),
    each labelled by the positions it was found from, so a list that runs
    past an end of the pack labels each side;
  - new functions for those that return a bare value, which cannot carry a
    label: `solarReturnInstantDetailed`,
    `mostRecentSolarReturnInstantDetailed`, `lunarReturnInstantDetailed` and
    `moonSignsBetweenDetailed` take the same arguments as the plain function
    and return `{ value, ephemeris, flags }` (new type `DetailedResult`),
    `value` being the plain function's result; the plain functions are
    unchanged. `./internal` has `bodyLongitudeDetailed` and
    `longitudeSpeedDetailed` beside `bodyLongitude` and `longitudeSpeed`.
    `findLongitudeCrossings` keeps `searchLongitudeCrossings` as its labelled
    form. New types `TechniqueEphemeris`, `ChartAspectPatterns`,
    `DetailedResult`. No signature or existing field changes.
  Tests: `src/ephemeris-fallback-techniques.test.ts` (each of the twelve,
  with the pack whole, damaged, and outside it at 1750 and 2230, and after
  the caller's choice), and the packed-consumer check, which now also
  checks a techniques `Date` through its detailed form, its objects and a
  list's elements on the installed package with the pack removed, damaged
  and undecodable.
- **The size of the change to positions, said exactly.** The 29 arcseconds
  of 1.1.0-rc.10's first line are the largest difference at noon TT on each
  of the 146,097 days the sweep read, not a limit. In this candidate a
  planet passing behind the Sun moved more, because its pack bent the
  planet's light by the Sun behind the disc too
  (`docs/evidence/1.1.0-rc.11-20261115/results/near-sun.json` has the figures
  measured on this build). That no longer holds: from 1.1.0-rc.12 the pack
  bends no light behind the disc (1.1.0-rc.12, above), and outside it the
  bending is at most 1.7512 arcseconds, at the limb.
- **The dense DE440 sweep measures what its table holds.**
  `src/calc-bounds.ts` holds the bounds `calc()` quotes for astronomy-engine's
  results (on the pack it quotes `src/calc-bounds-de440.ts`), but from
  1.1.0-rc.10, when `calc()`'s default became the pack, the sweep's engine
  side measured the pack's apparent places and its check compared them with
  astronomy-engine's limits, and with an arbiter that leaves out the light
  deflection the pack applies. Its workflow failed on 1.1.0-rc.10 (run
  43618467433: the rates of Mercury to Pluto hundreds of arcseconds a day
  over, at the days a planet passed behind the Sun). The sweep's engine side
  now names the source it runs on (`--ephemeris`, astronomy-engine for the
  table), refuses a result another source computed, and compares a run on
  the pack with the kernel's place with the deflection; the table's tools
  refuse a run on the pack. Run with the fixed tools on 1.1.0-rc.10's head,
  whose position code this candidate keeps, over the same 146,097 instants,
  the engine's values on astronomy-engine are the same bytes as 1.1.0-rc.3's
  committed sweep in all eight eras, and every largest difference is within
  the limit the table quotes, so `src/calc-bounds.ts` is unchanged
  (`docs/evidence/1.1.0-rc.11-20261115/sweep/`). The workflow's run on this
  candidate's head is the measurement of this build. The pack's own bounds
  are still the 240 L1 vectors' (`src/calc-bounds-de440.ts`).
- **PR 102's flag on the pack.** `src/calc-delta-t-de440.test.ts` holds the
  `"delta-t-extrapolated"` flag and the widened bound on the pack, as
  `src/calc-delta-t.test.ts` does on astronomy-engine.
- **Sizes.** The techniques entry's import graph is 201,294 bytes, 3,483
  more than 1.1.0-rc.10's, over its budget of 199,900: raised to 203,800.
  The package beside the pack is 1,238,281 bytes unpacked, over the cap of
  1,225,000 (this entry and the README's lines, and the labels): raised to
  1,245,000. Neither has the owner's approval; both are for the owner to
  decide with the candidate (`scripts/verify-package-contents.mjs`).

## 1.1.0-rc.10 (unreleased candidate)

The candidate for **1.1.0**, a minor release: the DE440 default of
1.1.0-rc.9, now under every function, and a fallback that is never silent.
It contains 1.1.0-rc.7 and 1.1.0-rc.9, and the far-future ΔT warning of pull
request 102 (ZOD-65). It is a draft for the owner, and is not to be published
on npm until the owner approves it. Checks:
`docs/evidence/1.1.0-rc.10-20261114/`.

1.1.0-rc.9 was a draft on this same pull request (101). It was superseded
before review and was never tagged or published: this candidate replaces it.
Its archive stays in `artifacts/`, as every carried archive does, because a
version names one byte sequence and an archive is never repacked
(`artifacts/README.md`); that is why this cut has a new number.

- **Default positions move to DE440, and can shift by up to 29 arcseconds
  for the Sun, the Moon and the planets (33 for the true node).** From
  1.1.0-rc.9 `natalChart()`, `positions()` and the functions built on them
  compute on the shipped DE440 pack; from this candidate `calc()`, `chart()`,
  `events()` and `birthWindow()` do too, so every function gives the same
  position for the same instant. Against 1.1.0-rc.7 and every release before
  it, which computed on astronomy-engine, a position inside 1790 to 2210
  changes by the difference between the two ephemerides. The largest
  differences measured, astronomy-engine's apparent place against DE440 at
  noon TT on each of the 146,097 days from 1800-01-01 to 2199-12-31
  (`docs/evidence/de440-sweep-20261111/`), in arcseconds of ecliptic
  longitude of date: Pluto 29.19 (on 2199-12-31, and still growing), Venus
  22.92, Neptune 19.71, Mars 14.32, Mercury 14.12, Saturn 13.10, Uranus
  12.09, the Moon 11.92, Jupiter 10.64, the Sun 2.39; and the true node
  32.64, which is more than 29. As a whole angle the largest is Pluto's,
  29.86. The sweep read JPL's kernel, not the pack, whose places are within
  0.0016 arcseconds of the kernel's and whose true node is within 0.84
  (`docs/evidence/de440-20261110/pack-accuracy.json`); the years 1790 to
  1799 and 2200 to 2209 were not swept. Signs, houses near a cusp, aspects
  near their orb, speeds, and ingress and return times move with the
  positions: the Moon's 12 arcseconds are about 20 seconds of its motion.
  Mars to Pluto become planetary-system barycentres.
  `setDefaultEphemeris("astronomy-engine")` gives the earlier values at
  every instant.
- **`calc()`, `chart()`, `events()` and `birthWindow()` on DE440.** In
  1.1.0-rc.9 these stayed on astronomy-engine, so a default `calc()` and
  `positions()` could differ by up to 29.19 arcseconds for one instant.
  Now `calc()` takes from the pack what `natalChart()` takes from it: the
  apparent geocentric place of the Sun, the Moon and Mercury to Pluto, and
  the true node and its opposite point, in all eight frames (the pack's
  place is of date; another frame is reached from it with the engine's own
  nutation and precession). With every default it is `positions()`'s
  longitude, latitude and speed to the bit again, and `chart()` is
  `natalChart()`'s chart. `events()` searches the same longitudes as
  `searchLongitudeCrossings`. A `birthWindow()` is partitioned on the pack,
  so each cell holds what a lone `natalChart()` call gives. Each receipt
  names the ephemeris it used (`receipt.engine.ephemeris`, and
  `ephemeris:jpl-de440@<the pack's SHA-256>` among its conventions), and a
  window has a new `ephemeris` field.
- **What `calc()` still computes on astronomy-engine, and says so in its
  receipt:** a heliocentric, barycentric or topocentric position, an
  astrometric or geometric one, and the Earth. The pack's reduction makes
  the apparent geocentric place only; the others are defined by
  astronomy-engine's own steps (its barycentre, planet centres, no light
  deflection) and their bounds were measured on it. `natalChart()` gives
  none of them, so none disagrees with it, but a topocentric or geometric
  position and the default one for the same body rest on two ephemerides.
  Also unchanged, on astronomy-engine: the sky entry's rising, setting and
  planetary hours, and the vedic entry's star-anchored ayanamsas and
  `vargaSensitivity`. The mean node, the mean south node and Black Moon
  Lilith use no ephemeris. `houses()` uses none either.
- **Bounds of a `calc()` position from the pack.** They are no longer
  astronomy-engine's. `bounds.position` is the largest angle from JPL
  Horizons (DE441) at the conformance suite's 240 L1 vectors, 24 TT instants
  a body from 1851 to 2148, rounded up to two significant figures: the Moon
  0.013 arcseconds, the Sun and the planets 0.0034 to 0.0038
  (`src/calc-bounds-de440.ts`; `src/calc-bounds-de440.test.ts` recomputes
  every row and fails on a stale one). It is labelled `measured` in the true
  ecliptic of date, where it was measured, and `estimated` in the seven other
  frames. Twenty-four instants a body are few. The distance and the speed of
  such a position, and the true node, have been compared with no arbiter
  on the pack: their bounds are `null`, not astronomy-engine's.
- **Never a silent fallback.** Where a result that would have come from the
  pack comes from astronomy-engine instead, the result itself says so. Two
  new `ChartFlag` values (the type `EphemerisFallback`):
  `"de440-unavailable"`, when the pack could not be opened (its bytes are
  missing, their SHA-256 is not the sealed pack's, or they cannot be
  decoded; `defaultEphemeris().de440.error` says which), and
  `"outside-de440-span"`, when the instant is outside the pack's coverage
  less a day at each end. They appear last in `chart.flags`, in
  `calc()`'s and `events()`'s `flags`, in a window's `flags`
  (`"de440-unavailable"`; a window lies inside the pack's years), in
  the timing and techniques entries' `flags`, and in a natal receipt's
  `resultFlags`. And every result names its ephemeris: `chart.ephemeris` is
  now on every chart (`{ name: "astronomy-engine", version: "2.1.19" }`
  where it was absent before), each `BodyPosition` from the engine carries
  `ephemeris` (a name) and, on a fallback, `fallback` (the reason), so
  `positions()`, `transits()` and `progressedBodies()` say so row by row;
  `moonPhase()` carries the same two fields; `saturnReturn()` and a complete
  `searchLongitudeCrossings()` carry `flags`, which also report a search
  that runs past the end of the pack. `setDefaultEphemeris("astronomy-engine")`
  is the caller's own choice: the result names astronomy-engine and carries
  no fallback flag. `findLongitudeCrossings()` returns bare crossings and
  cannot say; use `searchLongitudeCrossings()` where it matters.
  Tests: `src/ephemeris-fallback.test.ts` (the pack missing, changed in one
  character, cut short, not base64; an instant outside it; the caller's
  choice), and the packed-consumer check, which does the same to the
  installed package's own file (`scripts/verify-packed-consumer.mjs`).
- **Compatibility of the new fields.** A chart's bodies now have two more
  possible keys, so code that compares a computed chart's bodies with a
  natal record's must leave `ephemeris` and `fallback` out: a record keeps
  the computed fields and names the ephemeris once. A natal receipt whose
  chart fell back carries the flag, which an engine before this candidate
  refuses as an unknown flag. A supplied chart may carry a fallback flag
  only if it names astronomy-engine (or, as a chart from an earlier
  release, names nothing).
- **Birth-time windows and the pack's records.** The pack is a series of
  Chebyshev fits; where a read passes from one record to the next, two fits
  meet within the pack's budget and not exactly: the true node steps by up
  to 1.11 arcseconds across the 96,049 such instants from 1800 to 2200, the
  Moon by up to 0.0011, the Sun and the planets by under 0.00025
  (`docs/evidence/1.1.0-rc.10-20261114/results/window-pack-seams.json`). The window search's bounds describe smooth motion, so it now
  treats each such instant as a seam, as it treats a leap second: the
  DE440 source's new `steps(fromTtDays, toTtDays)` lists them, a few in 48
  hours. `src/window-de440.test.ts` holds windows on the pack to
  `natalChart()` at every whole second and, around each seam, at every
  millisecond. The pack's reduction also bends light at the Sun, by the
  inverse of the angle from it, so a planet passing behind the Sun moves far
  faster in `natalChart()` than the body does (Neptune, 0.022° from the
  Sun's centre on 1920-08-03, at more than ten times the search's rate bound); the
  search raises its bound for Mercury to Pluto within a degree of the Sun by
  what that deflection allows. On the 1,000 preregistered random windows of `docs/evidence/birth-window/` (1800 to 2200, all thirteen systems), run on the pack, all 24,188 sampled transitions were matched, none missed and none extra, over 12,259,372 whole-second samples, and no window was flagged `bound-exceeded` (`docs/evidence/1.1.0-rc.10-20261114/`). On astronomy-engine the search
  is as it was.
- **A far-future clock time is flagged, and its bounds widened (pull request
  102, ZOD-65).** After the IERS table ends (2027-10-02 for this release's
  table) ΔT is extrapolated, and no arbiter can check it. A result that
  moves with it carries the new `ChartFlag` value `"delta-t-extrapolated"`:
  `natalChart()` and `chart()` on UTC or UT1 input, and on TT input where
  the chart has houses; `calc()` (new `flags`), `houses()` and `events()`
  (new `flags`), whose bounds grow by how far the result moves while TT and
  UT1 move by their 1-σ bands and are then labelled `estimated`
  (`docs/calc.md`, *Bounds*; `src/calc-delta-t.test.ts`). A natal receipt
  written by this candidate or later must carry the flag where its ΔT, time
  scale and houses call for it; earlier records, 1.1.0-rc.9's among them,
  are read without it. The topocentric Sun, Moon and Mars take the
  geocentric bound, labelled `estimated`, as every other topocentric body
  does. `ChartFlag` now has nine values.
- **API, additive.** `EphemerisFallback`; `Chart.ephemeris` on every chart;
  `BodyPosition.ephemeris` and `.fallback`; `MoonPhase.ephemeris` and
  `.fallback`; `SaturnReturnResult.ephemeris` and `.flags`;
  `CrossingSearchResult` `flags`; `BirthWindow.ephemeris` and the
  `BirthWindowFlag` value; `CalcPosition.flags`, `EventsResult.flags`;
  `PositionSource.place` may give `dist`, and `PositionSource.steps` is
  optional; a DE440 source gives both. `CalcReceipt`'s
  `engine.ephemeris.name` is typed `string`, where it was the literal
  `"astronomy-engine"`. New convention ids of a `calc()` receipt on the
  pack: `light-time:iterated`, `deflection:sun`,
  `aberration:relativistic-annual`, `target:system-barycentre`,
  `place:icrf-to-true-ecliptic-of-date`,
  `frame-bias:iau2006-fukushima-williams`, `nutation:iau2000b-p03`,
  `time:tdb-three-term` and `frame-turn:from-true-ecliptic-of-date`
  (`docs/calc.md`).
- **Conformance.** Regenerated on this candidate
  (`conformance/RESULTS.md`): the verdicts are 1.1.0-rc.9's. A plain call
  passes 459 of the 500 vectors, fails none, and 41 are unsupported (all 240
  position vectors pass); started with `--ephemeris astronomy-engine` the
  adapter gives 267, 192 and 41. Each position's `meta` now names the
  ephemeris on either run.
- **Licensing.** Unchanged from 1.1.0-rc.9: the pack is data refitted from
  JPL's DE440, `NOTICE` credits JPL and cites the ephemeris, and
  `LICENSING.md` (*DE440 pack*) records what the pack rests on.
- **Sizes.** The package is 4,540,059 bytes unpacked in 98 files, against
  1.1.0-rc.9's 4,502,147 and 1.1.0-rc.7's 1,152,017. 3,319,552 of them are
  the pack's base64 text, unchanged; the rest is 1,220,507, 37,912 more than
  1.1.0-rc.9's: documents 17,347 (this entry and the README's lines),
  JavaScript 14,156 (5,139 of it in the root's import graph, which is
  147,832 bytes beside the pack), declarations 6,408 and the
  manifest 1 (`docs/evidence/1.1.0-rc.10-20261114/sizes.json`, which
  also gives the packed sizes). The cap on the rest rises from 1,185,000 to
  1,225,000. Eleven import-graph budgets rise, each to its measurement and
  about one per cent: the root's from 144,000 to 149,400, `./calc`'s from
  190,000 to 199,900, `./window`'s from 142,500 to 149,500, `./techniques`'s
  from 194,500 to 199,900, `./timing`'s from 163,500 to 168,900, `./vedic`'s
  from 179,500 to 184,800, `./sky`'s from 132,000 to 136,400, `./internal`'s
  from 104,000 to 108,200, `./de440`'s from 50,700 to 53,200,
  `./de440/pack`'s from 52,000 to 54,400 and `./geo`'s from 35,600 to 35,700
  (`scripts/verify-package-contents.mjs` has each measurement and what the
  bytes are). Part of the growth is pull request 102's. None of these
  figures has the owner's approval: they are for the owner to decide with
  this candidate.

## 1.1.0-rc.9 (draft, superseded by 1.1.0-rc.10 before review)

Never tagged or published. 1.1.0-rc.10 above contains it and changes what
this entry's *The fallback, and what says so* and *What stays on
astronomy-engine* describe.

The next candidate for 1.1.0 after 1.1.0-rc.7, which it contains: the sealed
DE440 pack, shipped in the package, and the root entry computing on it by
default. It is a draft for the owner, and is not to be published on npm until
the owner approves it. Checks: `docs/evidence/1.1.0-rc.9-20261114/`.

There is no 1.1.0-rc.8 archive. 1.1.0-rc.8 was a draft cut on 1.1.0-rc.3 in
pull request 101 that shipped the pack behind `withEphemeris` only: a plain
call still computed on astronomy-engine. Before it was reviewed, main moved
to 1.1.0-rc.7, and its archive, which held none of 1.1.0-rc.6's or
1.1.0-rc.7's changes, was withdrawn where the branch joined main. The number
is not used again (`artifacts/README.md`).

- **DE440 by default.** A call in the root entry outside `withEphemeris`
  (`natalChart`, `positions` and the functions built on them, the crossing
  searches, `moonPhase`, and the opt-in entries that build on them) takes the
  Sun, the Moon, the planets and the true node from the shipped pack when its
  instant is at least a day inside the pack's coverage, which is 1790 to 2210,
  and from astronomy-engine otherwise. Nothing is opened, supplied or fetched
  by the caller, and no environment variable is read. A chart from the pack
  names it in `chart.ephemeris` (`jpl-de440`, with the pack's SHA-256), and
  its receipt is a DE440 receipt, which engines before 1.1.0-rc.3 refuse; a
  chart from astronomy-engine has no `ephemeris` property, as before.
- **Positions change.** `docs/versioning.md` lets a value change in a minor
  release when the engine computes it more accurately, with its size listed.
  Inside the pack's years every default position of the root moves from
  astronomy-engine's value to DE440's. The largest such moves found by the
  sweep of 1.1.0-rc.7, which compared astronomy-engine's apparent places with
  DE440 at noon TT on each of the 146,097 days from 1800-01-01 to 2199-12-31
  (`docs/evidence/de440-sweep-20261111/`), are, in arcseconds: Sun 3.4, Moon
  12, Mercury 17, Venus 24, Mars 23, Jupiter 17, Saturn 24, Uranus 20,
  Neptune 22, Pluto 30, the true node 33. (The sweep read the kernel; the
  pack's own places were not swept, and 1790 to 1799 and 2200 to 2209 were
  not in it.) Mars to Pluto become planetary-system barycentres. Speeds,
  aspects, house placements near a cusp, ingress and return times move with
  them. `setDefaultEphemeris("astronomy-engine")` gives 1.1.0-rc.7's values
  at every instant, to the bit.
- **Accuracy against Horizons.** A plain `natalChart` is within 1″ in
  longitude and in latitude of JPL Horizons (DE441, in the IAU 2006/2000A
  true ecliptic of date) at all 240 L1 vectors of the conformance suite: 24
  TT instants from 1851 to 2148, the Sun, the Moon and the planets, Mars to
  Pluto as system barycentres. The largest differences are 0.0127″ in
  longitude and 0.0011″ in latitude, both the Moon's
  (`src/de440-default.test.ts`, which enforces them; the same on the package
  installed from its archive, `docs/evidence/1.1.0-rc.9-20261114/`). On
  astronomy-engine 48 of the 240 pass. The vectors do not test the true node,
  speeds, or instants outside those years.
- **The fallback, and what says so.** New in the root: `defaultEphemeris()`
  reports the default (`"de440"` or `"astronomy-engine"`), whether the pack
  opened, its SHA-256, the two instants between which it is used, and why it
  did not open if it did not; `setDefaultEphemeris(name)` chooses. If the
  pack's bytes are not the sealed pack's, or the runtime cannot decode them,
  the engine computes on astronomy-engine, does not throw, and every chart
  says which ephemeris it came from. A search across an end of the pack reads
  two ephemerides, one on each side (`docs/de440.md`, *The default source*).
- **What stays on astronomy-engine.** The calc entry (`calc`, `houses`,
  `chart`, `events`), `birthWindow`, the sky entry's rising, setting and
  planetary hours, and the vedic entry's star-anchored ayanamsas and
  `vargaSensitivity` compute as before, with the bounds measured on
  astronomy-engine, and name it; they still refuse inside `withEphemeris`. A
  default `calc()` position and the root's `positions()` were equal to the
  bit; inside the pack's years they now differ, within the limits `calc()`
  quotes. No receipt of `calc()` carries a bound for a DE440 position.
- **`@zodiacs/engine/de440/pack`**, a new entry point (seventeen public entry
  points): `DE440_PACK` describes the pack (`de440-1790-2210.v2.zeph`,
  2,489,664 bytes, SHA-256
  `51428874d9a47213abc0ff42cbcec65f338624eaa2d8831f0e6ddc3654bf1fa7`, refitted
  by zodiacs.org's pack compiler 2.0.0 from NAIF's `de440.bsp`),
  `de440PackBytes()` gives its bytes, and `shippedDe440Source()` the source
  the root's default uses (`openShippedDe440Pack()`, the same as a promise).
- **`@zodiacs/engine/de440`** gains `openDe440PackSync`, `openDe440Pack`
  without WebCrypto and without a promise, which checks the digest with the
  engine's own SHA-256 (`src/de440/sha256.test.ts` compares it with Node's).
- **Conformance.** The suite's adapter answers every request with a plain
  call: 459 of the 500 vectors pass, none fails and 41 are unsupported, where
  1.1.0-rc.7 had 267, 192 and 41. Started with `--ephemeris
  astronomy-engine` it sets the fallback, and those results (267, 192 and
  41, 1.1.0-rc.7's verdicts) are committed beside the first and checked in
  continuous integration (`conformance/RESULTS.md`).
- **Licensing.** The pack is data refitted from JPL's DE440. `NOTICE` cites
  the ephemeris and says that Zodiacs.org made the pack; `LICENSING.md`
  (*DE440 pack*) records what NAIF's rules for SPICE kernels state, that they
  do not speak of data refitted from a kernel, and that shipping the pack
  rests on the owner's position of 2026-11-13 that DE440 is JPL's public
  data: an open question for the owner before publication. The licence
  expression is unchanged.
- **Sizes.** The package is 4,502,147 bytes unpacked in 98 files, against
  1.1.0-rc.7's 1,152,017 in 94: 3.9 times. 3,319,552 of those bytes are the
  pack's base64 text, in one shared chunk; the rest is 1,182,595, 30,578 more
  than 1.1.0-rc.7 (`docs/evidence/1.1.0-rc.9-20261114/sizes.json`, which
  also gives the packed sizes). The pack compresses little, so every install
  downloads about eight times what 1.1.0-rc.7's did, and, because the root
  entry now imports the pack, so does every application that bundles the
  root, `./calc`, `./sky`, `./techniques`, `./timing`, `./vedic` or
  `./window`: the root's import graph is 142,693 bytes beside the pack's
  3,319,552, where 1.1.0-rc.7's was 108,531. The package gate holds the pack
  to its exact size and digest, in one file, measures every graph without it,
  and caps the rest of the package: that cap rises from 1,155,000 to
  1,185,000, the budgets of the eight graphs that load the ephemeris rise by
  the code that reads a pack (the root's from 109,000 to 144,000), `./de440`'s
  from 48,000 to 50,700, and `./de440/pack` gets 52,000
  (`scripts/verify-package-contents.mjs`). None of these figures, and not the
  size itself, has the owner's approval: they are for the owner to decide
  with this candidate.

## 1.1.0-rc.7 (unreleased candidate)

The next candidate for 1.1.0 after 1.1.0-rc.6, which it contains: the error
limits a `calc()` result quotes, now from a far larger comparison. It is not
to be published on npm until the owner approves it.

- **Error limits from 146,097 daily comparisons with DE440.** Each position
  from `@zodiacs/engine/calc` carries `bounds`: how far its position,
  distance and speed were found to be from an independent ephemeris. For
  the geocentric Sun, Moon, Mercury to Pluto (each correction) and the true
  node and its opposite point, these were the largest differences from JPL
  Horizons at 32 instants, and on other days the engine went past ten of
  the eleven apparent position limits. They are now the largest differences
  from JPL's DE440 at noon TT on each of the 146,097 days from 1800-01-01 to
  2199-12-31, in all eight frames, rounded up to two significant figures
  (`docs/evidence/de440-sweep-20261111/`). Position limits of the apparent
  places, in arcseconds, old to new: Sun 3.0 to 3.4, Moon 8.3 to 12,
  Mercury 9.3 to 17, Venus 11 to 24, Mars 6.6 to 23, Jupiter 13 to 17,
  Saturn 18 to 24, Uranus 20 (unchanged), Neptune 21 to 22, Pluto 25 to 30,
  and the true node and its opposite point 16 to 33. The astrometric and
  geometric rows and the distance and speed limits of the same bodies move
  by the same rule (`src/calc-bounds.ts`); none falls. `docs/versioning.md`
  lets a bound found to be wrong be corrected in a minor release; these are
  such corrections. Each bound's `basis` now names the comparison it rests
  on.
- **What they mean.** They are the largest differences found at one instant
  a day, not proven limits. The true node's is 33 arcseconds, so "within 30
  arcseconds of DE440" holds for the Sun, the Moon and the planets only.
  Pluto's largest is 29.86 arcseconds (29.19 in ecliptic longitude), on the
  last day and still growing: a thin margin, for 1800 to 2199 only.
- **What keeps the old limits.** The 72 rows the sweep did not take
  (heliocentric, barycentric and topocentric positions, and the mean nodes
  and Black Moon Lilith) keep their values and their basis. The topocentric
  Sun, Moon and Mars keep limits (3.0, 7.8 and 6.6 arcseconds) below the
  geocentric ones the sweep found ([docs/calc.md](docs/calc.md)).
- **No position changes.** This candidate computes the positions 1.1.0-rc.6
  and 1.1.0-rc.3 compute (`docs/evidence/1.1.0-rc.7-20261111/`).
- **Sizes.** The package is 1,152,017 bytes unpacked in 94 files, 3,690 more
  than 1.1.0-rc.6's 1,148,327: this entry 2,888, the README's lines 379,
  LICENSING.md and NOTICE 365, and JavaScript 58. That is over the cap
  of 1,150,000, which rises to 1,155,000 (`scripts/verify-package-contents.mjs`,
  `docs/evidence/1.1.0-rc.7-20261111/sizes.json`), a rise the owner decides
  with this candidate. No entry point's budget changes.

## 1.1.0-rc.6 (unreleased candidate)

The next candidate for 1.1.0 after 1.1.0-rc.3 (main at `bc0b5a7`): a choice
for a birth in an hour the clock showed twice. It is not to be published on
npm until the owner approves it.

Two drafts came before it, and neither archive is carried here. 1.1.0-rc.4
was drafted in pull request 89 with this choice and with a refusal of a birth
given as a calendar date with no time. It was not merged. The refusal changes
documented behaviour, and by the owner's decision of 2026-11-11 it is held
for 2.0.0: in 1.x a birth's `utc` given as `YYYY-MM-DD` is read as midnight
UTC, as the README's *Resolved instant inputs* says. 1.1.0-rc.5 was drafted
in pull request 90 with the choice alone. An independent review of it found
that it recorded `"later"` for times that have no second pass, and it was
superseded by this candidate before merging.

- **`fold: "earlier" | "later"`** in `@zodiacs/engine/geo`.
  `resolveLocalToUtc`, `resolveLocalBirth` and `resolveBirth` take the new
  option for a wall time the clock showed twice. The default, `"earlier"`,
  gives what earlier versions gave. With `fold: "later"`, 01:30 in New York
  on 2021-11-07 resolves to 06:30 UTC where the default gives 05:30 UTC.
  Both passes carry the `dst-fold` flag and the same `jump` and `transition`,
  so a birth form can ask which pass it was and resolve again. The option
  changes nothing for a time the clock showed once, neither the result nor
  the record a receipt keeps, and a skipped time moves forward by the jump
  whichever value is given. The expected instants in
  `src/geo/fold-choice.test.ts` are written out from the IANA time zone
  database's rules ([docs/time.md](docs/time.md)).
- **Receipts.** `localResolution.policy.fold` records the pass taken:
  `"later"` only for a repeated time whose later pass was asked for,
  `"earlier"` for every other time. The codec checks it against the instant
  and the recorded clock change: an `"earlier"` record of a repeated time
  must fall before the change, a `"later"` one at or after it, inside the
  repeated span, and a `"later"` record without the `dst-fold` flag is
  refused as `invalid_context`. 1.1.0-rc.1 and 1.1.0-rc.3 refuse a record
  that says `"later"` as `unsupported_feature`, and read this candidate's
  `"earlier"` records, among them those of an ordinary and of a skipped time
  asked for their later pass (`docs/evidence/1.1.0-rc.6-20261111/`).
  Records that say `"earlier"`, which is every record written before this
  candidate, are read as before.
- **`api/`.** `api/geo.api.md` gains the exported type `FoldChoice` and the
  optional `fold` of the three functions' options. It and
  `api/receipt.api.md` widen `policy.fold` from `"earlier"` to
  `"earlier" | "later"`, a new member of a union a result carries, which
  `docs/versioning.md` allows in a minor release.
- **`lunarReturn`** still refuses a birth flagged `dst-fold`, whichever pass
  was chosen.
- **Sizes.** The option, its input check and its error message make
  `./geo`'s import graph 35,584 bytes, over its budget of 35,500, which
  rises to 35,600. The package is 1,148,327 bytes unpacked in 94 files,
  5,509 more than 1.1.0-rc.3's 1,142,818: this entry 3,499, the README's
  lines 355, declarations 927 and JavaScript 728. That is over the
  cap of 1,145,000, which rises to 1,150,000
  (`scripts/verify-package-contents.mjs`,
  `docs/evidence/1.1.0-rc.6-20261111/sizes.json`). The owner approved both
  rises on 2026-11-11.

## 1.1.0-rc.3 (unreleased candidate)

The third candidate for 1.1.0, on 1.1.0-rc.2 (main at `883371f`): positions
from JPL's DE440, for zodiacs.org's hosted compute API (its programme unit
P4.1), with sixteen public entry points. It is not to be published on npm
until the owner approves it.

- **`@zodiacs/engine/de440`**, a new entry point. `openDe440Pack(bytes,
  { expectDigest })` opens a sealed pack (`ZODEPH02`) of Chebyshev series that
  zodiacs.org's research runtime refits from NAIF's `de440.bsp` and quantises,
  refuses it unless its SHA-256 is the one expected and its trailer and
  header check, and returns a source that places the Sun, the Moon, the
  planets and the true node. The reduction is the research runtime's, ported
  operation for operation: light-time, deflection of light by the Sun,
  relativistic annual aberration, IAU 2006 precession with frame bias, IAU
  2000B nutation (the engine's own terms, arguments and offsets,
  P03-adjusted) and the true obliquity; Mars to Pluto are planetary-system
  barycentres. The geocentric Moon is formed from the Earth-Moon system's
  parts, so that the barycentre's speed never multiplies the rounding of the
  light-time epoch. Six-byte quantised fields, which the runtime's reader
  decodes wrongly, are refused. The entry fetches nothing and ships no pack.
- **Accuracy.** On the raw kernel the reduction is within 1e-6″ of an ERFA
  chain over `de440.bsp` at 200 instants from 1800 to 2200, place and node.
  A pack adds its refit: on the pack compiled for 1790 to 2210, against the
  kernel at 20,001 instants from 1800 to 2200 TT and at the edges of its
  records, the Moon's place differs by at most 0.0016″, every other body's by
  at most 0.0008″, and the true node by at most 0.84″, at an edge of the
  Moon's records (`docs/evidence/de440-20261110/pack-accuracy.json`).
- **`withEphemeris(source, fn)`** in the root runs `fn` with the root's body
  positions from a source (`positions`, `natalChart` and what is built on
  them, the crossing searches, `moonPhase`), and restores the one before. A
  chart computed inside names it (`chart.ephemeris`); a chart from
  astronomy-engine is unchanged. The functions that compute positions from
  astronomy-engine themselves, or whose bounds were measured on it (the calc
  entry, the sky entry's rising, setting and planetary hours, the vedic
  entry's star-anchored ayanamsas and `vargaSensitivity`, the window entry's
  `birthWindow`), throw a TypeError inside it.
- **Natal receipts** of a chart from a DE440 pack carry a new conventions
  set, the current one with the positions, the Moon and the frame of the
  DE440 reduction, name the ephemeris `jpl-de440` with the pack's SHA-256 as
  its version, and require the feature `ephemeris-jpl-de440`, so that an
  earlier engine refuses them. The set is the last of
  `NATAL_RECEIPT_CONVENTION_SETS`, so no earlier set's index moved. On a
  DE440 receipt, a provenance claim about the ephemeris must name its pack.
- **Checks.** `src/de440.test.ts` and `src/de440-format.test.ts` (synthetic
  packs, float64 and quantised, against values written independently: the
  digest checks, the reader, the switch, the refusals, the receipts),
  `src/de440-sources.test.ts` (no astronomy-engine position function is
  called under a DE440 source in the calls zodiacs.org's compute API makes)
  and `src/de440-kernel.test.ts` (with PRECISION_KERNEL set, the 1e-6″ gates).
- **Sizes.** The entry and the switch make the package 1,142,818 bytes
  unpacked, 46,035 more than 1.1.0-rc.2's 1,096,783: opt-in JavaScript
  (`dist/de440.js`, its own chunks and the refusals) 29,536, the root's
  JavaScript 2,206 (`withEphemeris` and the source's path in the ephemeris
  chunk, which every entry that loads it carries), declarations 6,866,
  documents 7,271 and the manifest 156
  (`docs/evidence/de440-20261110/sizes.json`). The cap rises from
  1,100,000 to 1,145,000, with a budget of 48,000 for `./de440` and raised
  budgets for `./internal` (69,000), `./time` (42,600) and `./window`
  (107,000), with the owner's approval of 2026-11-10; the root's rises to
  109,000 and `./vedic`'s to 144,500 under the owner's delegation of
  2026-11-04 (`scripts/verify-package-contents.mjs`).

## 1.1.0-rc.2 (unreleased candidate)

The second candidate for 1.1.0, on 1.1.0-rc.1 (main at `a253973`):
corrections of statements that said more than their evidence; two new entry
points that load no ephemeris, `@zodiacs/engine/time` and
`@zodiacs/engine/lite`, which make fifteen public entry points; time bands in
`@zodiacs/engine/calc`; and the birth-time sensitivity of the vargas in
`@zodiacs/engine/vedic`. The 500 conformance verdicts are 1.1.0-rc.1's: 267
pass, 192 fail, 41 unsupported, none in error. It is not to be published on
npm until the owner approves it. Checks: `docs/evidence/1.1.0-rc.2-20261102/`.

- **Corrections (zodiacs.org's finding F-89).** Statements that 1.0.0 and
  1.1.0-rc.1 made in the README, NOTICE, LICENSING.md and doc comments, and
  that zodiacs.org's claims ledger found to say more than their evidence, now
  say what was measured or what the code does
  (`docs/evidence/1.1.0-rc.2-20261102/f89/`). The README no longer says that
  the Vertex and the East Point agree with Swiss Ephemeris's
  `swe_houses_armc` to within 0.00001″ given its inputs, which zodiacs.org's
  points record of 0.1.1-rc.10 does not bear out; it gives the conformance
  suite's figures instead, within 0.014″ and 0.007″ on its ten L2 vectors for
  them, from 1833 to 2182, whose arbiter is ERFA (`conformance/RESULTS.md`,
  which rounds to the nearest 0.001″, and `conformance/results/summary.json`).
  A plain 5-day crossing scan can miss a station that takes the body less than
  |f″|h²/8 past the target: up to 0.0056° for Saturn and 0.011° for Jupiter at
  their stations from 2019 to 2024, not the 0.0103° and 0.0205° given before. A
  local-time resolution names a transition only where there is one, and no
  tzdb version where the runtime reports none. The Gregorian adoption table is
  in a shared chunk that `dist/geo.js` and `dist/techniques.js` import. The
  calc bounds of the mean node, the mean south node and Black Moon Lilith were
  measured against their definitions evaluated with ERFA, and their `basis`
  now says so; their speed bounds' basis also says that their speeds were
  compared in the true ecliptic of date only. No bound's value changes.
  Placidus's step count near the polar limit is no longer given. Munkasey's
  co-ascendant can lie west of the meridian within ε of the equator, not
  within 90° − ε. `ChartInput.deltaT` falls back to the engine's time basis.
  Receipts name the ephemeris from the rc.8 conventions set on, not only in
  the current one.
- **`@zodiacs/engine/time`** (zodiacs.org's finding F-53), a new entry point
  that loads no ephemeris: `timeBasis(ms, scale, pin)`, an instant's UT1 and
  TT with the `deltaT` and `timeScale` records a chart carries, and
  `elapsedDays`; `EPHEMERIS_SPAN`; and the frame of date the ephemeris uses,
  `tilt`, `eclipticFrame`, `meanEcliptic` and `eclipticOfDate`; with
  `DELTA_T_IERS_MODEL`, `TIME_SCALE_NAMES` and the types they take and give
  (`api/time.api.md`, `docs/time.md`). Each is the function a chart computes
  with, behind a check that throws `RangeError` for an argument it refuses;
  `tilt` and `eclipticFrame` give frozen results, so a caller cannot change
  the frame the engine keeps for its next chart. Through them
  astronomy-engine's vectors give `natalChart`'s longitudes to the bit
  (`src/time.test.ts`; the preregistered checks are in
  `docs/evidence/1.1.0-rc.2-20261102/time-entry/`). The root does not import
  the entry. zodiacs.org bundled these functions from `dist/` until now. The
  nutation and frame modules move out of the ephemeris chunk into a shared
  chunk that it and `dist/time.js` import (NOTICE, LICENSING.md), so each
  graph that loads the ephemeris grows by the imports and exports that join
  the two.
- **Bands from the time basis** (zodiacs.org's unit P1.M3c).
  `timeBands(record)`, exported by `@zodiacs/engine/time`, gives the 1-σ
  bands, in seconds, of the TT and the UT1 of a recorded instant (a
  `TimeBasis`, a chart, a calc instant, or a natal result from the time-basis
  set on) from its two recorded bands, `deltaT.sigma` and
  `timeScale.ut1MinusUtc.sigma`, by the scale the instant was given on and the
  basis that gave UT1 and TT (`docs/time.md`, *The time bands*). On UTC input
  from 1972-01-01 to 2027-10-02 without a pinned ΔT, TT comes from the leap
  seconds (exactly to 2027-06-28, when the shipped list expires; after it the
  list's last value is carried, with no band for a leap second not yet
  announced), so its band is 0, and UT1 carries the band of UT1 − UTC; with a
  pin, TT is UT1 plus the pin and takes UT1's band; after the table, TT takes
  both bands, combined as the root of the sum of their squares. It reads the
  recorded fields only, and throws `RangeError` for a record without a time
  scale. `@zodiacs/engine/calc` carries the bands into its results, to first
  order, as a new `band` field kept apart from `bounds` (`docs/calc.md`,
  *Bands*), and exports the `TimeBands` and `CalcTimeBand` types they use:
  `calc()`'s positions (null without speeds), from each coordinate's rate
  times the TT band, with a conservative bound on the observer's turn for a
  topocentric one, and for the true nodes from their speed over ±0.25 day,
  which smooths their short-period motion; `houses()`' angles and cusps, from
  each one's rate on UT1 times the UT1 band plus its rate on TT times the TT
  band (in the sidereal zodiac the sidereal longitude's, the ayanamsa's rate
  in it), whole-sign and fallback cusps 0; each event's UTC and UT1; and
  `chart()`'s bodies, ascendant and midheaven. So on UTC input from
  1972-01-01 to 2027-10-02 without a pinned ΔT every geocentric, heliocentric
  and barycentric position's band is 0. Each receipt names the new id
  `time-band:first-order`, last, but `calc()`'s without speeds; `events()`'
  even when it finds no event. A band is not a bound on the error and leaves
  out the ephemeris's error. Root charts, natal envelopes and the other
  entries' results carry none. The preregistered
  checks are in `docs/evidence/1.1.0-rc.2-20261102/time-bands/`.
- **`@zodiacs/engine/lite`** (zodiacs.org's units P2.E: declinations, sect,
  composite and dignities), a new entry point that loads no ephemeris: the
  root's declination parallels and out-of-bounds flags
  (`findDeclinationAspects`, `declinationsForBodies`, `declinationOf`,
  `declinationOrb`, `eclipticToEquatorial`, with their constants and types),
  `@zodiacs/engine/techniques`' composite midpoints and their aspects and its
  essential dignities with their tables and mutual reception, and
  `sectReading`, new: a chart's sect under the convention a caller names,
  `"altitude"` (the Sun's altitude, which the caller computes; day from 0 up)
  or `"ecliptic"` (the root's `sectOf`), with the sect light, Mercury's side
  of the Sun (`orientality`) and the planets in and out of sect
  (`docs/lite.md`, `api/lite.api.md`). There is no default convention, and
  `sectOf` does not change. Each function and table of the declination,
  composite and dignity parts is a copy of the root's or the techniques
  entry's, with the same results and not the same object; the declarations are
  theirs. Each of the four parts is built into a file of its own that imports
  nothing (`scripts/build-lite.mjs`, which `npm run build` runs after tsup),
  and `npm run exports:smoke` checks that the entry holds only its pinned
  modules and loads in a Node process that cannot load astronomy-engine
  (`scripts/lite-entry.mjs`; the preregistered checks are in
  `docs/evidence/1.1.0-rc.2-20261102/lite/`). The composite functions and the
  techniques' name helpers move to modules of their own
  (`src/techniques/composite.ts`, `src/techniques/names.ts`), with no public
  change. esbuild 0.27.7, the version tsup runs, is now a direct dev
  dependency.
- **The birth-time sensitivity of the vargas** (zodiacs.org's unit
  P2.B.vargas). `vargaSensitivity(natal, ayanamsa, options?)`, exported by
  `@zodiacs/engine/vedic` with `VARGA_POINTS` and seven types, gives for each
  point and varga the first millisecond after the birth at which the point's
  varga sign changes and the last change before it, up to 2,880 minutes on
  each side: the instant, its minutes from the birth, the boundary crossed and
  the signs on either side (`docs/vedic.md`, *Birth-time sensitivity*). The
  points are the Ascendant, the Sun to Pluto and the two mean nodes; the true
  node is not offered. Each instant is exact in the engine's own arithmetic on
  the chart's clock, as `siderealChart` and `chartPoints` compute the
  positions, which is not a claim of accuracy. That none is missed rests on
  derived rate bounds for the Ascendant and the mean nodes, and on bounds
  scanned, not derived, for the bodies. A row the search cannot compute
  carries a typed refusal:
  `no-angles`, `polar` (more than 66° from the equator), `out-of-range`
  (outside 1800 to 2200), `rate-bound` or `evaluation-budget` (2,000,000
  evaluations a call). `vargaOf` places a longitude as before, through an
  internal function that takes a whole tick, and the vargas' change
  boundaries are held to an engine-free fixture,
  `src/vedic/fixtures/varga-changes.json` (the preregistered checks are in
  `docs/evidence/1.1.0-rc.2-20261102/varga-sensitivity/`).
- **Sizes.** `./time`'s import graph is 42,306 bytes in 7 files and
  `./lite`'s 28,930 in 5, under budgets of their own, 42,400 and 29,000
  (94 and 70 bytes left). `./calc`'s is 151,426 bytes, 6,165 more than
  1.1.0-rc.1's 145,261, for the corrections, the time bands and the chunks it
  shares with `./time`: over its budget of 145,500, which this candidate
  raises to 156,000. `./vedic`'s is 141,340, 13,589 more than 127,751, for
  the varga sensitivity and the same chunks: over its budget of 128,000,
  raised to 143,000. The graphs of the root, `./internal`, `./internal/math`,
  `./receipt`, `./sky`, `./techniques`, `./timing` and `./window` grow by 49
  to 405 bytes, the root's by 345 to 106,325, for the imports and exports
  that join the chunks `./time` shares with them (and, in `./techniques`, the
  two modules the composite functions and the name helpers moved to); none
  of their budgets is raised, and `./window`'s leaves 443 bytes. The package
  is 1,096,783 bytes unpacked in 90 files, 90,289 more than 1.1.0-rc.1's
  1,006,494, over the cap of 1,020,000, which this candidate raises to
  1,100,000 for the two entries, the bands, the varga sensitivity, the
  corrections and their documentation, rather than move the CHANGELOG's 0.x
  history out of the package: 50,692 bytes of JavaScript that only the
  opt-in entry points load, 21,520 of declarations, 17,312 of README,
  CHANGELOG, LICENSING.md and NOTICE, 420 of manifest and 345 of the root's
  graph (`sizes.json`). The two new budgets, the two raised ones and the cap
  are the ceilings approved under the owner's delegation of 2026-11-03 (OQ3
  in `docs/evidence/1.1.0-rc.2-20261102/OWNER-ANSWERS.md`), not about 5 per
  cent over a measured graph as before; `scripts/verify-package-contents.mjs`
  gives each graph's headroom.

## 1.1.0-rc.1 — unreleased candidate

The first candidate for 1.1.0, on 1.0.0 (main at `4771fa6`): natal receipts
name their conventions as ids of the Zodiacs conventions registry, and a new
entry point gives those ids. No value changes. It is not to be published on
npm until the owner approves it. Checks: `docs/evidence/1.1.0-rc.1-20261026/`.

- **Receipts carry their ids.** `createNatalEnvelope` writes a new
  conventions set, 1.0.0's with `conventionIds:
  "zodiacs-conventions-registry;receipt-and-result;sorted-unique;in-receipt"`,
  and `receipt.conventionIds`: every id, in the registry's syntax (a
  namespace, a colon and a value), that the receipt and its result name, in
  code-unit order, each once. From the receipt, each conventions and coverage
  field's key and value (`zodiac:tropical`), the requested and actual house
  systems (`house:placidus`), why there are no houses, each flag, the
  reference, the instant's scale (`time-scale:utc`) and the ephemeris
  (`ephemeris:astronomy-engine@2.1.19`); from the result, the ΔT model and
  segment, the time basis and the source of UT1 − UTC (`time-basis:iers`).
  That is the rule of zodiacs.org's registry tests, and the registry it
  publishes (version 2026-10-18) holds every id these receipts name but the
  new set's own, which the site adds when it adopts this release
  (`results/site-rule.txt`). The tests' timed chart in New York with
  Placidus houses names 26; a flag or a polar fallback adds its own. The
  codec requires the ids under the new set, exactly as the envelope's fields
  give them, and refuses them under any other.
- **Records.** An envelope of the new set requires the feature
  `convention-ids`. Each carried archive from 0.1.1-rc.7 to 1.0.0 refuses
  such a record as `unsupported_feature`, as docs/versioning.md says an
  earlier release refuses a set it does not know; without the feature they
  would refuse it as `invalid_shape`, because they read a receipt's fields
  before its set (`results/earlier-readers.json`). docs/versioning.md now
  asks a feature of every new set. This release reads every record 1.0.0
  reads. A receipt names the engine that computed its chart, which may be
  earlier or later than the one that wrote it, so the new set is accepted
  from 0.1.1-rc.16, as 1.0.0's is, with no upper bound. A receipt written by
  the carried 1.0.0 archive (`src/fixtures/receipt-1.0.0.json`) parses,
  serializes to its own bytes, and replays to positions, angles and cusps
  within 1e-9° of its own (`src/receipt-ids.test.ts`).
- **`@zodiacs/engine/conventions`**, a new entry point that imports no
  module of another entry: `natalConventionIds(envelope)`, which names a
  1.0.0 envelope's ids too; `conventionId(namespace, value)`;
  `parseConventionId(id)`, which gives a `ConventionIdParts`, the value being
  everything after the first colon;
  `conventionAddress(id)`, the registry's page with the id through
  `encodeURI` as its fragment; and `CONVENTIONS_REGISTRY`. The three that
  take an id throw a `RangeError` for a malformed one. The root does not
  import the entry. `NatalReceipt` gains the optional `conventionIds`; `api/`
  records both.
- **Migration.** Reading records needs nothing. Code that builds an envelope
  by hand may keep writing 1.0.0's set; code that writes the new set writes
  its ids and its feature too. On 1.0.x a 1.1 record is
  `unsupported_feature`: read it with 1.1. `NATAL_RECEIPT_CONVENTION_SETS`
  gains the new set at index 0, so each earlier set moves one place: take a
  set by its content, as its doc comment asks. The ids take room under
  `NATAL_ENVELOPE_LIMITS`: for the tests' chart the envelope grows from 5,585
  to 6,976 bytes, the longest string `createNatalEnvelope` accepts in
  `extensions` falls from 59,927 to 58,536 characters, and the longest array
  of numbers from 3,816 to 3,787 entries (`results/extension-room.txt`). An
  envelope near those limits that 1.0.0 accepted can now be refused
  (`size_limit`, `complexity_limit`).
- **No value changes.** 1.0.0-rc.1's battery of 6,417 calls over 1.0.0's
  twelve entry points (the new `./conventions` is not in it) prints the same
  bytes on the carried 1.0.0 archive and on this build, run on one machine
  (darwin-arm64), but in the 129 lines that hold a natal envelope or the list
  of sets, which differ only by what this candidate adds to them. Of the
  build's 48 JavaScript files, three are new code: the receipt entry, the new
  entry and the chunk of ids the two share; ten hold 1.0.0's lines in another
  order, their chunks renamed; and the other 35 are 1.0.0's once chunk-name
  hashes and the version are set aside.
- **Sizes.** The new entry's graph is 2,754 bytes, under a budget of 2,900.
  `./receipt` loads its ids: 72,500 bytes, 3,009 more than 1.0.0's 69,491,
  over its budget of 70,000, which this candidate raises to 76,500 with the
  owner's approval of 2026-10-26. The package is 1,006,494 bytes unpacked in
  77 files, 14,579 more than 1.0.0's 991,915, over the cap of 1,000,000, which
  it raises to 1,020,000 with the same approval: 3,740 bytes of JavaScript and
  3,370 of declarations for the new entry and the receipt's ids, 7,328 of
  README and CHANGELOG, 136 of manifest and the 5 of the version in the root's
  graph (`sizes.json`).

## 1.0.0 — 2026-10-11

The first stable release: 1.0.0-rc.2 with the version changed. From this
release the package follows Semantic Versioning as docs/versioning.md
describes, and `api/` records the public declarations of the twelve entry
points. Checks: `docs/evidence/1.0.0-20261011/`.

- Before this release npm carried 0.1.1-rc.14 to 0.1.1-rc.16 (`latest`
  0.1.1-rc.15, `next` 0.1.1-rc.16). 0.1.1-rc.17, 1.0.0-rc.1 and 1.0.0-rc.2
  were never published, so a caller moving from npm reads their entries
  below: 1.0.0-rc.1's *Migration* lists each breaking change and deprecation
  from rc.17 with what a caller does about it. A caller on 0.1.1-rc.15 reads
  0.1.1-rc.16's entry too, which has its own breaking changes and
  *Migration*, and one on rc.14 rc.15's as well.
- No API and no value changes from 1.0.0-rc.2. Every declaration file of the
  build is 1.0.0-rc.2's byte for byte, and 1.0.0-rc.1's battery of 6,417
  calls over the twelve entry points prints the same bytes on 1.0.0-rc.2's
  archive and on this build, run on one machine, with the version written
  as a placeholder. The 500 conformance verdicts are 1.0.0-rc.2's: 267 pass,
  192 fail, 41 unsupported, none in error.
- Results depend on the JavaScript engine, its version and the processor, by
  amounts far below any bound this package publishes. The tests' exact pins
  are x86-64 V8's, as CI runs, where none fails. On arm64 (an Apple M4, Node
  20, 22 and 24) 4 of the 3,853 tests fail: one calc round-trip case, which
  two tests replay, has a longitude speed 1.42e-11° a day from the pinned
  one, against the test's 1e-12; and the site-parity checks find 42 of 120
  return charts and 1 of 60 void-of-course windows not equal, every instant
  agreeing (a Moon longitude by 5.69e-14°). Over 1.0.0-rc.1's 6,417 calls the
  largest arm64 difference is 1.31e-8° in a true node's longitude and
  2.17e-8° a day in its speed; Node 24.17.0 differs from Node 22.22.2 on
  x86-64 by at most 1.14e-13. In JavaScriptCore the calc round trip differs
  by up to 1.26e-9° in a longitude and 3.56e-9° a day in a speed. One
  conformance residual rounds differently in its ninth decimal on arm64; no
  verdict changes. A comparison "to the bit" in these notes is between runs
  on one runtime and processor.

## 1.0.0-rc.2 — unreleased candidate

The second candidate for 1.0.0, on 1.0.0-rc.1 (main at `c6b5490`, the merge
of zodiacs-org/engine#30). It changes no API and no value: it lets a bundler
leave out the tables a program does not read, and it adds to 1.0.0-rc.1's
migration the step a TypeScript caller takes. 1.0.0-rc.1 froze the exported
tables where they are declared, and a bundler keeps such a freeze, and the
other calls a table is built with, in a program that never reads the table,
because a call might have effects: on zodiacs.org that put the chart
bundle's engine chunks over their size budget. It is not to be published on
npm until the owner approves 1.0.0. Checks:
`docs/evidence/1.0.0-rc.2-20261006/`.

- Each call a table's declaration makes when its module loads is marked
  `/*#__PURE__*/`: the freeze, the freezes of its entries, the `map`,
  `Array.from` or `Object.keys` that builds it, and a `Set` or `Map` built
  from data. Nothing else in a table is what a bundler takes for an effect:
  the receipt's convention sets built with a spread of the set before are
  built in a function called in place, and `RELEASING_UNIT_DAYS`' quotients
  are written as numbers, the same doubles. A program that reads a table
  gets it as before; one that does not no longer carries it. Bundled alone
  with esbuild, Rollup or Rolldown, each of the 66 such tables in the build
  is left out of a program that reads nothing; 1.0.0-rc.1 kept 43 of them
  under esbuild, 11 under Rollup and 42 under Rolldown. In programs that
  each load one entry point and read nothing, 1.0.0-rc.1 kept 43, 20 and 42
  of them, and this candidate keeps three, which modules only `./calc` and
  `./vedic` load read (below).
- Nothing else a module does when it loads reads a table, but in the
  modules that only `./calc` and `./vedic` load (below). `src/time-scale.ts`
  computed six bounds from `UT1_DATA` and `LEAP_SECOND_LIST` when it loaded,
  which kept both tables in every program that loaded the chunk they share
  with `REFERENCE_SPAN`; the generator now writes the six into
  `src/time-scale-data.ts` as numbers, the same values. The five values
  `./window` computes from tables when it loads are marked. Bundled with
  esbuild and minified, a program that calls only `outsideReferenceSpan` is
  180 bytes gzipped, where it was 7,475 on 1.0.0-rc.1.
- `DEFAULT_ASPECT_POLICY = createAspectPolicy()`, which the root builds when
  it loads, is marked too, so a bundler leaves the policy, and the code that
  builds it, out of a program that does not read it. Bundled with esbuild
  and minified, a program that calls only `normalizeLongitude` is 137 bytes
  gzipped, where it was 4,169 on 1.0.0-rc.1 and 3,936 on rc.17, and one
  that calls `natalChart` 35,132, where it was 37,000 and 36,736.
- `CHALDEAN_FACES` (`./techniques`) was marked, but not the `Array.from`
  that builds it, so bundlers kept it; it is marked now.
- The tables that only `./calc` and `./vedic` load are as 1.0.0-rc.1 had
  them, and so is what those modules read of the others when they load: a
  program that loads either entry carries `REFERENCE_SPAN`, and one that
  loads `./vedic` `SIGNS` and `SIGN_SLUGS`, whether it reads them or not.
  Their marks, 16 bytes each in the built files, would add at least 288
  bytes to `./calc`'s graph and 432 to `./vedic`'s, which have 239 and 249
  left, and a budget is raised only with the owner's approval.
  `UNMARKED_SOURCE` in `scripts/pure-tables.mjs` names their modules.
- `scripts/pure-tables.mjs` states the rule and checks it: its tests run it
  on the source, and the export smoke test on the build, module by module.
  It holds to the rule whatever reads a table when its module loads, its
  own module's or one it imports, by name, as a default or through a
  namespace. It refuses a freeze outside a table's declaration; a mark on a
  call whose value is discarded, which a bundler would drop with its
  effect; and a mark on a call it finds may freeze a value that exists
  before it, which a bundler would leave unfrozen, with a freeze of its
  own, in a function it calls or constructs, or in one it runs. It does not
  read every form of code, so it is an aid to reading a mark, not a proof;
  the release's record reads each mark in `src/` by hand. The export smoke
  test also checks that no entry point but `./calc` and `./vedic` reaches
  the modules it leaves out through its static imports. The generated
  `src/time-scale-data.ts` and `src/tzdb/tzdb-2025c.ts` carry the marks
  from their generators.
- 1.0.0-rc.1's migration, below, gains its step for TypeScript: declare
  what you keep of the constants its *Types only* bullet lists as their
  `string` or `number`, and of a birth window's result as readonly. The
  packed-consumer check, which failed on 1.0.0-rc.1's archive until its own
  TypeScript was so declared, now also exercises 1.0's additions:
  `ZoneHistoryNotLoadedError` by its class, `./calc`'s epochs inside
  `EPHEMERIS_SPAN` and its `epoch-out-of-range` refusal beyond, the frozen
  tables and the lookups that return their entries, and
  `SIDEREAL_TIME_RATE`.
- Sizes: each entry's graph grows by what it loads of the marks and the
  functions called in place, less 105 bytes where it loads the time scale,
  whose six bounds are now numbers: from none (`./crossings`, `./houses`)
  to 759 bytes (`./techniques`); the root's is 105,980 bytes, 615 more. No
  budget is raised. The tightest are `./crossings`, 9,942 of 10,000;
  `./geo`, 35,439 of 35,500; `./calc`, 145,261 of 145,500; and `./vedic`,
  127,751 of 128,000.
- No value moved: 1.0.0-rc.1's battery of 6,417 calls over the twelve entry
  points prints the same bytes on both candidates, every declaration file
  is 1.0.0-rc.1's, and the conformance results are 1.0.0-rc.1's.

## 1.0.0-rc.1 — unreleased candidate

The first candidate for 1.0.0, on rc.17 (main at `782b496`, the merge of
zodiacs-org/engine#26). 1.0 is a promise about the API rather than new
calculations: from 1.0.0 the package follows Semantic Versioning, and
`docs/versioning.md` says what that covers, how a number may change, which
records stay readable and how something public is deprecated (twelve months'
notice, removal only in a major release). Before the promise was made, three
reviews read every public declaration of the twelve entry points for what
should not be frozen as it stood; a fourth read the changes, and two more
this candidate. It acts on what they found, and each change below says what
a caller does about it. No calculated value moved: in a comparison of 6,411
calls across the twelve entry points, each result that differs from rc.17's
is one of the changes listed here. It is not to be published on npm until
the owner approves 1.0.0. Checks: `docs/evidence/1.0.0-rc.1-20261006/`.

- `api/` holds the public declarations of each of the twelve public entry
  points as the build gives them, without comments, with the declarations
  they refer to that the entry point does not export. `npm run api:check`
  runs in CI after the build and fails, with a diff, when the build declares
  anything else; `npm run api:report` rewrites the files, which are committed
  with the change. The two release tags the policy gives a meaning to,
  `@experimental` and `@deprecated`, are shown above the declarations, the
  members and the exports under another name that carry them.
- `docs/versioning.md`: the policy. What is public (the twelve entry points,
  their declarations, documented behaviour and records), what a minor release
  may add, the experimental tier, how numbers may change, which records the
  codec reads, deprecation, and the Node.js lines supported.
- Experimental in 1.0, outside the promise until a minor release takes the tag
  away: `lunarMeanArguments`, `MEAN_LUNAR_INCLINATION`, `meanNodeLongitude`
  and `meanApogee` (root); `houseSpeeds` and `HouseSpeeds` (`./houses`);
  `davisonChart`, `davisonPlace` and their three types (`./techniques`);
  `planetaryReturns`, its three types, `ReturnBody`, `RETURN_BODIES` and
  `RETURN_STEP_DAYS` (`./timing`); `yoginiDasha`, `ashtottariDasha`,
  `YOGINIS`, `ASHTOTTARI_YEARS` and `CycleOptions` (`./vedic`). Each
  declaration's comment, and its guide, say what may change.
- `./calc` computes a caller's ayanamsa carried by precession from an epoch
  anywhere in `EPHEMERIS_SPAN`, 0001-04-30T12:00 to 3998-09-03T12:00 TT, the
  owner's decision of 2026-10-06 on the site's finding F-80, where rc.17
  refused one from an epoch outside 1800 to 2200. Its bound outside that
  span comes from two new bands, measured against ERFA in 64,974 comparisons
  (`docs/evidence/calc-epochs-2026-10-06/`): 0.0037″ and 1.3 × 10⁻⁷″ a day on
  the engine's precession, which parts from ERFA's the further the epoch is
  from J2000.0, and 1.8 × 10⁻⁵″ and 1.2 × 10⁻⁷″ a day on Newcomb's or IAU
  1976's, held at J2000.0. An epoch beyond `EPHEMERIS_SPAN` is refused with a
  new reason, `epoch-out-of-range`, whose `epochSpan` is `EPHEMERIS_SPAN`.
- New names: `SIGN_SLUGS`, `ASPECT_POLICY_SCHEMA`, `CONFIGURED_ASPECTS_SCHEMA`
  and `DELTA_T_IERS_MODEL` (root); `SIDEREAL_TIME_RATE`, and the types
  `Angles` and `HouseSystem` (`./houses`); `ZoneHistoryNotLoadedError`
  (`./geo`); `BIRTH_WINDOW_SCHEMA` (`./window`); `ReturnChart`
  (`./techniques`); `AyanamsaFlag` (`./vedic`); the type `BodyName`
  (`./crossings`); `CalcLocation` (`./calc`); `NatalConventionSet`,
  `NatalCoverage` and the record types `NatalRecordedResult`,
  `NatalBodyRecord`, `NatalAnglesRecord`, `NatalHousesRecord`,
  `NatalAspectRecord`, `NatalDeltaTRecord` and `NatalTimeScaleRecord`
  (`./receipt`).
- `./receipt`: a natal record has its own types, the same shapes as rc.17's,
  rather than the chart's. `createNatalEnvelope` copies the fields a record
  holds and leaves out any other field of the chart's result, so that a field
  a minor release adds to a chart does not change the records it writes; a
  chart's `input` is still read strictly, because an input the receipt cannot
  describe may have changed the numbers. The reader compares a record's ΔT
  and time scale with this engine's own as a record holds them. A record
  this candidate writes has the fields and the conventions of rc.17's, which
  reads it, and it reads rc.17's.
- `./geo`: before `prepareLocalTime` has loaded a zone's history, the
  functions that need it, `./geo`'s and `./techniques`' `moonSignCandidates`,
  throw a `ZoneHistoryNotLoadedError` (exported by `./geo`), an `Error` with
  the same message as before, so that a caller can catch that case by its
  class.
- `./geo`: a Julian date late in 9999 that resolves into the Gregorian year
  10000 gets its calendar note, `"new-style"`, which rc.17 left out: it
  compared the dates as text, where a five-digit year sorts first.
- `./sky`: a refused `planetaryHours` day carries `reason: "sample-budget"`,
  as a refused `skyEventsOn` does.
- `./crossings`: the two functions take a body name type of the caller's own,
  `BodyLongitudeAt<B>`, with `BodyName` the default. The root's
  `findLongitudeCrossings` and `searchLongitudeCrossings` take a window's ends
  as any `DateInput`, as the root's other functions do; the crossings entry
  itself still takes Dates, which keeps it within its size budget.
- `./calc`: `CALC_AYANAMSAS` is taken from `./vedic`'s `AYANAMSAS`, in its
  order, so that the two cannot drift; `CalcAyanamsa`, `CalcAyanamsaModel` and
  `CalcScale` are `./vedic`'s `AyanamsaName` and `AyanamsaPrecessionModel` and
  the root's `TimeScaleName`.
- Documentation of what the reviews found unclear: `BirthInput.utc`,
  `ChartInput.utc` and `AyanamsaValue.utc` (the instant on the scale
  `timeScale` names; the names are kept because receipts record them),
  `AngleInput`'s units, the ΔT segment `"fallback"` (written by rc.15's first
  cut only, kept so that its records stay readable), `DeltaTTable` (its shape
  is the model's; a model of another shape would be a new export),
  `EPHEMERIS_SPAN.timeScale` (a label, like `fromTT`), `offsetAt` (the host
  Intl's answer, a cross-check on `zoneOffsetAt`), the two place types
  (`Observer` on WGS84, `CalcPlace` on the IERS 2003 ellipsoid), the identity
  of `./vedic`'s values (a copy through JSON or `structuredClone` is refused,
  although the types carry no brand), the three tables of sign rulers (one
  each in `./techniques`, `./timing` and `./vedic`, now kept equal by a test),
  and which return finder to use.
- Sizes: the package is 982,086 bytes unpacked in 74 files, 35,737 more
  than rc.17's 946,349 in 70: 1,828 bytes (5.12 per cent of the growth) of
  the root's JavaScript, the reviews' checks and frozen tables; 4,607
  (12.89) of JavaScript that only the opt-in entry points load; 13,515
  (37.82) of declarations, most of it the documentation of the 1.0 API;
  15,683 (43.88) of documents, this entry above all; and 104 (0.29) of
  manifest. The owner approved raising the cap from 950,000 to 1,000,000 on
  2026-10-06, which leaves 1.82 per cent of headroom. Every entry is within
  its budget; `./geo`'s was raised from 35,000 to 35,500 with the same
  approval, for `ZoneHistoryNotLoadedError` and `calendarNote`'s checks, and
  its graph is 35,375 bytes, the tightest of all. The next are `./calc`,
  144,694 of 145,500; `./crossings`, 9,942 of 10,000; and `./vedic`, 127,184
  of 128,000.

Breaking changes, each with what to do:

- `./calc`: a Julian date's scale is `"utc"`, `"ut1"` or `"tt"`, the root's
  `TimeScaleName`; `"UTC"`, `"UT1"` and `"TT"` throw a RangeError that says
  so. Write the scale in lower case. (`./calc` came in rc.16, which is on npm
  under `next`.)
- `./calc`: `houses()` takes `houseSystem`, as `chart()` and `natalChart()`
  do, and its receipt records `houseSystem`; `system` throws. Rename the
  field. A result's `requested` and `system` keep their names.
- `./calc`: a receipt's schema is `zodiacs.calc-receipt.v1`, where rc.16 and
  rc.17 wrote `zodiacs.calc-receipt.draft-v1` with requests in their own
  vocabulary; a stored rc.16 or rc.17 request needs the two renames above
  before it is passed back.
- `./calc`: a caller's ayanamsa from an epoch outside 1800 to 2200 but inside
  `EPHEMERIS_SPAN`, refused `out-of-range` in rc.17, is computed; beyond it,
  it is refused `epoch-out-of-range`, a new member of `CalcRefusal["reason"]`.
  Handle the new reason; `out-of-range` now means an instant only.
- Options a function does not name now throw a RangeError instead of being
  ignored, so that a misspelling such as `timescale` is not a silently
  different answer: `ayanamsa`, `userAyanamsa`'s input and its `epoch`,
  `declareSiderealLongitude`'s declaration, the four dasha functions and the
  crossing searches' options. They also refuse what the techniques and timing
  entries already refused: options that are not a plain object (`null`, an
  array, a string, an instance of a class), an inherited key and a getter.
  Check the names, and pass a plain object or nothing. An option set to
  `undefined` still counts as absent, and the options types now say so
  (`| undefined`).
- `userAyanamsa` refuses a bare-number `epoch`, which it read as epoch
  milliseconds although a Julian date was the likelier meaning. Pass
  `{ julianDateTT }`, a `Date` or an ISO string.
- `davisonPlace` refuses a place outside latitudes −90 to 90 and longitudes
  −180 to 180 (rc.17 averaged it as given) and a convention it does not name
  (rc.17 used the great-circle midpoint). `calendarNote` refuses a date that
  is not a valid Gregorian YYYY-MM-DD, a calendar other than `"gregorian"`
  and `"julian"`, and a country that is not a nonempty string, which rc.17
  answered for.
- `deltaT` and `deltaTAt` throw a RangeError for a UT that is not a finite
  number. rc.17 returned NaN for NaN and ±Infinity (`deltaTAt` a record with
  NaN seconds) and read anything else as a number, `null` as 0 and `"1"` as
  1. Pass a finite number.
- The exported tables are frozen, and their declarations readonly:
  `ASPECTS` and its entries, `ASPECT_TYPES`, `SIGNS` and its entries,
  `SIGN_NAMES` (now the same array as `SIGN_SLUGS`), `ELEMENTS`,
  `MODALITIES`, `HOUSE_SYSTEMS`, `POLAR_UNDEFINED_HOUSE_SYSTEMS`, `LOTS`,
  `CALC_BODIES`, `CALC_AYANAMSAS` and `CALC_FRAMES`; `signForLongitude`
  returns, and `matchAspect`'s `definition` is, one of the frozen entries.
  Code that changed one throws in strict mode; copy it first. `ASPECT_BODIES`,
  a Set, cannot be frozen: it is now typed `ReadonlySet`, and the engine no
  longer reads it, so changing it changes nothing the engine computes.
- Types only: `ENGINE_VERSION`, `EPHEMERIS.version`, `TZDB.version` and
  `TZDB.sha256` are typed `string`, `WINDOW_VERIFICATION` `string`, and
  `MAX_WINDOW_MS`, `WindowBudgetError.limit` and the techniques' search
  constants (`SOLAR_RETURN_*`, `LUNAR_RETURN_*`, `MOON_SIGN_MAX_SPAN_DAYS`,
  `VOID_OF_COURSE_MAX_DAYS`) `number`, so that a release can change them; the
  values are rc.17's. `CALC_FRAMES` is `readonly CalcFrame[]`. The birth
  window's result types and the sky's options are readonly. `vimshottariAt`'s
  `levels` is `1 | 2 | 3 | 4 | 5`. `NatalEnvelope["result"]` is
  `NatalRecordedResult`, and `NATAL_RECEIPT_CONVENTION_SETS` is
  `readonly NatalConventionSet[]`, newest first: take a set by its content,
  not by an index other than 0. `NatalReceipt.conventions` and `.coverage`
  are `NatalConventionSet` and `NatalCoverage`, records of strings, where
  rc.17 typed each set's literal values: compare them as strings.
  `NatalZoneTransition.cause` is `./geo`'s `TransitionCause`, the same three
  names. `AspectDefinition` and `SignDefinition` have readonly members, as do
  the inputs `CrossingSearchOptions`, `BirthWindowInput`, `WindowRounding` and
  `PlanetaryReturnOptions`: build such an object whole, or copy it, rather
  than assign to its fields. `houses()` and `chart()` take a `CalcLocation`,
  with no height, where rc.17 declared a `CalcPlace` whose height they
  refused.

Deprecated, each kept working at least until twelve months after 1.0.0 and
removed only in a major release:

- `SIGN_NAMES`: it holds slugs (`"aries"`), not names. Use `SIGN_SLUGS`.
- `ConfiguredAspectMotion`: use `AspectMotion`, the same type.
- `PLACIDUS_POLAR_FALLBACK`: Koch falls back too. Use `POLAR_FALLBACK`.
- `DECLINATION_ORB` and `DECLINATION_ORB_LUMINARY`: use
  `DEFAULT_DECLINATION_ORB_POLICY.orb` and `.luminaryOrb`, the same values.
- `SIDEREAL_RATE` (`./houses`): use `SIDEREAL_TIME_RATE`, the same value.
- `PlanetaryReturn` (`./techniques`): use `ReturnChart`, the same type;
  `./timing`'s `PlanetaryReturn` is another one.

Considered and left as they are: calc's `status: "ok"` (calc's own word for a
computed request, beside `CalcRefusal`); calc is not experimental;
`EPHEMERIS_SPAN.timeScale` stays `"TT"`; no brand types in 1.x; the three
return finders stay, and the guides say which to use.

Migration: write calc's time scales in lower case and `houses()`'s
`houseSystem`, in a stored calc request too before it is passed back; handle
`epoch-out-of-range`; check option names and pass plain objects; give
`userAyanamsa` an epoch that is not a bare number; give `davisonPlace` places
in range, `calendarNote` a valid date, a named calendar and a country, and
`deltaT` a finite number; copy any exported table before changing it, and do
not change `ASPECT_BODIES` to change what the engine computes; in
TypeScript, declare what you keep of a constant the *Types only* bullet lists
(`ENGINE_VERSION`, `TZDB.version`, `WINDOW_VERIFICATION`, `MAX_WINDOW_MS` and
the others) as its `string` or `number`, not rc.17's literal, and what you
keep of a birth window's result as readonly (`readonly WindowChange[]`,
`readonly WindowUnresolved[]`); and move off the seven deprecated names when
convenient.

### Corrections

- `docs/time.md` called the flags `dst-gap` and `dst-fold` deprecated. They
  are permanent: stored receipts carry them and no other name replaces them.
- `docs/timing-hellenistic.md`, *Limits*, described failures far from the
  present that cannot happen since rc.14 refuses instants outside
  `EPHEMERIS_SPAN`.
- Three of rc.17's doc comments named a package where TypeScript reads a
  tag, which cut editors' hovers short; package names in comments are now in
  backticks.

## 0.1.1-rc.17 — unreleased candidate

rc.17 adds the sidereal zodiac to the calc entry (`@zodiacs/engine/calc`), on
rc.16 (main at `23660f5`, the merge of zodiacs-org/engine#25). In rc.16 its
four functions refused `zodiac: { sidereal }` with `not-in-this-version`,
though the entry's own map of Swiss Ephemeris's `calc_ut` flags typed the
option in and `@zodiacs/engine/vedic` computed sidereal longitudes. Tropical
values are rc.16's: the root entry and eleven others build to rc.16's files
but for the version's value and the hashed chunk names that follow from it,
calc's tropical round-trip values are unchanged, and so are the conformance
suite's 500 verdicts and values. rc.17 is not to be published on npm: under
the owner's decision of 2026-10-05 the next publication is the 1.0
candidate. Checks: `docs/evidence/calc-sidereal-2026-10-05/` and
`docs/evidence/rc17-20261005/`.

- `calc()`, `houses()`, `events()` and `chart()` take `zodiac: { sidereal }`
  with one of the nine built-in ayanamsas by name, or a caller's own,
  `{ name?, epoch, value, rate?, model? }` (`CalcUserAyanamsa`):
  `userAyanamsa` in JSON, and the counterpart of `SE_SIDM_USER`. A sidereal
  longitude is the longitude in the ecliptic of date less the ayanamsa, the
  true one in the true ecliptic of date and the mean one in the mean
  ecliptic of date, subtracted as `siderealLongitude()` subtracts it: with
  every other default, `calc()` gives `siderealChart()`'s longitudes to the
  bit. Speeds are the sidereal longitude's, and a cartesian position turns
  with it. `houses()` rebuilds whole-sign cusps from the sidereal
  ascendant's sign, as `siderealChart()` does; `events()` searches sidereal
  longitudes; `chart()` adds `sidereal`, `siderealChart()`'s longitudes as
  plain numbers.
- Two new refusals: the sidereal zodiac in a frame other than the two
  ecliptics of date (`unsupported-combination`), and a caller's ayanamsa
  carried by precession from an epoch outside 1800 to 2200 (`out-of-range`).
  A malformed caller's ayanamsa throws a RangeError that names its field
  under `zodiac.sidereal`, an epoch whose TT falls outside the range of a
  Date among them.
- `CalcPosition` and `HousesResult` gain `ayanamsa`, and `ChartResult` gains
  `sidereal`, whose own `ayanamsa` has the same shape; both are null in the
  tropical zodiac. That shape, `CalcAyanamsaValue`, is `{ name, mean,
  nutation, true, subtracted, bound }`, in the result's angular unit:
  `subtracted` says whether the true or the mean ayanamsa was subtracted, and
  `bound` is the mean ayanamsa's. Receipts name `zodiac:sidereal` and
  `ayanamsa:<name>`, or `ayanamsa:user-epoch` or `ayanamsa:user-linear`, and
  record a caller's ayanamsa with every default filled in.
- In the sidereal zodiac each bound adds the ayanamsa's own: the largest
  difference of the engine's mean ayanamsa, and of its rate, from ERFA's
  construction of the same definition, over 2,333,979 comparisons: every
  star definition in every year from 1800 to 2199, densely around its pass
  by the Sun, and callers' ayanamsas at the ends of what calc accepts. That
  is 4.6 × 10⁻⁷″ and 1.6 × 10⁻⁷″ a day for epoch and linear definitions,
  the rate's the floor of a linear ayanamsa's own rounding; a speed adds a
  few tenths of a microarcsecond a day of rounding of its own, which no
  bound includes (`docs/calc.md`). For a star definition it depends on the
  star's angle from the Sun: 0.0013″ and 0.00039″ a day at 2° or more,
  0.0048″ and 0.026″ a day from 0.3° to 2°, and 0.058″ and 27″ a day within
  0.3°, where the star is on or beside the Sun's disc. The fixtures
  `src/fixtures/ayanamsa-rates.json` and
  `src/fixtures/ayanamsa-rates-dense.json`, which keep the years and callers
  that hold each band's largest differences, and `src/calc-sidereal.test.ts`
  hold the engine to them.
- `@zodiacs/engine/vedic`: `ayanamsa()` now computes through an internal
  `ayanamsaAt`, which also gives a star definition's star's angle from the
  Sun. A linear ayanamsa is now its value at J2000.0, less whole turns, plus
  its rate times TT days since J2000.0. It was counted from its epoch, so
  that from an epoch far from the span its value ran to hundreds of
  thousands of degrees, whose rounding put up to 2 × 10⁻⁴″ a day into its
  rate at 3,600″ a year; and from a Julian date rebuilt from TT days, held
  near 2.4 million only to about 5 × 10⁻¹⁰ day, which put up to 2 × 10⁻⁶″ a
  day there. A linear ayanamsa moves by the rounding this removes: Raman's and
  Sri Yukteswar's by less than 10⁻¹³°, and a caller's by less than 10⁻¹²°
  from an epoch from 1800 to 2200 and by up to 8.6 × 10⁻¹¹° from an epoch at
  the end of a Date's range (`docs/evidence/rc17-20261005/`). Every epoch and
  star definition's value is rc.16's. `docs/vedic.md` corrects its agreement
  with ERFA: none of its first comparison's 164 was within 17° of the Sun,
  and near the Sun the engine and ERFA part by up to 0.058″.
- The calc round-trip fixture gains twelve cases, among them its first four
  of `chart()`. Of its 25 earlier cases, the sidereal Moon, refused
  `not-in-this-version` in rc.16, is now computed; 15 gain `ayanamsa: null`;
  and every receipt names rc.17. The conformance results are regenerated: 267
  pass, 192 fail and 41 unsupported of 500, every verdict and value as in
  rc.16.
- Sizes: the calc entry's import graph grows from 113,904 to 139,836 bytes,
  and its budget is raised from 115,000 to 145,500, because it now loads the
  ayanamsas, with their star catalogue and apparent places, and the sidereal
  charts, in a chunk it shares with `./vedic`. `./vedic`'s graph grows by
  1,508 bytes, to 123,639 of its 128,000. The package is 946,349 bytes
  unpacked in 70 files (rc.16: 923,282 in 69): of the 23,067 bytes it grows
  by, 9,844 are opt-in JavaScript, 4,618 declarations and 8,605 documents.
  That leaves 0.38 per cent of the cap of 950,000, which was not raised; a
  candidate that grows by more than about 3,600 bytes will need it raised, or
  the package trimmed.

Breaking changes:

- A calc request with `zodiac: { sidereal }`, refused `not-in-this-version`
  in rc.16, is now computed, or refused `unsupported-combination` in a frame
  outside the ecliptics of date. `not-in-this-version` now means only
  gravitational deflection.
- Every `CalcPosition` and `HousesResult` has a new key, `ayanamsa`, and
  every `ChartResult` one, `sidereal`, null in the tropical zodiac. Code that
  compares a whole rc.16 result needs them; no tropical value changes.

Migration: expect the new keys, null in the tropical zodiac. A sidereal
longitude that came from `siderealLongitude()` or `siderealChart()` in rc.16
is the same number from calc in rc.17 with calc's other defaults: to the bit,
but where a linear ayanamsa moved (above), by as much as it moved.

### Corrections

- rc.14's, rc.15's and rc.16's entries call each an unreleased candidate. They
  were published on npm afterwards: rc.14 and rc.15 on 2026-09-30, rc.16 on
  2026-10-01, and on 2026-10-05 `latest` was rc.15 and `next` rc.16
  (`docs/evidence/rc17-20261005/npm-view.txt`).

## 0.1.1-rc.16 — unreleased candidate

rc.16 brings six pieces of work onto rc.15 (main at `93ebae9`, the merge of
zodiacs-org/engine#20), each from its feature branch as that branch's own
commits, in this order: the uniform calculation API (`@zodiacs/engine/calc`),
birth-time windows (`@zodiacs/engine/window`), the techniques entry
(`@zodiacs/engine/techniques`), house positions, cusp speeds and planetary
returns (`@zodiacs/engine/houses`, and `planetaryReturns` in
`@zodiacs/engine/timing`), the sky entry (`@zodiacs/engine/sky`) and, last,
the full IAU 2000B nutation. The branches' copies of earlier local rc.15
builds were left out. The calc and window entries were then put on rc.15's
time basis, the budgets and the root's isolation extended to the new entries,
and calc, window and sky moved onto the engine's nutation. Nothing was pushed
or published. One build came before this one, on a local branch, and was
neither pushed nor published; its review found preregistered gates that fail
described as not applying, figures read off samples too sparse or placed in
the wrong band of latitude, and sources missing from `LICENSING.md` and
`NOTICE`, and this candidate corrects them
(`docs/evidence/rc16-20260930/README.md`, *The re-cut*). Checks:
`docs/evidence/rc16-20260930/`, and each piece's own evidence, beside which
its preregistered gates were run again after the nutation, on this candidate's
code (the `rc16/` directory of each; the evidence README says which build each
ran on, and that the source commit's computing code is the same).

**Held back:** the sky branch's Chinese-calendar entry
(`@zodiacs/engine/chinese`: the 24 solar terms and the Four Pillars). Its
apparent Sun is a series fitted to JPL DE430, and no coefficient set derived
from a JPL ephemeris ships until NAIF answers whether such derived
coefficients may be redistributed. The entry waits for a Sun source that is
not JPL-derived. Its source, tests, export, guide, data script, licensing
notes and evidence claims are all left out; the sky branch's
preregistration, which set the Chinese gates C1 to C4 beside the sky's, is
carried unchanged, and rc.16 acts on none of them.

Breaking changes:

- `NATAL_RECEIPT_CONVENTION_SETS` (`@zodiacs/engine/receipt`) has a new set
  at index 0, which names the nutation, so each earlier set is one index
  later: rc.15's time-basis set is at 1 and the rc.8 set at 2. Code that
  takes a set by its index needs the new one. A receipt of the new set
  carries `nutation: "iau2000b;equation-of-equinoxes-with-two-complementary-terms"`
  and `moonPosition: "astronomy-engine-geo-moon;no-light-time;no-aberration"`.
  The codec accepts it from 0.1.1-rc.16 on, in SemVer order, and now accepts
  rc.15's set under 0.1.1-rc.15 alone, where rc.15 accepted it from rc.15 on
  (`src/receipt-nutation.test.ts`, `src/receipt-versions.test.ts`).
- Every result that depends on the nutation moves, by the amounts under
  *The nutation* below: longitudes of date, the angles and the cusps, the
  Vertex, the East Point and the lots, right ascensions and declinations, the
  mean nodes and Black Moon Lilith, the ayanamsas' `nutation` and `true`
  values, and every instant found from them (longitude crossings, returns,
  stations, void-of-course windows, window switches, rises and sets). No
  function signature of the root entry or of an rc.15 entry point changes,
  and the root's exports are rc.15's.

Migration: take a conventions set by its content (the `nutation` key marks
the current one), or add one to its index. A test or a stored value that
pins a longitude, an angle or an instant to rc.15's last digits needs rc.16's
value. A receipt replays its request, not its engine: to reproduce an rc.15
result as rc.15 computed it, run the carried rc.15 archive.

### New entry points

- `@zodiacs/engine/calc` (`docs/calc.md`). `calc({ body, time, frame,
  center, zodiac, flags })` returns `{ lon, lat, dist, speeds, cartesian,
  bounds, receipt }`; `houses()`, `events()` and `chart()` give the engine's
  houses, longitude crossings and natal charts in the same vocabulary. Eight
  frames (the ecliptic or the equator; true or mean of date, J2000.0 or the
  ICRS), four centers (geocentric, heliocentric, barycentric, topocentric) and
  three corrections (apparent, astrometric, geometric); speeds in every
  coordinate, analytic for geometric positions on fixed axes and central
  differences otherwise; receipts of convention ids; and typed refusals,
  `not-in-this-version` (the sidereal zodiac, which `@zodiacs/engine/vedic`
  gives, and light deflection), `unsupported-combination`, `out-of-range`
  and `sample-budget`. An instant is an ISO string, a `Date` or
  `{ jd, scale: "UTC" | "UT1" | "TT" }`, read on the engine's time basis as
  `positions()` reads it, with an optional pinned ΔT; the receipt records its
  UTC, `jdUt1` and `jdTt`. calc refuses an instant whose UT1 or TT is outside
  1800 to 2200, where it has no comparison to take a bound from. With every
  default it is the position `positions()` gives, to the bit. Bounds are the
  largest differences from JPL Horizons (DE441) over 32 preregistered
  instants from 1802 to 2188 (sample maxima, not limits), from the comparison
  rerun after the nutation (`docs/evidence/calc-api/rc16/`): 3.00″ median and
  24.6″ at worst, geocentric and apparent, the ephemeris's own error; the
  barycentric Sun's are derived from the barycentre's error. All twelve
  frame checks against ERFA pass there; on astronomy-engine's five-term
  nutation the four through the nutation had failed by up to 0.20″.
  `houses()` carries the conformance suite's L2 bounds, 0.02″ for the angles
  and 0.08″ for the cusps. `docs/calc.md` maps every Swiss Ephemeris
  `calc_ut` flag.
- `@zodiacs/engine/window` (the README's *Birth-time windows*).
  `birthWindow(input)` partitions a window of up to 48 hours inside
  `REFERENCE_SPAN` into cells within which each body's sign and house, the
  signs of the ascendant and midheaven, the aspects in orb and any Placidus or
  Koch fallback are constant, with each switch's first millisecond and
  changes, and each cell's share under a uniform prior and, optionally, a
  rounding model; also `WINDOW_RATE_BOUNDS`, `MAX_WINDOW_MS`,
  `WINDOW_VERIFICATION` ("sampled at one-second resolution") and
  `WindowBudgetError`. The search splits at every step of the time basis (the
  ΔT model's seam in 1941, 1972-01-01, each leap second and the end of the
  IERS table) and compares both sides. Where the true node's millisecond
  jitter would make its sign flicker for longer than the budget of two
  million instants allows (24 of its 294 ingresses from 1800 to 2200), the
  flicker is left unresolved, found before the budget is spent: the nodes'
  signs are null there, and so are their houses where those are whole signs,
  the interval is listed in `unresolved`, and the result carries
  `node-unresolved`. The preregistered check, natalChart at every second of
  1,000 random windows, rerun after the nutation, passes: all 24,188 sampled
  transitions matched, none missed and none extra, and natalChart confirmed
  every switch at its millisecond (1,487,520 checks)
  (`docs/evidence/birth-window/rc16/`).
- `@zodiacs/engine/techniques` (`docs/techniques.md`), six techniques the
  Zodiacs.org site computed outside the package: solar and lunar returns
  (`solarReturnInstant`, `mostRecentSolarReturnInstant`, `lunarReturnInstant`,
  `solarReturn`, `lunarReturn`); composite and Davison charts
  (`compositeMidpoints`, `compositeAspects`, `compositeChart`, `davisonChart`,
  `davisonPlace`); the void-of-course Moon (`moonIngresses`, `moonAspects`,
  `voidOfCourseWindows`, `voidOfCourseAt`) under one named convention,
  `VOID_OF_COURSE_CONVENTION`; grand trines, T-squares, grand crosses and
  kites (`aspectPatterns`, `chartAspectPatterns`, `patternContainment`);
  essential dignities with cited tables and mutual reception
  (`dignityRulersAt`, `essentialDignities`, `mutualReceptions`, beside the
  site's `dignityFor` and `dignitiesFor`); and the Moon signs possible over a
  date (`moonSignCandidates`, `moonSignsBetween`). Against the site's code on
  a seeded synthetic corpus, 6,795 of 6,796 cases agree exactly; the
  preregistered parity gate, G1, allowed none to differ, so it is recorded as
  failed. The one that differs is 2011-12-30 in Pacific/Apia, a date the zone
  skipped, which the site answers and the package refuses. The rerun after the
  nutation generated the site's outputs on rc.16's build, where the
  preregistration named the carried rc.15 archive: a deviation, made so that a
  difference comes from the port and not from the nutation. By design, returns
  are not clipped to 1800–2200 but flagged, and dates before 1970 are read on
  the shipped tzdata. The solar return is within 42.27 s of USNO's 20
  published equinoxes and solstices of 1850 to 2022 (gate 120 s), and within
  32.05 s and 6.81 s of the Horizons Sun and Moon of the conformance suite's
  L1 vectors (60 s and 15 s). Two more of its gates fail on rc.16. G5, sizes:
  the root's graph was to stay at rc.15's 95,273 bytes and is 103,537; the
  package was to stay within the 700,000-byte cap, not raised, and is 923,282
  bytes; `./techniques` was to be at most 150,000 bytes and is 152,472. G6: no
  existing file under `src/` was to change and every existing test was to pass
  unchanged; it failed as run on its branch, and rc.16 changes 20 of rc.15's
  files under `src/`, 13 of them tests
  (`docs/evidence/techniques-2026-09-29/rc16/`).
- `@zodiacs/engine/houses` (`docs/houses.md`), one file that imports no other
  module, no ephemeris and nothing of the root entry:
  `housePosition(system, input, { lon, lat })`, a body's house position in
  each of the thirteen systems as Swiss Ephemeris's `swe_house_pos` defines it
  (`null` for Koch or Topocentric where the system has none);
  `coAscendants(input)`, the equatorial ascendant, Koch's and Munkasey's
  co-ascendants and Munkasey's polar ascendant; and
  `houseSpeeds(system, input)` with `SIDEREAL_RATE`, the speeds of the cusps
  and angles, derived analytically. Given the same inputs, house positions are
  within 0.01″ of `swe_house_pos` for eleven systems and not for Porphyry (11
  of 20,000 cases) or Topocentric, where Swiss's positions leave up to 0.445″
  in their defining equation; the co-ascendants are within 0.00000001″ of
  Swiss's `ascmc[4]` to `ascmc[7]`; the speeds are within 0.00035° a day of a
  central difference of the engine's own cusps, and differ from Swiss's for
  Koch, Placidus, Porphyry, whole sign and, in 5 cases, Alcabitius, where
  Swiss's are not the derivatives of its cusps
  (`docs/evidence/houses-extra-2026-09-29/`, Swiss Ephemeris an instrument
  only). These take their inputs as given and do not move with the nutation.
  Gate B of its preregistration fails on rc.16: the root's graph was to stay
  at rc.15's 95,273 bytes, its files byte-identical, and is 103,537 bytes;
  `./timing` was to stay within its 120,000-byte budget and is 123,039; the
  package was to stay within the 700,000-byte cap and is 923,282; and existing
  tests and released functions' results change with the nutation. Its part for
  `./houses`, a budget with its reason, holds: 13,606 bytes of 15,000
  (`docs/evidence/houses-extra-2026-09-29/rc16/`).
- `planetaryReturns(natal, body, from, to)`, with `RETURN_BODIES` and
  `RETURN_STEP_DAYS`, in `@zodiacs/engine/timing`: every instant in a window
  at which the Sun, the Moon or Mercury to Pluto stands on its natal
  longitude, retrograde returns included, each result carrying its verdict
  (`complete`, or `refused` over a sample budget). Against JPL Horizons, for
  invented charts that include a direct, retrograde and direct return of each
  of Mercury to Pluto, every return is found with its direction and within
  the preregistered τ, and the solar returns of an invented native are within
  49.7 s of USNO's March equinoxes of 2001 to 2004
  (`docs/evidence/houses-extra-2026-09-29/rc16/`).
- `@zodiacs/engine/sky` (`docs/sky.md`): `skyEvents` and `skyEventsOn` give
  the rise, set and upper and lower transit of the Sun, the Moon and the
  planets for an observer on the WGS84 ellipsoid, with 34′ of refraction
  (USNO), the topocentric semi-diameter (upper limb by default) and parallax,
  `limb` and `refraction` options and polar flags; `planetaryHours` and
  `planetaryHourAt` give the planetary hours in the Chaldean order, and say
  why a day has none. Rerun after the nutation against the preregistered
  gates: against skyfield with JPL DE440s (226,717 events, 1900–2100) and
  Swiss `rise_trans` (statistics only), every event agrees within 5 s but 192
  rises and sets of Uranus at 65° in 1950 (up to 11.61 s, from
  astronomy-engine's Uranus), so gates S1 and S2 fail, as they did on the
  branch; 465 of 467 USNO times are within 30 s of the published minute, and
  S3 fails on the other two (30.06 s and 30.15 s) and on three events only one
  side lists; S4, the planetary hours' worked examples and their consistency
  with the rise and set function, passes. Its package gate fails on rc.16: the
  root's graph was not to grow from rc.15's 95,273 bytes, and is 103,537
  (`docs/evidence/sky-chinese-2026-09-29/rc16/`).

The root imports none of these, and `scripts/root-isolation.mjs` checks it
from the build's own module list (`OPT_IN_SOURCE` names each entry's
modules, with `src/equator.ts`, which calc and sky share, and
`src/first-millisecond.ts`, the sky entry's).

### The nutation

The nutation is now the full IAU 2000B series (McCarthy & Luzum 2003; IERS
Conventions 2003, chapter 5). astronomy-engine 2.1.19, which is still the
ephemeris, keeps 5 of that model's 77 luni-solar terms; the engine now
evaluates all 77 and the two fixed planetary offsets itself
(`src/nutation.ts`, transcribed from `iau2000b` in NOVAS C 3.1, a work of the
US Government), adds the two largest IAU 2000 complementary terms to the
equation of the equinoxes (IERS Conventions 2010, table 5.2e), and turns
astronomy-engine's vectors on the J2000 mean equator to the ecliptic and
equator of date with astronomy-engine's own IAU 2006 precession, reproduced
line for line (`src/frame.ts`, `src/equator.ts`). No code of the package
calls astronomy-engine's nutation, its rotations to the ecliptic or equator
of date, its sidereal time or its observer functions any more; the calc
entry's topocentric observer is astronomy-engine's `terra`, reproduced term
for term, on the engine's sidereal time and frames. `LICENSING.md` and
`NOTICE` record the sources. This answers finding production-positions-7 of
the engine audit of 2026-09-22 (Zodiacs site repository,
`docs/platform/evidence/engine-audit-2026-09-22/LEDGER.md`). Evidence:
`docs/evidence/nutation-2026-09-29/`; the figures for the new entries are
from `docs/evidence/rc16-20260930/results/entries-plumbing.json` and each
entry's rerun.

The model: Δψ and Δε equal ERFA's `nut00b` within 1e-10″ at 101 instants
from 1800 to 2200 and within 6e-11″ every 0.1 day over that span
(`docs/evidence/calc-api/rc16/diagnostics.json`, D4). Sampled every 0.1 day
of TT from 1800 to 2200, the equation of the equinoxes is within 3.50e-5″ of
ERFA's `ee00` on IAU 2000B (the largest in 2146; 1.5e-5″ at the 101
instants), and the sidereal time within 3.50e-5″ of gmst06 plus that `ee00`
(`docs/evidence/rc16-20260930/results/nutation-grid.json`). The rotation to
the ecliptic of date is within 7.1e-7″ of ERFA's with `bp06` at the 101
instants (`docs/evidence/nutation-2026-09-29/results/module-against-erfa.json`).
IAU 2000B itself differs from IAU 2006/2000A (ERFA's `nut06a`) by up to
0.00394″ in Δψ on the same 0.1-day grid (in 2192), and so puts a longitude
of date up to that far from it. The engine's nutation is computed for each
instant, where astronomy-engine reused the last one for any time within
1e-6 day, so no result depends on what was computed before it.

What it moved, from rc.15 (and, in the new entries, from their builds on
rc.15 before the nutation):

- The root entry. Every longitude of date moves by the change in Δψ, the same
  for every body, node, Lilith and lot: up to 0.2701″ sampled every 10 minutes
  from 1800 to 2200, and up to 0.2635″ over 9,697 synthetic charts from 1850
  to 2150; latitudes by less than 1e-10″; speeds by up to 0.0726″ a day in the
  plumbing check's 520 charts (below). The sidereal time and the true
  obliquity move by up to 0.2452″ and 0.08654″ (every 10 minutes), so over the
  9,697 charts, at places up to 60.17° N, the ascendant and Placidus cusps
  moved by up to 0.8003″ and the midheaven by up to 0.2576″, and no chart
  changed house system. Toward the polar circle they move more: in those 520
  charts, Koch's cusps by up to 3.883″ at 65.75°, and at 66° to 80° the angles
  by up to 1.622″ and the lots by up to 3.345″, both at 67.21°, where Koch's
  cusps moved by at most 0.1023″ (46 of the 48 charts there fall back to whole
  signs) (`docs/evidence/rc16-20260930/results/plumbing-by-latitude.json`).
  Saturn-return crossings move by up to 257 s near stations (median 20 s).
  Against ERFA's IAU 2006/2000A chain on the same vectors, at 4,001 instants
  from 1800 to 2200, a longitude was up to 0.2520″ off and is up to 0.003691″
  off; the ascendant and midheaven were up to 0.8235″ and 0.2457″ off and are
  up to 0.006284″ and 0.003358″ off, at latitudes within 60°. Against Swiss
  Ephemeris 2.10.03 (statistics only), the house ladder of the Zodiacs site's
  rc.9 record is within 0.035″ in every system from 1850 to 2049, where rc.15
  was up to 3.727″ (Koch); the mean node and Lilith within 0.4503″ and 0.4887″
  (0.6091″ and 0.6785″). Each body's largest declination error against DE440s
  changes by less than 0.04″. The ayanamsas' `mean` values do not change;
  `nutation` and `true` move by the change in Δψ, which cancels from sidereal
  longitudes. (`docs/evidence/nutation-2026-09-29/results/`; on this tree the
  same run gives the same figures,
  `docs/evidence/rc16-20260930/results/root-plumbing.json`.)
- `@zodiacs/engine/calc`: in the true-of-date frames by the root's amounts (up
  to 0.114″ in longitude and 0.0554″ a day in speed at the plumbing check's 24
  instants); in the mean-of-date, J2000.0 and ICRS frames not at all, except a
  topocentric position, whose observer now turns with the engine's sidereal
  time and nutation: by up to 0.00092″. `houses()` moves with the root's
  angles (up to 0.322″ in the angles and 0.874″ in Koch's cusps at 63.4° S in
  that check); `events()` by the longitudes' change over the body's speed, up
  to 4.9 s there for the true node. Of calc's 107 rows of bounds, 104 are
  measured against Horizons and 3, the barycentric Sun's, derived from the
  barycentre's error. 71 of the measured rows fall and none rises, among them
  the outer planets' rate bounds, which the five-term nutation's rate error
  dominated (geocentric apparent Neptune 0.051 to 0.013″ a day), and the mean
  nodes' and Lilith's position bounds, 0.2 to 0.0023″; the derived rows do not
  change.
- `@zodiacs/engine/window`: switch instants by up to 17 ms in the plumbing
  check's eight windows, whose switches otherwise match one for one, but for
  two one-millisecond flickers of the true node's house at a cusp that
  appear in two windows, which natalChart confirms. The node's flicker at an
  ingress changes with it: at the ingresses of July 2026, March 2028 and
  September 2029, 1,349, 299 and 179 sign changes where the build before the
  nutation gave 1,603, 311 and 147
  (`docs/evidence/birth-window/rc16/node-flicker.json`). The engine's
  obliquity now changes by up to 2.60e-5° a day (2.073e-5° on the five-term
  series); the window's bound, 5e-5° a day, is 1.9 times that
  (`docs/evidence/birth-window/rc16/window-rates.json`). Scanned again on
  this build, the true node's millisecond jitter reaches 4.394e-5° (in 1835),
  so its bound is at least 3.01 times every value found (the branch's scan,
  before the time basis and the nutation, gave 4.832e-5° in 2187 and 2.97),
  and the same 24 of 294 ingresses are over the budget
  (`docs/evidence/birth-window/rc16/`).
- `@zodiacs/engine/techniques`: over the site-parity corpus, solar returns by
  up to 7.2 s, lunar returns by up to 0.59 s and void-of-course windows by up
  to 0.372 s, and no window, sign or aspect changes; over the plumbing check's
  six invented natives, composite positions by up to 0.1081″ and a Davison
  chart's bodies by up to 0.129″. Against USNO the solar returns moved from
  45.35 s at worst to 42.27 s, against Horizons from 33.23 s and 6.87 s to
  32.05 s and 6.81 s.
- `@zodiacs/engine/houses`: nothing, given the same input; an input taken
  from the engine moves with its sidereal time and obliquity.
- `planetaryReturns`: by the longitudes' change over the body's speed, up to
  79.2 s for a slow body near a station in the plumbing check; against
  Horizons the largest differences, as motion, went from 0.840″ to 0.804″
  (Sun) and 0.815″ to 0.705″ (Moon), and the planets' changed by up to
  0.239″.
- `@zodiacs/engine/sky`: event instants by up to 25 ms (the Moon), the
  planetary hours' boundaries by up to 8 ms, altitudes by up to 0.061″;
  azimuths by up to 2.45″, where a transit passes near the zenith. Against
  skyfield and Swiss each body's largest difference moved by at most 0.018 s,
  and the same 192 events fail.

The plumbing was checked first: the tree with the series cut to
astronomy-engine's five terms and no complementary terms gives rc.15's
results (the root, 520 charts, largest difference 8.0e-13°,
`docs/evidence/nutation-2026-09-29/results/plumbing.json`, and again on this
tree, `docs/evidence/rc16-20260930/results/root-plumbing.json`) and the new
entries' results before the nutation (178,416 values: longitudes within
2.3e-13° and every angle within 6.9e-11°, speeds within 1.2e-10° a day,
every instant to the millisecond, every structure the same;
`docs/evidence/rc16-20260930/results/entries-plumbing.json`).

Cost: a natal chart takes 3 per cent longer, one longitude 6 to 20 per cent
and a Saturn-return scan 19 per cent (the nutation's
`results/performance.json`). The series is evaluated from products of its
arguments' multiples, ten calls to `Math.sin` and `Math.cos` where 154 would
do it directly, within 1e-14″ of NOVAS's own loop.

Conformance: one verdict moves, `L1-POS-0041`, the Sun on 1908-05-30, which
was 1.076″ off in longitude and passes: 267 pass, 192 fail, 41 unsupported
of 500. The L2 residuals shrink: the ascendant from 0.182″ to 0.0190″ at
most, the midheaven from 0.178″ to 0.00815″, the Vertex from 0.285″ to
0.0134″, the East Point from 0.103″ to 0.00680″ and the cusps from 0.489″
to 0.0712″ (`conformance/RESULTS.md`, regenerated on this build;
`docs/evidence/rc16-20260930/conformance-changes.json`).

Tests whose expectations changed, each saying where its expectation now
comes from: the Mercury station of February 2026 moves 5.94 s, to
06:47:13.822Z, 0.047 s from where ERFA's frame puts it; the polar-fallback
receipt's ascendant follows the engine, 0.0003″ from ERFA's; the Placidus
latitude of the polar-limit tests (the root's and the window's), which was
1.07e-5″ below the limit on the five-term obliquity, moves by the
obliquity's change; the 1973 rc.14 replay separates the time basis from the
nutation; the calc round-trip fixture and the techniques' site-parity
fixtures were generated again on this build; and tests that took
astronomy-engine's nutation as the engine's take the engine's own.

### Receipts

The current conventions set names the nutation (*Breaking changes*). rc.15's
receipts, as the carried rc.15 archive serializes them
(`src/fixtures/receipt-rc15.json`), still parse under rc.15's set and replay
as the requests they record, on the same time basis; recomputed today every
longitude moves by the change in Δψ (0.2701″ at most) and the angles and cusps
by the change in the sidereal time and the obliquity. Receipts that rc.13 and
rc.14 wrote still parse under the rc.8 set; replayed on UT1 with the recorded
ΔT pinned, 16,218 rc.14 receipts from 1972 to 2027-10-02 differ from their
recorded results by up to 0.2554″ in the bodies and 3.022″ in the angles and
cusps, where rc.15 reproduced the angles and cusps exactly
(`docs/evidence/nutation-2026-09-29/results/receipt-replay.json`,
`docs/time.md`).

### Sizes and budgets

Import graphs (`scripts/verify-package-contents.mjs`'s measure: the
JavaScript a plain import loads), in bytes, with the sum of the graph's files
each gzipped at level 9 in parentheses
(`docs/evidence/rc16-20260930/sizes.json`):

| Entry | rc.15 as carried | rc.16 | Budget |
| --- | ---: | ---: | ---: |
| `.` | 97,704 (32,408) | 103,537 (34,828) | 108,500 (was 100,000) |
| `./calc` |  | 113,904 (37,490) | 115,000 |
| `./crossings` | 9,410 (2,768) | 9,410 (2,768) | 10,000 |
| `./deltat` | 4,968 (1,944) | 4,968 (1,944) | 5,500 |
| `./geo` | 34,135 (12,459) | 34,659 (12,953) | 35,000 |
| `./houses` |  | 13,606 (3,503) | 15,000 |
| `./internal` | 58,997 (20,156) | 64,830 (22,572) | 68,000 (was 60,000) |
| `./internal/math` | 18,165 (4,928) | 18,165 (4,928) | 20,000 |
| `./receipt` | 66,200 (22,290) | 66,580 (22,374) | 70,000 |
| `./sky` |  | 92,109 (31,262) | 97,000 (92,000 on its branch) |
| `./techniques` |  | 152,472 (50,308) | 160,000 (150,000 on its branch) |
| `./timing` | 114,916 (36,305) | 123,039 (39,477) | 129,000 (was 120,000) |
| `./vedic` | 116,779 (38,359) | 122,131 (40,647) | 128,000 (was 120,000) |
| `./window` |  | 102,590 (34,123) | 105,000 |

The root grows by 5,833 bytes, 2,420 gzipped: the nutation, 5,794
(`src/nutation.ts` 4,146, `src/frame.ts` 2,110, less 508 in
`src/ephemeris.ts`, and 46 of imports, exports and their use in
`src/declination.ts` and `src/points.ts`), and 39 bytes of export names that
the calc, window and sky entries import from the root's shared chunk
(`gastHours`, `tilt`, `eclipticOfDate`).

Every budget raised here was raised after these sizes were measured, to fit
them; each has its reason in the budget file. For the nutation, which every
graph that loads the ephemeris carries: the root from 100,000 to 108,500,
`./internal` from 60,000 to 68,000, `./timing` from 120,000 to 129,000,
`./vedic` from 120,000 to 128,000 and `./techniques` from its branch's
150,000 to 160,000. For the nutation and the frames of date it now takes
from `src/equator.ts`: `./sky` from its branch's 92,000 to 97,000. The
techniques and houses preregistrations had fixed `./techniques` at 150,000
and `./timing` at 120,000, and the sky's did not let the root grow; those
gates are recorded as failed (*New entry points*), and the raised budgets
do not make them pass. New budgets: `./calc` 115,000, `./window` 105,000 and
`./houses` 15,000; calc and window, set before the nutation, keep theirs,
with 0.96 and 2.34 per cent of headroom left. `./geo` grows by 524 bytes,
the imports and exports of the local-time chunk it now shares with
`./techniques`, and `./receipt` by 380, the conventions set that names the
nutation; both stay within their budgets.

The cap on the whole package was raised from 700,000 to 950,000 bytes after
the five new entry points were measured (in `5e0d00c`, before the nutation,
when they took the package to 879,777 bytes), for them and their
documentation; the techniques and houses preregistrations had required the
package to stay within 700,000 bytes without raising the cap. The package is
923,282 bytes unpacked in 69 files (rc.15: 668,343 in 54). A stand-in for the
Zodiacs site's engine chunk grows by 1,080 bytes gzipped with the nutation
(the nutation's `results/sizes.json`); no site build measured it.

### Corrections

- rc.15's entry says that Placidus's iteration settles to 1e-9° within 64
  steps "except within about 4e-9° of the polar limit". The window branch's
  review measured the band at about 1e-8°; `src/houses.ts` says so, and the
  window search compares the house system and the houses at every
  millisecond within 1e-8° of the limit.

## 0.1.1-rc.15 — unreleased candidate

rc.15 brings four pieces of work onto rc.14: the time basis and local time
(tzdb 2025c history before 1970, a birthplace's own mean time, Julian dates,
leap seconds and IERS UT1), Hellenistic timing techniques in
`@zodiacs/engine/timing`, the sidereal zodiac and Jyotish techniques in
`@zodiacs/engine/vedic`, and a Placidus fix near the polar limit. Three
builds came before this one, on local branches, and none was pushed or
published: the first, which had two reviews; a first attempt at a re-cut
with their fixes, dropped before review; and the re-cut. A re-check of the
re-cut found living people's birth data in commits of its history that later
commits removed, and asked for corrections to the records. This build is the
re-cut's code with those corrections, from a history rebuilt before the
first push so that no commit carries that birth data: the commits of the
earlier builds are not in this repository, and `artifacts/README.md` lists
their archives. Its `dist/` is byte-identical to the re-cut's
(`rebuilt/dist-digest.log`). The figures below that describe this build were
measured on the re-cut's tree (`recut/`) or on this one (`rebuilt/`), except
the Swiss Ephemeris statistics in the Vedic entry, measured on the first
build, whose ayanamsas are within 7.7e-11″ of this build's. Checks:
`docs/evidence/rc15-20260929/`, whose `recut/` and `rebuilt/` directories
hold the outputs cited here by those names, with each piece's own evidence
beside it.

Breaking changes, in `@zodiacs/engine/geo` unless another entry is named:

- A wall time before 1970-01-02 throws until `prepareLocalTime(date,
  timeZone)` has loaded the zone's history, one of 16 files.
  `resolveLocalToUtc`, `resolveLocalBirth` and `resolveBirth` throw an
  `Error` naming `prepareLocalTime`; `prepareLocalTime` resolves at once for
  a date in 1971 or later and for the fixed zones, and loads the history for
  any earlier date, 1970's included (`rebuilt/corrections-probe.log`).
- Unknown birth-form keys and options throw `RangeError`: an unknown key of
  `resolveLocalBirth`'s or `resolveBirth`'s input, an unknown key or a value
  of the wrong kind in `resolveLocalToUtc`'s options (`longitude`,
  `calendar`, `country`), and an unknown calendar. A misspelled `calender`
  is refused rather than ignored.
- In the root entry, a birth input (to `natalChart` or `saturnReturn`, or in
  place of a chart, as to `transits`) with a key that differs from a field
  only in letter case, such as `timescale`, `Latitude` or `deltat`, throws
  `RangeError`, and so does a `timeScale` other than `"utc"`, `"ut1"` or
  `"tt"`, `null` and `"UTC"` included. rc.14 accepted both, ignoring them as
  unknown keys (`rebuilt/corrections-probe.log`).
- `lmt` means that a local-mean-time clock read the wall time. It used to
  mean an offset with seconds, which flagged legal times such as Madras time
  in Kolkata and missed local mean time in whole minutes, such as Guam's in
  1890.
- `DeltaT.model` has a new value, `"iers-utc/1"`, for a chart from 1972 to
  2027-10-02, and the type `DeltaTSegment` a new one, `"fallback"` (types of
  the root and `@zodiacs/engine/deltat`). Code that handles each value of
  either type needs the new ones. No chart's `deltaT.segment` is
  `"fallback"`: the first cut gave it to charts in 1972 before the UT1
  table's first day, which now come from IERS C04.
- `NATAL_RECEIPT_CONVENTION_SETS` (`@zodiacs/engine/receipt`) has a new set
  at index 0, the time-basis set, so each earlier set is one index later:
  the rc.8 set is at 1, where rc.14 had it at 0. Code that takes a set by
  its index needs the new one.

Other changes to existing results:

- Wall times before 1970 are read on tzdata 2025c with its `backzone` file,
  compiled by zic and shipped in the package, not on the host's `Intl` data:
  the main data files without `backward`, and all of backzone, as the tzdb
  Makefile's `PACKRATDATA=backzone` with an empty `PACKRATLIST`. Before 1970
  that is the Makefile's own build for 584 of the 597 names; for the other
  13, links that backzone points at a zone it adds, the Makefile keeps
  `backward`'s target and the package follows backzone
  (`recut/backzone-divergence.json`, as `docs/time.md` describes). Where the
  package and the host differ, the offset changes: at some instant before
  1970, 122 of the 597 names the package ships give another offset than
  tzdata 2025c's default build, which `Intl` carries on a host with tzdb
  2025c (`recut/backzone-divergence.json`, computed from zic's output; the
  audit's list of 98 zones that the tests carry,
  `src/fixtures/tzdb-divergence-98.json`, compared another build and misses
  28 of them). Stockholm 1947-07-01 12:00, for one, is now +1:00, where a
  default build gives +2:00.
- From 1972 to 2027-10-02 a chart's `utc` is read as UTC: TT = UTC +
  (TAI − UTC) + 32.184 s from the IERS leap-second list, and UT1 = UTC +
  (UT1 − UTC) from IERS, the EOP 20 C04 series in 1972 and `finals2000A.all`
  of 2026-09-24 from 1973-01-02, observed then predicted, which the engine's
  table reproduces within 0.66 ms on each of C04's 367 days and within
  0.79 ms on each of `finals2000A.all`'s 19,997. rc.14 read the instant as UT1
  with the ΔT model. Over 1,801 synthetic charts at four places in that span,
  with Placidus houses, the ascendant and cusps moved by up to 45.0″ from
  rc.14, the midheaven by up to 12.4″, the Moon by up to 0.462″, the other
  bodies by up to 0.0723″ and ΔT by up to 0.0829 s
  (`recut/rc14-comparison.json`). Those are that sample's largest. A review's
  wider sample, 4,525 charts from 1800 to 2200 at random places within 66° of
  the equator in seven house systems, found 101.03″ in the ascendant and
  cusps (1989-04-15T19:05:42.489Z, 65.61° S 40.27° W, Porphyry) and 0.4885″
  in the Moon (1983-07-13T04:38:00.672Z, 65.35° S 65.63° W)
  (`recut/review-sample.json`). Before 1972 and after 2027-10-02 the instant
  is still read as UT1 with the model: over 7,896 charts from 1850 to 2150
  the angles and cusps are unchanged, the Sun, Moon and planets are within
  0.000003″ of rc.14's, and the true nodes within 0.035″, the rounding of
  astronomy-engine's numerical Moon velocity, which now samples on a fixed ΔT
  (`recut/rc14-comparison.json`, `recut/node-velocity.json`). Outside
  1850–2150 the nodes differ by more: by 0.0694″ at 1843-03-06T14:21:09.972Z
  and 0.0681″ at 2156-05-24T16:14:31.804Z in the review's sample.
- The leap-second list is IERS's `leap-seconds.list` updated 2026-07-06
  through Bulletin C 72, which expires 2027-06-28 (sha256
  `db5a895f16853b03bfc865e8d68f9fc8710ef1740e3400c701cd46a5bbbc3433`); after
  the expiry the last value, 37 s, is carried and
  `chart.timeScale.leapSeconds.listed` is `false`. The list has no leap
  second after 2017, and the engine matches all 28 changes of Bulletin C 72
  (`recut/leap-seconds.json`). After 2027-10-02 UT1 − UTC is taken as 0
  within ±0.9 s.
- The flag names `dst-gap` and `dst-fold` are kept, deprecated, and now
  mean a gap or fold of any cause; `jump.cause` gives it (`dst`,
  `legal-change` or `date-line`).
- Receipts gain a conventions set, `NATAL_RECEIPT_CONVENTION_SETS[0]`, which
  records the instant's scale (`receipt.timeScale`), its time basis
  (`result.timeScale`) and, for a local resolution, the calendar, tzdb
  version and form, clock, transition and birthplace mean time. Each of
  those is optional, so a local resolution in rc.14's six fields is still
  accepted, and each one given is checked arithmetically. The set is
  accepted only from 0.1.1-rc.15 on, and the rc.8 set only from rc.8 to
  rc.14. Receipts that rc.13 and rc.14 wrote, serialized by their carried
  archives, still parse under the rc.8 set and replay as the UTC requests
  they record, which their engines read as UT1. Recomputed today their
  sidereal time moves by UT1 − UTC, up to 12.2″ from 1972 to 2027-10-02:
  over 16,218 rc.14 receipts on synthetic instants in that span at latitudes
  up to 65°, the midheaven by up to 12.85″ and the ascendant and cusps by up
  to 12.94″ at the equator, 40.55″ at 60° and 129.1″ at 65°, enough to
  change its sign near a sign's edge, and the Moon by up to 0.462″
  (`recut/receipt-replay.json`, `src/replay-time-basis.test.ts`); the rc.14
  fixture's angles by 5.85e-5° (`src/receipt-time-basis.test.ts`); and five
  charts a review chose by up to 1.71e-3° in the angles, 1.80e-3° in the
  cusps and 5.98e-5° in the bodies (`recut/replay.log`). Read on UT1 with
  the recorded ΔT pinned (`timeScale: "ut1"`, `deltaT` from the receipt's
  result), the same receipts reproduce the recorded angles and cusps exactly
  (`docs/time.md`).
- The receipt codec orders a receipt's engine version by SemVer 2.0.0
  precedence against the release that brought what it checks: 0.1.1-rc.15
  for the time-basis set, rc.9 and rc.10 for the house systems they added. A
  receipt of the time-basis set under a version before 0.1.1-rc.15 in that
  order, such as 0.1.1-rc.14.1, 0.1.1-beta, 0.1.1-alpha.7 or 0.1.1-rc, is
  refused; the first cut's regular expressions let those four through. A
  receipt's engine, ephemeris and package versions must be SemVer 2.0.0
  versions, and one that is not, such as 0.1.1-rc.01 or 0.1.1-rc.13+.., is
  refused as `invalid_value`. The rc.8 set is accepted only under the
  versions that wrote it, rc.8 to rc.14, with or without build metadata;
  rc.14 accepted it under each of the six versions above and under 0.1.1-rc.15
  (`recut/versions.log`, `src/receipt-versions.test.ts`,
  `src/semver.test.ts`).
- Placidus no longer falls back to whole signs outside the polar circle
  (finding F-46). Within about 4e-9° of the polar limit, near the sidereal
  times at which a cusp's right ascension reaches 90° or 270°, the 64-step
  iteration could fail to settle to 1e-9° and the chart fell back at
  isolated milliseconds (for example at 66.56186339751429°,
  92.16879370494166° around 2000-03-20T00:00Z). Where the iteration does
  not settle, the cusp is now found by bisection on its bracket, which
  cannot fail there. Wherever the iteration settles, cusps are bit-identical
  to before.

Changes to the time basis and to local time since this candidate's first cut,
after its review, measured against that build on synthetic instants and
places (`recut/time-basis-fixes.json`, `recut/tz-line-ends.json`):

- Inside a leap second (23:59:60 on UTC), a TT instant was read one second
  early on UT1, and a UT1 instant was reported with a UT1 − UTC that did not
  add up. UT1 is now TAI + (UT1 − TAI) and the old TAI − UTC holds through
  the leap second. For TT input at 108 instants inside the 27 leap seconds,
  ΔT falls by 0.36 s to 1 s, the midheaven moves by up to 14.11″ and the
  ascendant and cusps by up to 31.23″ at 59.91° N. On UT1 input at 275
  instants around the 25 leap seconds from 1974, ΔT, the angles and the
  positions do not change; at 98 of them the reported UT1 − UTC does, where
  the first cut's was 1 s away from 32.184 s + (TAI − UTC) − ΔT.
- 1972 took UT1 − UTC as 0 within ±0.9 s. It now comes from IERS EOP 20
  C04, −0.635 s to +0.811 s, continuous with `finals2000A.all` at
  1973-01-02, where the midheaven jumped by 11.83″ in a millisecond (now
  0.01462″, the millisecond's own). Over 283 charts in 1972 at four places,
  on UTC and on TT input the midheaven moves by up to 13.26″ and the
  ascendant and cusps by up to 32.12″, while the Sun, Moon and planets keep
  their positions (within 2e-7″; the true nodes within 0.0184″); on UT1
  input the angles stay and ΔT changes by up to 0.811 s (also at 22 UT1
  instants around 1972's two leap seconds), which moves the Moon by up to
  0.399″, the other planets by up to 0.0526″ and the true nodes by up to
  0.017″.
- A speed whose two samples straddle a leap second or a step of the time
  basis (1972-01-01, 2027-10-02, and the ΔT model's 13.95 ms step at
  1941.0) is now divided by the TT between them. The first cut's speeds
  there were 1.005787 times this rate within 86.4 s of each leap second,
  0.9997422 at 1972-01-01, 1.000845 at 2027-10-02 and 0.9999193 at 1941.0.
- UT1 and TT input whose UTC fell just outside the first cut's UT1 table,
  before 1973-01-02 or after 2027-10-02, is labelled by the table
  (`"observed"` or `"predicted"` and its σ), not `"fallback"` with σ 0.9 s;
  TT input whose UTC falls up to 0.148 s past 2027-10-02 now takes UT1 − UTC
  from the table, which moves its ΔT by 0.148 s.
- The leap-second list is IERS's current one: `timeScale.leapSeconds.listed`
  is `true` from 2026-06-28 to 2027-06-28, where the first cut's expired
  list gave `false`.
- Charts change nowhere else: 20,000 charts from 1850 to 2150 on the three
  scales, 3,995 of them with a pinned ΔT, away from those instants, give the
  first cut's results but for `listed` and the UT1 table's digest, now
  `064d98b4a531053a`.
- 30 changes of standard offset that the shard generator labelled `"dst"`,
  where a zone line ended during daylight saving and the clock went back,
  are `"legal-change"` in `jump.cause` and the receipts'
  `transition.cause` (`recut/tz-line-ends.json`).
- `zoneOffsetAt` answered from `Intl` until another call loaded a zone's
  history, so one question could get two answers; it now throws until
  `prepareLocalTime` has.

New:

- Birth input takes `timeScale`: `"utc"` (default), `"ut1"` or `"tt"`; any
  other value throws `RangeError`, and so does a key that differs from a
  birth field only in letter case, such as `timescale`, which was ignored
  and read a TT instant as UTC (other unknown keys are still ignored).
  Charts report `chart.timeScale` beside `chart.deltaT`, whose `model` is
  `"iers-utc/1"` from 1972 to 2027-10-02. UT1 turns the Earth (sidereal
  time, the angles) and TT moves the planets. See `docs/time.md`.
- `@zodiacs/engine/geo`: `prepareLocalTime`, `resolveLocalBirth` and
  `zoneOffsetAt`, which before 1970 throws, as `resolveLocalToUtc` does,
  until `prepareLocalTime` has loaded the zone's history; a `longitude`
  option that reads a wall time in a zone's local mean time era on the
  birthplace's own mean time (only eras tzdb records as LMT, never a legal
  mean time); `calendar: "julian"`, converted exactly through the Julian Day
  Number, with `julianToGregorian`, `gregorianToJulian`, `country` and
  `calendarNote` from a table of the Gregorian calendar's adoption in 18
  countries, each date cited to public-domain sources (tzdata's `calendars`
  file and Grotefend's tables of 1891 and 1898) and each country named as
  tzdata's `iso3166.tab` names it (`GREGORIAN_ADOPTION`,
  `GREGORIAN_ADOPTION_SOURCES`). Each resolution names the tzdb version and
  data form, the transition behind the offset and its cause. Around each of
  the 65,237 changes of offset from 1850 to 2100 in 597 zones, 2,548,849
  sampled wall minutes in all round-trip (`recut/roundtrip-full.json`), and
  the calendar conversion matches an independent implementation of
  Richards's algorithm on all 2,817,174 days from JDN 0 to Julian 3000-12-31
  (`recut/jdn-richards.json`). NOTICE and LICENSING.md record the tzdb,
  leap-second and IERS data the package now carries, the adoption table's
  sources and the Vedic ayanamsas' star values.
- `@zodiacs/engine/timing`: annual and monthly profections, firdaria,
  zodiacal releasing from the Lots of Fortune and Spirit, and solar arc
  directions. Ages count in solar-return years, each result names its
  conventions, and dated results carry `flags` (`"outside-reference-span"`,
  `"sect-contradicts-altitude"`). A chart given on UT1 or TT is read at its
  UTC instant; a chart's pinned ΔT is not applied to the solar returns or
  the arc. See `docs/timing-hellenistic.md` and
  `docs/evidence/timing-hellenistic-2026-09-28/`.
- `@zodiacs/engine/vedic`: nine ayanamsas and user-defined ones, sidereal
  charts, nakshatras and padas, the sixteen Parashari vargas, KP sub-lords,
  Vimshottari dashas to five levels, and Yogini and Ashtottari mahadashas.
  Epoch ayanamsas are held at J2000.0 in their own precession model and
  carried with IAU 2006, as the Indian Astronomical Ephemeris has done since
  2021. An ayanamsa is read as a chart reads its instant, on the time
  basis, with an optional `timeScale` and pinned ΔT, and records its
  `timeScale`; `siderealChart` uses the chart's own. Against Swiss
  Ephemeris 2.10.03 (pyswisseph, used as an instrument; statistics only),
  at 14,647 instants from 1800 to 2200, the mean ayanamsa is within the
  0.01″ gate for Lahiri (0.0013″), Fagan–Bradley (0.00091″), True Chitra
  (0.0020″), True Revati (0.0044″) and three user-defined epochs. Four
  named ayanamsas miss it: Raman (10.14″) and Yukteswar (806.16″) by
  definition, True Pushya (0.544″) at 12 instants with δ Cnc within 0.2° of
  the Sun, and the Galactic Center (0.101″) on catalogue data. Krishnamurti
  misses it by design (0.0712″): the engine reads its epoch as 1900-01-01
  0h TT, where Swiss Ephemeris uses J1900.0. Those statistics are from the
  comparison run on the first cut (`ayanamsa-swiss.json`); at the same
  instants this build's mean and true ayanamsas are within 7.7e-11″ of the
  first cut's (`recut/ayanamsa-engine.json`). Dasha dates and a sidereal
  longitude's `utc` are UTC instants, for a chart given on UT1 or TT too.
  See `docs/vedic.md` and `docs/evidence/vedic-2026-09-28/`.
- The root entry imports none of `/timing`, `/vedic` or `/geo`, and
  `npm run exports:smoke` fails if its static graph reaches one of their
  modules or a zone history. It reads the graph from the build's own module
  list (esbuild's metafile, `dist/metafile-esm.json`, which is not packed),
  so a module is found whatever its file's name or extension.
- The conformance results (`conformance/RESULTS.md`, adapter 0.2.0, which
  now gives the instant's scale) are 266 pass, 193 fail and 41 unsupported
  of 500 (rc.14: 232, 222, 46). All 34 changes are time vectors: the 20
  backzone-history zone offsets and 9 values of TT − UTC now pass, and the
  5 repeated local times are answered from the reported transition
  (`recut/conformance.log`, `recut/conformance-changes.json`). Against the
  first cut's results no verdict changes; the residuals of TT − UTC at
  1972-06-30T23:59:59Z and 1972-07-01T00:00:00Z move from 0 to 4.2e-9 s and
  7.1e-15 s (tolerance 0.0005 s), because UT1 − UTC in 1972 is no longer
  taken as 0, and the results file is regenerated.

The package gate changes. rc.14 had one cap, 300,000 bytes unpacked, for
everything (rc.14: 282,469). rc.15 has a budget for each entry point's
import graph, the JavaScript a plain import of it loads, and a stated cap for
the whole package; `scripts/verify-package-contents.mjs` gives each with its
reason. No budget or cap changed after the first cut. On this build
(`rebuilt/sizes.json`, `rebuilt/gates.log`; each headroom rounded down):

- the root, `.`: 97,704 bytes, budget 100,000, 2.34 per cent above its size.
  rc.14's was 81,712. The 15,992 bytes more are the time basis every chart
  now needs (the leap-second and UT1 tables, 5,710; `src/time-scale.ts`,
  6,499; its use in the API and the ephemeris, 863 and 675), 655 of Placidus
  bisection, and 1,590 of imports and exports of the chunks that the new
  entry points share with the root. The first cut's root was 95,273; the
  fixes to the time basis added 2,431 of those bytes (the 1972 knots, 410;
  `src/time-scale.ts`, 1,505; the API and the ephemeris, 395 and 74; imports
  and exports, 47);
- `/timing` 114,916 (30,215 beyond the root's graph), budget 120,000;
  `/vedic` 116,779 (32,750 beyond), budget 120,000; `/geo` 34,135 (31,206
  beyond), budget 35,000, and its zone histories, loaded only by
  `prepareLocalTime`, 189,144 bytes in 16 files, budget 200,000 and exactly
  16 files; `/receipt` 66,200 (41,589 beyond), budget 70,000; `/internal`
  58,997, budget 60,000; `/internal/math` 18,165, budget 20,000;
  `/crossings` 9,410, budget 10,000; `/deltat` 4,968, budget 5,500. Each
  budget is above its graph by 1.70 per cent (`/internal`), 2.34 (the root),
  2.53 (`/geo`), 2.75 (`/vedic`), 4.42 (`/timing`), 5.74 (`/receipt`), 6.26
  (`/crossings`), 10.10 (`/internal/math`) and 10.70 (`/deltat`). As first
  cut, `/geo` was 31,672, `/receipt` 62,880, `/internal` 56,961, `/timing`
  112,485 and `/vedic` 114,106;
- the whole package: 668,343 bytes unpacked in 54 files, cap 700,000,
  4.73 per cent above its size. It grew by 385,874 bytes from rc.14's:
  278,975 (72.30 per cent) of JavaScript that only the opt-in entry points
  load, 189,144 of it the zone histories; 49,620 (12.86 per cent) of
  declarations, which no runtime loads; 41,287 (10.70 per cent) of the
  README, this file, the licences and the manifest; and 15,992
  (4.14 per cent) of the root's own graph, which its budget holds. Code that
  imports only the root loads only that graph. A budget is raised only in a
  candidate whose changelog says so.

Known limitation: the ΔT model `zodiacs-deltat/1` steps back 13.95 ms at
1941.0 (1940-12-31T18:00 UT1), where its spline hands over to its knots
(review finding F-47), and rc.15 keeps the step. Removing it would change
the model's values there. A receipt that rc.8 to rc.14 wrote records the
model's ΔT, which the receipt codec recomputes and checks to 1e-9 s, so
valid receipts of those versions would fail validation. The fix needs a new
model name, in a later candidate. Until then a speed whose samples straddle
the step is divided by the TT between them (`docs/time.md`).

Links to the organization's repositories, in the README and in this file's
earlier entries, now use its current name, zodiacs-org; GitHub redirects the
former name, ZodiacsOfficial.

Birth data in the tests, examples and documentation is synthetic, except
worked examples from published sources about people who have died, cited
with page: Saunders's charts of Christopher Reeve, Coretta Scott King and
Princess Diana, Estadella's of Charlie Chaplin, and the native of Valens's
*Anthologies* IV.9. Checks that used living people's charts, or birth dates
taken from the public record, now use invented charts; `CONTRIBUTING.md` and
`AGENTS.md` state the rule. The commits of this candidate add no living
person's birth data, and no real person's but those cited examples: the
history was rebuilt before its first push
(`docs/evidence/rc15-20260929/README.md`, *The published history*). One real
person's birth, taken from the Zodiacs site's demo chart, is in earlier
candidates' tests and evidence, in main's history; rc.15's tree no longer
holds it.

Migration: before resolving a wall time before 1970, `await
prepareLocalTime(date, timeZone)`; remove unknown keys from birth forms and
options; in birth inputs, correct keys that differ from a field only in
letter case, and give `timeScale` only as `"utc"`, `"ut1"` or `"tt"`, or leave
it out; read `lmt` as a local-mean-time clock and `jump.cause` for the kind
of a gap or fold. Expect charts from 1972 to 2027-10-02 to differ from
rc.14's by UT1 − UTC in their angles and by up to half an arcsecond in their
positions, and wall times before 1970 in the zones where backzone differs
from the host's data to resolve to other instants. Pass `timeScale: "ut1"`
or `"tt"` for an instant on one of those scales. Receipts of every earlier
set remain readable; to recompute an rc.8 to rc.14 receipt as its engine did,
pass its recorded instant with `timeScale: "ut1"` and its recorded ΔT as
`deltaT`. Before 1970, `await prepareLocalTime` before `zoneOffsetAt` too.

## 0.1.1-rc.14 — unreleased candidate

- `engines` now reads `"node": "^20.19.0 || >=22.7.0"`; rc.13's `>=18` was
  false. astronomy-engine 2.1.19 ships ES modules in a package without
  `"type": "module"`, and plain Node loads them as ES modules only from 20.19.0
  and 22.7.0. On 18.20.8, 20.18.3, 21.7.3 and 22.6.0, importing this package
  fails with "Named export 'Body' not found". Bundlers are not affected. CI
  installs the packed archive in a clean consumer on Node 20.19.0, 22.7.0, 22
  and 24, and the consumer check refuses an unsupported runtime by name.
- The licence expression is `MIT AND CC-BY-4.0`. The 32 values of Stephenson,
  Morrison & Hohenkerk's Table S15 in the package's ΔT module, shipped since
  rc.8, are CC BY 4.0, as NOTICE says; `package.json` had declared `MIT` alone.
  NOTICE, LICENSING.md and the README say where the values are: in a shared
  chunk under `dist/`, which `dist/deltat.js` re-exports. `npm run
  package:contents` checks that `package.json`, LICENSING.md, NOTICE and the
  README agree, and that the build still puts the values there.
- Instants outside `EPHEMERIS_SPAN`, the years astronomy-engine tabulates (TT
  0001-04-30T12:00 to 3998-09-03T12:00), throw `RangeError` at once from every
  calculation. rc.13 evaluated them, slowly and wrongly: a position at year
  30,000 took more than 20 s and put the Sun 29° off the ecliptic. The speed
  samples must lie inside too, so on the model ΔT clock the instants from
  0001-05-01T00:00Z to 3998-09-02T00:00Z are evaluated. This replaces rc.13's
  check against the ends of JavaScript's Date range.
- Each declination row gains `boundMarginArcsec`, the signed margin
  `(abs(dec) − trueObliquity) × 3600`. The out-of-bounds flag is exactly
  `boundMarginArcsec > 0`, the exempt Sun aside, and agrees with the sky only
  where the margin exceeds the ephemeris's declination error. Against JPL's
  DE440s at 20,000 instants from 1850 to 2150, the largest errors were 2.7″
  for the Sun, 3.4″ for the Moon, 4.6″ for Pluto and 12″ to 22″ for the other
  planets; the README gives each. Within them a flag can be wrong either way:
  at 2022-10-22T08:11:10.756Z the engine puts Mars 1.57″ inside the bound, and
  DE440s 1.05″ beyond it.
- The Sun's exemption is restated as a convention. rc.13's reason was wrong,
  and its entry is corrected below. The real Sun does pass the bound: computed
  with ERFA, at 402 of the 800 solstices from 1800 to 2199, by up to 1.09″
  (DE440s agrees within 0.008″ over 1850–2149). The engine cannot tell: its
  solar declination is off by up to 2.7″ near the present, and its solar
  latitude drifts from −1.1″ on average in the 1800s to +1.1″ in the 2100s, so
  at those solstices its margin has the real sign at only 404 of the 800. Far
  from J2000 the drift reaches tens of arcseconds: −68.3″ at the June solstice
  of year 2, +25.8″ at that of 3902. So `chartDeclinations` never flags the
  chart's own Sun, at any latitude, as rc.13 did not; it is unflagged at all
  7,995 solstices in `EPHEMERIS_SPAN`. `declinationsForBodies` exempts a
  supplied row labelled `Sun` only within `SUN_BOUND_LATITUDE` (0.001°) of the
  ecliptic, and holds it to the strict rule beyond.
- `trueObliquity` is the IAU 2006 mean obliquity plus astronomy-engine's
  five-term truncation of the IAU 2000B nutation in obliquity, not IAU 2000B
  itself, and the documentation now says so. It differed from ERFA's `obl06`
  plus `nut00b` by up to 0.086″ at the 20,000 instants.
- A declination aspect's longitude `separation` is the short way round between
  the supplied longitudes reduced exactly modulo 360, rounded once, whatever
  their size. rc.13 first normalized each longitude into [0, 360), which
  rounds: −1e-20 and 0 were 5.68e-14 apart (now 1e-20), and −0.1 and 0.2 were
  0.30000000000002275 apart (now 0.30000000000000004).
- The body-label rule is stated precisely: 1 to 80 UTF-16 code units,
  unchanged by `String.prototype.trim` (so no U+FEFF or U+3000 at either end),
  and no C0 control character or DEL. C1 controls, U+200B and lone surrogates
  pass. The rule and its message are rc.13's, but rc.13 changed the message
  without saying so: configured aspects used to say "Body labels must be
  nonempty, trimmed strings of at most 80 characters." and the declination
  functions "body identifier must be a nonempty string."; both now say "Body
  labels must be nonempty, trimmed strings of at most 80 characters, without
  control characters." Code that matched the old text must match the new.
- The archive check reads git objects only, never the working tree, and every
  commit reachable from HEAD, with no history simplification. The rc.13 check
  missed a rewrite on a merged side branch and accepted rc.11's first packing
  in any commit; reviews of two earlier local rc.14 builds found more ways
  past it. Now:
  - `artifacts/archives.json` records each archive's digest, size, file count
    and source commit. It is append-only: every committed version of it must
    be a prefix of HEAD's, and each commit's must extend its parents'. Its
    superseded entries are pinned in the script: rc.11's first packing, allowed
    only in 00bdae7, where it was committed.
  - Every recorded version, and `package.json`'s at HEAD, must be a strict
    semantic version, with no `v` prefix and no build metadata, and no two
    carried versions may be equal as npm compares them (`semver.eq`). A second
    archive under `0.1.1-rc.14+evil` or `v0.1.1-rc.14` is refused, and so is a
    HEAD version that differs only in build metadata, which let the check skip
    HEAD's rebuild.
  - In every commit, `artifacts/` must be a real directory holding only
    archives, receipts, the manifest and its README, as regular files: no
    symbolic link, no subdirectory, and no two names, nor another top-level
    entry and `artifacts`, that differ only in case.
  - Every version's receipt is checked, and nothing ever committed under
    `artifacts/` may be missing from HEAD.
  - Each archive's packed `package.json`, README, CHANGELOG and licence files
    must be byte-identical to its source commit's, and the commit that
    introduces it must be that source commit or a child of it.
  - A clean worktree of HEAD must rebuild the current version's archive byte
    for byte, both by default and with `--rebuild-all`, which also rebuilds
    every archive from its source commit; CI runs both. Each rebuild installs
    its commit's locked dependencies afresh with `npm ci` in that worktree and
    takes nothing from the checkout's `node_modules`. A change to a packed file
    under a version already carried fails either way.
  - Merge with merge commits: a squash or rebase merge rewrites the source
    commit, and the check then fails.
- rc.14 includes main's conformance suite (`conformance/`, not packed) and the
  section of LICENSING.md about it, which is packed. Its archive is built from
  that merged source.
- TypeDoc canonical URLs point to
  https://zodiacs.org/developers/engine/reference/, and the footer names both
  licences. Earlier entries refer to the separate earlier package by its
  repository, github.com/zodiacs-org/sdk, instead of its npm name.
- rc.13's exact decisions cost time. In the review's worst case, 256 bodies
  under 64 custom rules (32,045 aspects), `findConfiguredAspects` took 1.72 s,
  where rc.12 took 0.19 s, and 256 declinations all within a 90° orb took
  0.47 s, where rc.12 took 0.07 s (each the fastest of 63 runs on Node 22.22.2
  on a shared four-core machine). An ordinary chart's configured aspects or
  declinations still take under a millisecond.

Migration: plain Node consumers need Node 20.19.0 or a later 20.x, or 22.7.0
or later. Calculations at instants outside `EPHEMERIS_SPAN` throw `RangeError`.
Declination rows gain `boundMarginArcsec`. A row labelled `Sun` given to
`declinationsForBodies` more than 0.001° off the ecliptic can now be out of
bounds; the chart's own Sun in `chartDeclinations` never is. Declination
separations of longitudes outside [0, 360) can change, by less than 1e-13°.
Natal, transit, synastry, progression and receipt results are unchanged apart
from the reported engine version.

## 0.1.1-rc.13 — unreleased candidate

- Configured aspects are exact on binary64 inputs. `findConfiguredAspects`
  takes every longitude, speed, angle, orb and threshold as the exact value of
  its double, forms the signed separation without rounding, folds it into
  (−180°, 180°] by exactly 360°, and decides the orb test, the closest rule,
  the motion and the result order on exact values, with no tolerance. Only the
  reported orb is rounded, once, to nearest with ties to even. The policy's
  conventions gain `arithmetic: "exact-binary64;reported-orb-rounded-half-even"`.
  rc.11's direct subtraction still rounded across 0°: Mars at
  7.6999999999999895 and Saturn at 359.7, which are 8 + 2⁻⁵⁰ apart, are no
  longer a default conjunction at orb 8, and Jupiter at 6.3 and the Sun at 314
  now fall within a 7.3° semisquare orb, at exactly 7.3. The zero-orb square
  between 188.86 and 98.86 stays unmatched, since they are 90 + 2⁻⁴⁶ apart;
  the pre-merge rc.11 build at 00bdae79 matched it only by rounding.
- Declination parallels and contraparallels use the same exact arithmetic on
  the declination doubles: 13.3 and 12.3 match at orb 1, while 8.3 and 7.3, and
  1.1 and 0.1, do not. The reported orb and longitude separation are rounded once.
- A row labelled exactly `Sun` is never out of bounds. Other rows keep the
  strict rule against astronomy-engine's true obliquity of date. (Corrected in
  rc.14. This entry said the Sun defines the bound and so never passes it, and
  that its latitude had put the computed declination beyond it at 400 of the
  800 solstices from 1800 to 2200, by up to 1.35″, as at 2024-06-20T20:51Z. The
  real Sun does pass the bound, at 402 of the 800 solstices from 1800 to 2199,
  by up to 1.09″; the engine's 400 come from astronomy-engine's drifting solar
  latitude and have the real sign at only 404 of the 800. The obliquity is the
  IAU 2006 mean obliquity plus a five-term truncation of the IAU 2000B nutation
  in obliquity, not IAU 2000B itself. rc.14 keeps the exemption as a
  convention: for the chart's own Sun at any latitude, and for a supplied Sun
  row within 0.001° of the ecliptic.)
- One body-label rule for both analyses. The declination functions now reject,
  as configured aspects already did, labels that are empty, longer than 80
  characters, carry surrounding whitespace or contain control characters, with
  the same `RangeError` message.
- Ephemeris failures are `RangeError`s. Speed samples are checked against
  JavaScript's Date range, so `positions` and `progressedBodies` within six
  hours of ±8.64e15 ms no longer throw astronomy-engine's plain string. Any
  other string it throws, such as its light-time solver's refusal at year
  −250,000, reaches the caller as a `RangeError` whose `cause` is the original
  value. The README states the evaluable range.
- Secondary-progression documentation states that the mapping counts UTC
  milliseconds without leap seconds, not ephemeris days; that the speed is a
  central difference over ±0.001 day (±0.25 day for the nodes), numerically
  degrees per tropical year of life; and that the pre-birth mapping is not a
  converse progression. The cited PDF's SHA-256 and pages 84–85 are recorded,
  with the book's own 4.73 s precision budget behind the 5 s comparison and a
  new regression within 50 ms of its unrounded result.
- `homepage` is the repository README, and the TypeDoc footer and links are
  neutral. The packed-consumer check sets `"types": []`, refuses a temporary
  directory with `node_modules` above it, and removes that directory; the
  rc.12 site-adoption check counts its mismatches and cleans up.
- CI, now on Node 20, 22 and 24, runs `npm run archive:binding`: it refuses
  any carried archive that changes or disappears in history, and rebuilds the
  archive for the current version, requiring identical bytes (skipping that
  comparison until the version's archive exists). `artifacts/README.md` lists
  every carried archive. The first rc.11 archive, packed at 00bdae79
  (SHA-256 `13d637db…`, 70,676 bytes), was superseded before merge and never
  released; the rc.11 archive is `d88e0ff8…`. A version string will not again
  name two different byte sequences.

Migration: configured-aspect and declination-parallel results can change at
exact boundaries (membership, motion, order), and reported orbs and separations
can differ from rc.12's by up to about 2⁻⁴⁴°, not only in their last bit
(wording corrected in rc.14). 2⁻⁴⁵° was the largest difference in 200,000
random pairs; Moon 331.026 and Sun 103.38600000000001 under a custom 132.36°
angle had orb 0 in rc.12 and 2⁻⁴⁶° in rc.13. The Sun's `outOfBounds` can
change from true to false. Labels the declination API used to accept can now
throw `RangeError`. Callers near the ends of the Date range should expect
`RangeError` instead of a string. Natal, transit, synastry, progression-mapping
and receipt conventions are unchanged apart from the reported engine version.

## 0.1.1-rc.12 — unreleased candidate

- Export `PROGRESSION_DAYS_PER_YEAR`, `progressedInstant` and
  `progressedBodies` for the site's existing secondary-progression convention:
  one 365.2422-day tropical year of elapsed life maps to one day after birth
  (86,400,000 ms of UTC time, without leap seconds; wording corrected in rc.13).
- Accept the normal resolved `DateInput` forms with strict validation, retain
  signed targets before birth and preserve the original floating-point
  operation order and integer-millisecond Date truncation.
- Return the same twelve position rows as `positions`, including true lunar
  nodes. Speeds remain ephemeris degrees/day at the progressed instant, not
  degrees per lived day. No progressed angles, houses, extra chart points,
  solar-arc convention, aspect policy or receipt extension is added.
- Reuse the existing public JPL fixture for a constructed mapping-and-position
  component check and add a rounded published date-mapping example. These
  checks do not establish predictive validity or new physical accuracy bounds.

Migration: existing calculations and natal receipt conventions are unchanged
apart from the reported engine version. The site remains separately pinned;
this is an unpublished package candidate, not site adoption or npm release.

## 0.1.1-rc.11

- `createAspectPolicy` and `findConfiguredAspects` add explicit, immutable
  longitude-aspect policies: major, minor and custom angles; per-aspect,
  per-body and applying/separating/stationary orb limits; selected bodies;
  and deterministic matching. The result includes its resolved policy.
- The unpublished candidate's review repair uses direct bounded subtraction
  in configured matching and motion, preserving exact custom-angle matches
  at zero orb without widening tolerances. Configured boundary behavior can
  differ at roundoff scale from the historical helper; existing natal,
  transit, synastry and receipt calculations are unchanged. Current repair
  evidence is in `docs/evidence/rc11-20260928/decimal-orb-repair/`.
- `chartDeclinations(natal)` derives right ascension and declination from
  full ecliptic longitude and latitude using true obliquity on the chart's
  pinned or model ΔT clock. It includes parallel/contraparallel aspects,
  explicit orb settings and out-of-bounds flags. Right ascension is in
  degrees and is null at a numerical celestial pole.
- `eclipticToEquatorial`, `declinationsForBodies`, `declinationOf`,
  `declinationOrb` and `findDeclinationAspects` expose the underlying geometry
  with an explicitly supplied obliquity.
- Validation and finite comparison evidence is in
  `docs/evidence/rc11-20260928/`. The ephemeris provider and its corrections
  are unchanged; the programme's physical declination accuracy target is
  not established by the new geometric checks.

Migration: existing natal, synastry, transit and receipt conventions stay
unchanged. New aspect policies do not alter `chart.aspects`. The additional
analyses are not included in the natal receipt. This is a review candidate,
not an npm publication or a completed Phase 2 milestone.

## 0.1.1-rc.10

- A thirteenth house system, `"equal-mc"`: Equal houses from the midheaven,
  30° each with the 10th cusp at the midheaven (Swiss Ephemeris's `D`). It
  depends on neither the ascendant nor the latitude, so it is the same at every
  latitude. `equalMcCusps` computes it. Receipts accept it and check that its
  cusps count 30° from the midheaven; a receipt naming an engine before rc.10
  cannot carry it.
- `chartPoints(natal)` returns the chart's points and its sect.
  - **Mean Node and Mean South Node**: the Moon's mean node from the IERS
    Conventions' fundamental arguments (Simon et al. 1994), with the nutation in
    longitude.
  - **Black Moon Lilith**: the mean lunar apogee. It is the point of the mean
    orbit 180° from the mean perigee, carried to the ecliptic, so it has a
    latitude of up to 5.15°.
  - Both are within 0.7″ of Swiss's `SE_MEAN_NODE` and `SE_MEAN_APOG` every
    3.7 days from 1800 to 2199, and carry a speed.
  - **Vertex and East Point**, from the instant and the place. Given the same
    sidereal time, latitude and obliquity they agree with Swiss's to within
    0.00001″. `vertexOf` and `eastPointOf` compute them.
  - **The lots** of Fortune, Spirit, Eros, Necessity, Courage, Victory and
    Nemesis, after Paulus Alexandrinus, from the chart's ascendant and bodies,
    reversed by night. `sectOf` gives the sect they use.
- `antiscion`, `contraAntiscion` and `midpoint` for any longitudes.
- The osculating Lilith is left out. astronomy-engine's lunar series puts it
  198″ from Swiss's at the median, and up to 683″.

Migration: nothing changes for existing charts, systems or receipts.
`validateBirthSettings` accepts `"equal-mc"`, and its error message lists all
thirteen systems. The conventions set is rc.8's, unchanged.

## 0.1.1-rc.9

- Nine more house systems, for twelve: Koch, Regiomontanus, Campanus,
  Topocentric (Polich–Page), Alcabitius, Equal, Vehlow, Meridian (axial
  rotation) and Morinus, beside whole sign, Placidus and Porphyry. Each
  follows the definition Swiss Ephemeris uses. Given the same sidereal time,
  latitude and obliquity, every one agrees with Swiss's `swe_houses_armc` to
  within 0.0001″ over 20,000 random cases at every latitude and on the
  55°–66.6° ladder; Placidus, which iterates, to 0.0096″.
- Koch, like Placidus, is undefined inside the polar circle and falls back to
  whole sign with the `polar-fallback` flag, where Swiss refuses it. The new
  `POLAR_FALLBACK` names that system, and `POLAR_UNDEFINED_HOUSE_SYSTEMS` the
  two systems that use it; `PLACIDUS_POLAR_FALLBACK` stays. Every other
  system is computed at every latitude where the angles are. Inside the polar
  circle Regiomontanus, Campanus and Topocentric cusps turn with the eastern
  ascendant, so their 10th cusp is the lower meridian there, as in Swiss.
- Each system is exported as a function (`kochCusps`, `regiomontanusCusps`,
  `campanusCusps`, `topocentricCusps`, `alcabitiusCusps`, `equalCusps`,
  `vehlowCusps`, `meridianCusps`, `morinusCusps`) and through `computeHouses`.
  `src/house-systems.test.ts` holds each to its own definition: Regiomontanus
  and Campanus cusps lie on their circles through the horizon's north point,
  Koch and Topocentric cusps are the ascendants they are defined as, and
  Alcabitius, Meridian and Morinus cusps have the right ascensions they are
  defined by.
- Receipts accept the new systems and check each system's shape: Equal and
  Vehlow count 30° from the ascendant, the quadrant systems put the ascendant
  on the 1st cusp and the midheaven on the 10th (the lower meridian only for
  the three turning systems, and only beyond 65° of latitude), Meridian keeps
  the midheaven, and every system's cusps come in opposite pairs. A receipt
  naming an engine before rc.9 cannot carry a new system. The conventions set
  is rc.8's, unchanged.

Migration: nothing changes for whole sign, Placidus or Porphyry.
`validateBirthSettings` accepts the new names, and its error message lists
all twelve.

## 0.1.1-rc.8

- Observed ΔT with a band (Phase 1 step 1.4). The model `zodiacs-deltat/1`
  replaces astronomy-engine's 2004 polynomial: Stephenson, Morrison &
  Hohenkerk's 2016 reconstruction to 1941, USNO and IERS values from 1941,
  Bulletin A's predictions, then a damped extrapolation. Today ΔT falls from
  75.50 s to 69.20 s (IERS: 69.20 s): the Moon moves back 3.4″, and Moon
  events come about 6 s later. At 2100 ΔT is 78.9 ± 42.4 s, where rc.7 gave
  202.7 s. Every chart reports `deltaT`; birth inputs take a `deltaT` pin;
  `@zodiacs/engine/deltat` exports the model with no dependencies.
- Receipts record ΔT (`result.deltaT`, conventions `deltaT`) and name the
  ephemeris (`receipt.engine.ephemeris`, astronomy-engine 2.1.19, now an
  exact dependency pin). The conventions no longer call the planets
  "apparent": they are aberrated but not deflected, and the Moon has
  neither correction. rc.7's conventions are frozen; each set is read only
  from the engine versions that wrote it, and receipts from rc.3 to rc.7
  still parse and replay.
- `REFERENCE_SPAN`: a chart before 1800-01-01T00:00Z or from
  2200-01-01T00:00Z carries the new `outside-reference-span` flag.
- One longitude-crossing solver, the one the site runs. It moves into the
  package as `@zodiacs/engine/crossings`: `findLongitudeCrossingsWith` and
  `searchLongitudeCrossingsWith` take the longitude function as their first
  argument and import no ephemeris. `findLongitudeCrossings` and
  `saturnReturn` run it on the engine's longitudes.
- The window is (from, to]. A root exactly at `from` is no longer returned. A
  sample exactly on the target is returned once, at that sample, including a
  touch and the start of a plateau, which rc.7 dropped.
- A station that falls between two samples just past the target now gives
  both crossings. A natal Saturn 0.002° below its 2019 station gets three
  first-return passes, where rc.7 gave one.
- No sample budget and no `RangeError` for the size of a search. A quarter-day
  Moon scan over 2,600 days returns its 95 crossings, and Saturn from 1900 to
  2100 at 5 days its 13, where rc.7 threw at 10,000 samples.
  `searchLongitudeCrossings` takes an optional `maxSamples` and returns a typed
  `refused` result instead of throwing.

Migration: positions move by ΔT's change (the Moon about 3.4″ today, far
more in the far future), charts gain `deltaT` and may gain
`outside-reference-span`, and receipts from rc.8 carry the new conventions.
A crossing exactly at `from` is left out; include it by starting the window
earlier. Exact touches and grazing station pairs can add crossings to
Saturn-return seasons. Code that relied on the `RangeError` to bound work
should pass `maxSamples` to `searchLongitudeCrossings`.

## 0.1.1-rc.7

- Judge an aspect applying from the sign of its orb's rate of change. The old
  rule moved both bodies 0.02 day ahead, and so read every aspect as separating
  for the last 14.4 minutes before exact. `aspectMotion`, `AspectMotion` and
  `STATIONARY_RELATIVE_SPEED` are exported; `Aspect.applying` stays a boolean.
- Take each speed as the derivative of the reported longitude over ±0.001 day.
  The Moon's step error at perigee falls from 7.55″ a day to 0.0015″ a day. The
  true node keeps ±0.25 day. The Saturn return scan takes natal Saturn's
  direction from the same speed as the chart.
- Build the ascendant and midheaven on the true obliquity of date, the one that
  matches apparent sidereal time. Against ERFA on the 3,128-case grid, the
  ascendant's largest error falls from 506.8″ to 6.36″, and within 45° of the
  equator from 14.6″ to 0.36″. The midheaven's falls from 2.25″ to 0.20″.
- Put the Placidus limit at 90° minus the true obliquity, 66.53° to 66.59° over
  1800–2200, where it was 66°. Between the two, Placidus is now computed
  instead of falling back to whole sign.
- Offer `houseSystem: "porphyry"`. It is defined wherever the ascendant and
  midheaven are, including inside the polar circle. Placidus keeps whole sign
  as its polar fallback, now exported as `PLACIDUS_POLAR_FALLBACK` and returned
  as `fallbackSystem`.
- Receipts record the new speed, aspect and angle conventions. The set that
  rc.3 to rc.6 recorded is kept as `CONVENTIONS_RC3`, and their receipts stay
  readable and replay as before. `NATAL_RECEIPT_CONVENTION_SETS` lists both
  sets. A receipt must match one set exactly, and the old set only with an rc.3
  to rc.6 version. Porphyry is accepted only in the new set.

Migration: planetary longitudes are unchanged. Speeds, the angles, Placidus
cusps between 66° and the polar circle, and the applying flag of aspects close
to exact can change. Recorded receipts are immutable and are not rewritten.

## 0.1.1-rc.6 — unreleased candidate

- Compare the complete civil timestamp, including seconds and milliseconds, when
  matching a local HH:MM input. Historical shifts smaller than one minute now
  receive the correct gap/fold flags; neighboring ordinary times lose false
  ambiguity flags. The selected instants in the retained finite controls agree.
- Normalize only floating-point offset conversion to integer milliseconds.
  Preserve historical offset seconds, actual fractional-minute offsets, earlier
  fold selection and the existing forward-gap policy.
- Retain strict date/time/zone guards and the existing three-point offset
  sampling. This is a precision correction, not a proof of complete transition
  discovery, historical source accuracy or broad astronomical coverage.

Recorded receipts are immutable and are not rewritten. Recomputations can have
corrected time flags under this new version. The receipt schema, core numerical
formulas, the earlier package in github.com/zodiacs-org/sdk, site/starter
pins and account protocols are unchanged. The explicit merge/publication hold
and required review on pull request #5 of that repository remain.

## 0.1.1-rc.5 — unreleased candidate

- Preserve all five typed birth flags while checking derived echoes against the
  actual result. Correct unknown-time/polar echoes now produce canonical flags
  once and round-trip through the unchanged draft receipt schema.
- Reject unknown, malformed and contradictory claims. Snapshot up to 64 raw
  data entries without custom array iteration or scalar coercion; deduplicate
  valid claims. Canonical input records semantics, not the submitted array.
- Validate supplied Chart flag consistency against its input and house/angle
  metadata. Keep canonical object identity; normalize compatible echoes with a
  shallow metadata copy. This does not authenticate astronomical values.
- Capture validated public/civil settings once. Reject invalid civil settings
  and explicit null local time before Intl resolution. Ordinary Saturn inputs
  remain date-only; an explicit raw polar assertion requires one natal
  calculation before the return scan.

Migration: do not use flags to override timeKnown or the requested house system.
Fix contradictory/missing result claims in supplied Charts. Arrays over 64 raw
entries reject. Historical time flags remain assertions; executable same-realm
getters/proxies are not sandboxed. Internal computation, receipt wire format,
site/starter pins and the APIs of the earlier package in
github.com/zodiacs-org/sdk are unchanged. Required review and the explicit
merge/publication hold on pull request #5 of that repository remain.

## 0.1.1-rc.4 — unreleased candidate

- Validate the optional GeoNames client's compact v1 index and requested shard
  before caching fulfillment. Malformed HTTP-200 JSON now rejects with a fixed
  schema error and can be retried by a later explicit call.
- Reject unsafe table indices, coerced/out-of-range coordinates and malformed
  rows before returning partial results. Preserve Unicode names, empty region
  and country labels, geographical endpoints and host-independent timezone
  strings. No automatic retries, eager shard requests or new network endpoint.
- Return metadata array snapshots from `preload()` so caller mutation cannot
  alter validated cache state. Keep valid/in-flight cache sharing and original
  fetch/HTTP/JSON-parser failures.
- These checks do not authenticate place facts or detect structurally valid
  mixed-generation data. The v1 assets lack generation/content identities;
  hosts must serve matching index and shards together.

Site application rc.1 and the separately delivered standalone starter rc.3
remain pinned to their existing artifacts. Numerical calculations are unchanged
apart from the reported engine version. The explicit review/publication hold on
pull request #5 of github.com/zodiacs-org/sdk, the repository of an earlier
package, remains; this entry is not npm publication or production release.

## 0.1.1-rc.3 — unreleased candidate

- Add an optional draft natal receipt/envelope entry point for bounded local
  export/import, requested-versus-actual house preservation and redacted
  diagnostics. This does not change account sync v1 or establish an industry
  standard. Preserve original ISO spelling when captured and replay the recorded
  request without consulting today's timezone database. Imported provenance is
  an unauthenticated claim; recalculation across versions may differ.
- Reject duplicate decoded JSON keys, unknown versions/features, excessive
  input, inconsistent flags/results and unsupported exact-pole angles. Keep
  parser exceptions and arbitrary imported metadata out of diagnostics.
- The site and starter retain rc.1. Package publication, production release and
  required human/external review remain separate gates.

## 0.1.1-rc.2 — unreleased candidate

- Permit a later explicit GeoNames preload/search call to retry after rejected
  network requests, unsuccessful HTTP responses or JSON parsing failures.
- Preserve shared in-flight requests, successful index/shard caches and original
  rejection reasons. No automatic retry loop or per-caller cancellation API.
- This does not validate structurally invalid but parseable JSON responses.
  The site and public starter retain their immutable rc.1 candidate.

This candidate changes the optional geo client only; existing numerical
calculations are unchanged apart from the reported package version. The
review/publication hold on pull request #5 of github.com/zodiacs-org/sdk,
the repository of an earlier package, remains.

## 0.1.1-rc.1 — unreleased candidate

- Correct the polar ascendant in the shared implementation before deriving
  houses. Public consumers and the site receive the same rising axis.
- Require Placidus iteration convergence; allow up to 64 iterations and use
  a tighter stopping criterion, retaining the conservative 66-degree limit.
- Reject invalid calendar dates, ambiguous local date-times, non-date
  coercions, unsupported house systems and nonboolean unknown-time settings.
  Date-only ISO inputs still mean UTC midnight; date-times require an offset.
- Add public contract regressions and a real packed-consumer ESM/types check.
- Bound longitude-crossing work and reject steps that cannot advance time.
- Emit an exact coarse-sample crossing once, with explicit endpoint semantics.
- Preserve proleptic Gregorian years below 100 in local-time conversion;
  format historical years without false daylight-saving gap flags.

Migration: valid resolved inputs retain their shape. Callers previously relying
on `Date` rollover, implicit machine timezone, or silently ignored settings must
resolve/correct those inputs. Do not compare cached chart receipts across
versions without recalculation. The API of the earlier package in
github.com/zodiacs-org/sdk is unchanged.

Release holds remain in pull request #5 of that repository. This entry records
implementation, not publication, deployment, full external review, or
adoption.
